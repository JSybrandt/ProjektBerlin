
#include "UnityNP.h"
#include "Mutex.h"

namespace UnityPlugin
{

	class Invites
	{
	public:
		Invites();

		bool ProcessEvent(const sce::Toolkit::NP::Event& event);
		void Update();
	
		SimpleLock m_Lock;

	private:

		sce::Toolkit::NP::Utilities::Future<sce::Toolkit::NP::NpSessionInformation> m_JoinSession;
		sce::Toolkit::NP::Utilities::Future<sce::Toolkit::NP::MessageAttachment> m_Message;
	};

	extern Invites gInvites;
}
