#include "UserProfileSony.h"
#include "SignInSony.h"
#include "MessagePipe.h"
#include "ErrorCodesSony.h"

#include <rtc.h>

using namespace sce::Toolkit::NP;
using namespace sce::Toolkit::NP::Utilities;

namespace UnityPlugin
{
	CachedUserProfile gUserProfile;

	DO_EXPORT( ErrorCode, PrxRequestUserProfile ) ()
	{
		return gUserProfile.RequestUserProfile();
	}

	DO_EXPORT( bool, PrxUserProfileIsBusy ) ()
	{
		return gUserProfile.IsBusy();
	}

	DO_EXPORT( bool, PrxGetUserProfile ) (UserProfile* profile)
	{
		gUserProfile.GetUserProfile(profile);
		return true;
	}

	DO_EXPORT( ErrorCode, PrxRequestRemoteUserNpID ) (const char* onlineID)
	{
		return gUserProfile.RequestRemoteUserNpID(onlineID);
	}

	DO_EXPORT( bool, PrxGetRemoteUserNpID ) (NpID* npID)
	{
		return gUserProfile.GetRemoteUserNpID(npID);
	}

	DO_EXPORT( ErrorCode, PrxRequestRemoteUserProfileForOnlineID ) (const char* onlineID)
	{
		return gUserProfile.RequestRemoteUserProfileForOnlineID(onlineID);
	}

	DO_EXPORT( ErrorCode, PrxRequestRemoteUserProfileForNpID ) (const unsigned char* npID)
	{
		return gUserProfile.RequestRemoteUserProfileForNpID(npID);
	}

	DO_EXPORT( bool, PrxGetRemoteUserProfile ) (RemoteUserProfile* profile)
	{
		return gUserProfile.GetRemoteUserProfile(profile);
	}

	DO_EXPORT( bool, PrxUserProfileGetLastError ) (ResultCode* result)
	{
		return gUserProfile.GetLastError(result);
	}
	
	CachedUserProfile::CachedUserProfile()
		: m_GetCount(0)
		, m_State(STATE_NOTHING)
		, m_LastResult("UserProfile")
	{
	}

	bool CachedUserProfile::IsBusy()
	{
		SimpleLock::AutoLock lock(m_Lock);

		return m_State != STATE_NOTHING;
	}

	void CachedUserProfile::GetUserProfile(UserProfile* profile)
	{
		SimpleLock::AutoLock lock(m_Lock);
		*profile = m_profile;
	}

	std::string CachedUserProfile::GetOnlineID()
	{
		SimpleLock::AutoLock lock(m_Lock);
		return m_onlineID;
	}

	bool CachedUserProfile::ProcessEvent(const Event& event)
	{
		SimpleLock::AutoLock lock(m_Lock);
		bool handled = false;

		if (event.event == Event::profileError)
		{
			m_LastResult.SetResultSCE(event.returnCode, true, __FUNCTION__, __LINE__);
			UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_UserProfileError);
			m_GetCount = 0;
			m_State = STATE_NOTHING;
			return true;
		}

		int userId = 0;
		userId = event.userInformation.userId;

		switch(event.event)
		{
		case Event::profileGotOnlineId:
			if(m_GetCount > 0)
			{
				switch(m_State)
				{
				case STATE_GETTING_LOCAL_PROFILE:
					m_GetCount --;
					if(m_FutureOnlineID.hasError())
					{
						m_LastResult.SetResultSCE(m_FutureOnlineID.getError(), true, __FUNCTION__, __LINE__);
						UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_UserProfileError);
						return true;
					}
					else
					{
						m_onlineID = m_FutureOnlineID.get()->data;
						m_profile.onlineID = m_onlineID.c_str();
					}
					break;

				default:
					m_LastResult.SetResult(NP_ERR_BAD_STATE, true, __FUNCTION__, __LINE__, "Unexpected State");
					break;
				}
			}

			handled = true;
			break;

		case Event::profileGotNpUserInformation:
			if(m_FutureRemoteUserInfo.hasError())
			{
				m_LastResult.SetResultSCE(m_FutureRemoteUserInfo.getError(), true, __FUNCTION__, __LINE__);
				UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_UserProfileError);
				return true;
			}
			else
			{
				m_RemoteUserInfo = *m_FutureRemoteUserInfo.get();
			}
			handled = true;
			break;

		case Event::profileGotNpId:
			switch(m_State)
			{
				case STATE_GETTING_LOCAL_PROFILE:
					if(m_GetCount > 0)
					{
						m_GetCount --;
						if(m_FutureNpID.hasError())
						{
							m_LastResult.SetResultSCE(m_FutureNpID.getError(), true, __FUNCTION__, __LINE__);
							UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_UserProfileError);
							return true;
						}
						else
						{
							m_npID = *m_FutureNpID.get();
							m_profile.npID = (unsigned char*)&m_npID;
							m_profile.npIDSize = sizeof(SceNpId);
							
							SceNpDate DateOfBirth;
							int res = sceNpGetAccountDateOfBirth(&m_npID.handle, &DateOfBirth);  // get the accounts DOB
							if (res == SCE_OK)
							{
								SceRtcDateTime DobTime;
								SceRtcDateTime LocalTime;
								memset(&DobTime, 0, sizeof(DobTime));
								memset(&LocalTime, 0, sizeof(LocalTime));
								sceRtcSetYear( &DobTime, DateOfBirth.year);
								sceRtcSetMonth( &DobTime, DateOfBirth.month);
								sceRtcSetDay( &DobTime, DateOfBirth.day);	// make a Rtc struct from the DOB
								res = sceRtcGetCurrentClockLocalTime(&LocalTime); // get the current local time
								if (res == SCE_OK)
								{
									SceRtcTick DobTick;
									SceRtcTick LocalTick;
									sceRtcGetTick(&DobTime, &DobTick);
									sceRtcGetTick(&LocalTime, &LocalTick);	// convert it all to ticks

									SceRtcTick AgeTick;
									AgeTick.tick = LocalTick.tick - DobTick.tick; // calc age in ticks

									SceRtcDateTime AgeTime;
									sceRtcSetTick( &AgeTime, &AgeTick);	// convert back into Rtc structs

									m_profile.age = sceRtcGetYear(&AgeTime);	// and get age
								}
							}
							SceNpAccountId NPAccountId;
							res = sceNpGetAccountId(&m_npID.handle, &NPAccountId);  // get the account ID
							if (res == SCE_OK)
							{
								m_profile.npAccountId = NPAccountId;
							}
						}
					}
					break;

				case STATE_GETTING_REMOTE_NPID:
					if(m_FutureRemoteNpID.hasError())
					{
						m_LastResult.SetResultSCE(m_FutureRemoteNpID.getError(), true, __FUNCTION__, __LINE__);
						UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_UserProfileError);
						return true;
					}
					else
					{
						m_RemoteNpID = *m_FutureRemoteNpID.get();
					}
					break;

				default:
					m_LastResult.SetResult(NP_ERR_BAD_STATE, true, __FUNCTION__, __LINE__, "Unexpected State");
					break;
			}

			handled = true;
			break;

		case Event::profileGotAvatarUrl:
			if(m_GetCount > 0)
			{
				switch(m_State)
				{
				case STATE_GETTING_LOCAL_PROFILE:
					m_GetCount --;
					if(m_FutureAvatarURL.hasError())
					{
						m_LastResult.SetResultSCE(m_FutureAvatarURL.getError(), true, __FUNCTION__, __LINE__);
						UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_UserProfileError);
						return true;
					}
					else
					{
						m_avatarURL = *m_FutureAvatarURL.get();
						m_profile.avatarURL = m_avatarURL.c_str();
					}
					break;

				default:
					m_LastResult.SetResult(NP_ERR_BAD_STATE, true, __FUNCTION__, __LINE__, "Unexpected State");
					break;
				}
			}
			handled = true;
			break;

		case Event::profileGotCountryInfo:
			if(m_GetCount > 0)
			{
				switch(m_State)
				{
				case STATE_GETTING_LOCAL_PROFILE:
					m_GetCount --;
					if(m_FutureCountryInfo.hasError())
					{
						m_LastResult.SetResultSCE(m_FutureCountryInfo.getError(), true, __FUNCTION__, __LINE__);
						UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_UserProfileError);
						return true;
					}
					else
					{
						m_countryCode = m_FutureCountryInfo.get()->countryCode;
						m_profile.countryCode = m_countryCode.c_str();
						m_profile.language = m_FutureCountryInfo.get()->language;
					}
					break;

				default:
					m_LastResult.SetResult(NP_ERR_BAD_STATE, true, __FUNCTION__, __LINE__, "Unexpected State");
					break;
				}
			}
			handled = true;
			break;

		case Event::profileGotParentalInfo:
			if(m_GetCount > 0)
			{
				m_GetCount --;
				m_LastResult.SetResult(NP_ERR_BAD_STATE, true, __FUNCTION__, __LINE__, "Unexpected profileGotParentalInfo event");
			}
			handled = true;
			break;

		default:
			break;

		}



		switch(m_State)
		{
		case STATE_GETTING_LOCAL_PROFILE:
			if(handled && m_GetCount == 0)
			{
				// Got everything so send the data ready message.
				UnityPlugin::Messages::AddUserMessage(UnityPlugin::Messages::kNPToolKit_GotUserProfile, userId);
				m_State = STATE_NOTHING;
			}
			break;

		case STATE_GETTING_REMOTE_NPID:
			UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_GotRemoteUserNpID);
			m_State = STATE_NOTHING;
			break;

		case STATE_GETTING_REMOTE_PROFILE:
			UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_GotRemoteUserProfile);
			m_State = STATE_NOTHING;
			break;

		case STATE_NOTHING:
			break;
		}

		return handled;
	}

	ErrorCode CachedUserProfile::RequestUserProfile()
	{
		if(IsBusy())
		{
			return m_LastResult.SetResult(NP_ERR_BUSY, true);
		}

		SimpleLock::AutoLock lock(m_Lock);
		int ret;

		m_LastResult.Reset();
		m_FutureOnlineID.reset();
		m_FutureNpID.reset();
		m_FutureAvatarURL.reset();
		m_FutureCountryInfo.reset();

		sce::Toolkit::NP::UserProfileRequest request;
		memset(&request, 0, sizeof(request));
		request.userInfo.userId =GetUserId();;
		request.flag = SCE_TOOLKIT_NP_USER_PROFILE_UPDATED_INFORMATION;
#define	PROFILE_PARAMS  &request , true

		// Online ID...
		ret = sce::Toolkit::NP::UserProfile::Interface::getOnlineId( &m_FutureOnlineID, PROFILE_PARAMS );
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			return m_LastResult.SetResultSCE(ret, true, __FUNCTION__, __LINE__);
		}

		// First request was ok, so set the state now.
		m_State = STATE_GETTING_LOCAL_PROFILE;
		m_GetCount ++;

		// NpID...
		ret = sce::Toolkit::NP::UserProfile::Interface::getNpId( &m_FutureNpID, PROFILE_PARAMS );
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			return m_LastResult.SetResultSCE(ret, true, __FUNCTION__, __LINE__);
		}
		m_GetCount ++;

		// Avatar URL...
		ret = sce::Toolkit::NP::UserProfile::Interface::getAvatarUrl( &m_FutureAvatarURL, PROFILE_PARAMS );
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			return m_LastResult.SetResultSCE(ret, true, __FUNCTION__, __LINE__);
		}
		m_GetCount ++;

		// Country info...
		ret = sce::Toolkit::NP::UserProfile::Interface::getCountryInfo( &m_FutureCountryInfo, PROFILE_PARAMS );
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			return m_LastResult.SetResultSCE(ret, true, __FUNCTION__, __LINE__);
		}
		m_GetCount ++;

		return m_LastResult.GetResult();
	}

	SceNpId CachedUserProfile::GetNpID()
	{
		SimpleLock::AutoLock lock(m_Lock);
		return m_npID;
	}

	void CachedUserProfile::Update()
	{
	}

	// get remote NpID from a onlineID
	ErrorCode CachedUserProfile::RequestRemoteUserNpID(const char* onlineID)
	{
		if(IsBusy())
		{
			return m_LastResult.SetResult(NP_ERR_BUSY, true);
		}

		SimpleLock::AutoLock lock(m_Lock);

		if(!gSignedInState.IsSignedIn())
		{
			return m_LastResult.SetResult(NP_ERR_NOT_SIGNED_IN, true);
		}

		m_LastResult.Reset();
		m_State = STATE_GETTING_REMOTE_NPID;

		sce::Toolkit::NP::UserProfileRequest request;
		memset(&request, 0, sizeof(Request));
		request.userInfo.userId = GetUserId();
		request.flag = SCE_TOOLKIT_NP_USER_PROFILE_REMOTE_USER;
		request.numRemoteUserRequested = 1;

		memset(&m_RequestedOnlineId, 0, sizeof(SceNpOnlineId));
		memcpy(m_RequestedOnlineId.data, onlineID, sizeof(SceNpOnlineId));
		request.remoteUsersOnlineIds = &m_RequestedOnlineId;


		int ret = sce::Toolkit::NP::UserProfile::Interface::getNpId( &m_FutureRemoteNpID, &request, true );
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			return m_LastResult.SetResultSCE(ret, true, __FUNCTION__, __LINE__);
		}

		return m_LastResult.GetResult();
	}

	bool CachedUserProfile::GetRemoteUserNpID(NpID* npID)
	{
		SimpleLock::AutoLock lock(m_Lock);
		npID->npID = (unsigned char*)&m_RemoteNpID;
		npID->npIDSize = sizeof(SceNpId);
		return true;
	}

	ErrorCode CachedUserProfile::RequestRemoteUserProfileForOnlineID(const char* onlineID)
	{
		if(IsBusy())
		{
			return m_LastResult.SetResult(NP_ERR_BUSY, true);
		}

		SimpleLock::AutoLock lock(m_Lock);
		int ret;

		if(!gSignedInState.IsSignedIn())
		{
			return m_LastResult.SetResult(NP_ERR_NOT_SIGNED_IN, true);
		}

		m_LastResult.Reset();
		m_State = STATE_GETTING_REMOTE_PROFILE;

		sce::Toolkit::NP::UserProfileRequest request;
		memset(&request, 0, sizeof(request));
		request.userInfo.userId = GetUserId();
		request.flag = SCE_TOOLKIT_NP_USER_PROFILE_REMOTE_USER;
		strncpy(request.remoteUserOnlineId.data, onlineID, SCE_NP_ONLINEID_MAX_LENGTH);

		m_RemoteOnlineID = request.remoteUserOnlineId;

		m_FutureRemoteUserInfo.reset();

		ret = sce::Toolkit::NP::UserProfile::Interface::getNpUserInformation( &m_FutureRemoteUserInfo, &request, true );
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			return m_LastResult.SetResultSCE(ret, true, __FUNCTION__, __LINE__);
		}

		return m_LastResult.GetResult();
	}

	ErrorCode CachedUserProfile::RequestRemoteUserProfileForNpID(const unsigned char* npID)
	{
		SceNpOnlineId onlineID;
		memset(&onlineID,0, sizeof(SceNpOnlineId));
		strncpy(onlineID.data, (const char*)npID, SCE_NP_ONLINEID_MAX_LENGTH);
		return RequestRemoteUserProfileForOnlineID((const char*)&onlineID.data);
	}

	bool CachedUserProfile::GetRemoteUserProfile(RemoteUserProfile* profile)
	{
		profile->language = m_RemoteUserInfo.regionInfo.language;
		profile->onlineID = (const char*)&m_RemoteOnlineID.data;		// This might be the onlineID, or it might be the npID.
		profile->npID = (const unsigned char*)&m_RemoteUserInfo.npid;
		profile->npIDSize = sizeof(SceNpId);
		profile->avatarURL = (const char*)m_RemoteUserInfo.avatarUrl.c_str();
		profile->countryCode = (const char*)(m_RemoteUserInfo.regionInfo.countryCode);

		profile->firstName = (const char *)(m_RemoteUserInfo.personalDetail.firstName);
		profile->middleName = (const char *)(m_RemoteUserInfo.personalDetail.middleName);
		profile->lastName = (const char *)(m_RemoteUserInfo.personalDetail.lastName);
		profile->profilePictureUrl = (const char *)(m_RemoteUserInfo.personalDetail.profilePictureUrl);

		return true;
	}


};
