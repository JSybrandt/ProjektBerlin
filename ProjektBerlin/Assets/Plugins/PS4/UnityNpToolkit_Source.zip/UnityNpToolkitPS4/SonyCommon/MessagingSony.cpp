#include "MessagingSony.h"
#include "MessagePipe.h"
#include "ErrorCodesSony.h"
#include "SignInSony.h"

#include <libsysmodule.h>	// for module control

using namespace sce::Toolkit::NP;
using namespace sce::Toolkit::NP::Utilities;

namespace UnityPlugin
{

	extern std::string gSessionImageFilePath;

	CachedMessaging gMessaging;

	char CachedMessaging::sUnityMessageMagic[8] = {'U', 'n', 'i', 't', 'y', 'M', 's', 'g'};

	enum UnityPluginMessageType
	{
		MESSAGE_TYPE_GAME_INVITE,
		MESSAGE_TYPE_GAME_DATA,
	};

	struct UnityPluginMessageHeader
	{
		char magic[8];
		UnityPluginMessageType messageType;
		int dataSize;
	};

	DO_EXPORT( bool, PrxMessagingIsBusy ) ()
	{
		return gMessaging.IsBusy();
	}

	DO_EXPORT( bool, PrxMessagingSendMessage ) (const MsgRequest* request)	//const char* body, int expireMinutes, void* data, int dataSize)
	{
		return gMessaging.SendMessage(request);	//body, expireMinutes, data, dataSize);
	}

	DO_EXPORT( bool, PrxMessagingSendGameInvite ) (const MsgRequest* request)	//const char* body, int expireMinutes, void* data, int dataSize)
	{
		return gMessaging.SendGameInvite(request);	//body, expireMinutes, data, dataSize);
	}
	DO_EXPORT( bool, PrxMessagingSendInGameDataMessage ) (const unsigned char* npID, void* data, int dataSize)
	{
		return gMessaging.SendInGameDataMessage(npID, data, dataSize);
	}
	DO_EXPORT( bool, PrxMessagingShowMessageDialog ) ()
	{
		return gMessaging.ShowArrivedMessageDialog();
	}

	DO_EXPORT( bool, PrxMessagingShowInviteDialog ) ()
	{
		return gMessaging.ShowArrivedInviteDialog();
	}
	DO_EXPORT( bool, PrxMessagingGetMessageAttachment ) (MessageAttachment* attachment)
	{
		return gMessaging.GetMessageAttachement(attachment);
	}

	DO_EXPORT( bool, PrxMessagingGetGameInviteAttachment) (MessageAttachment* attachment)
	{
		return gMessaging.GetGameInviteAttachement(attachment);
	}

	DO_EXPORT( bool, PrxHasInGameDataMessage ) ()
	{
		return gMessaging.HasInGameDataMessages();
	}

	DO_EXPORT( bool, PrxGetFirstInGameDataMessage ) (InGameDataMessage* message)
	{
		return gMessaging.GetFirstInGameDataMessage(message);
	}

	DO_EXPORT( bool, PrxRemoveFirstInGameDataMessage ) ()
	{
		return gMessaging.RemoveFirstInGameDataMessage();
	}

	CachedMessaging::CachedMessaging()
		: m_Busy(false)
		, m_SessionInviteMessageAttachment(NULL)
		, m_GameInviteAttachment(NULL)
		, m_MessageAttachment(NULL)
	{
		InitMessage();

		m_FutureAttachment = new sce::Toolkit::NP::Utilities::Future<sce::Toolkit::NP::MessageAttachment>();
	}

	CachedMessaging::~CachedMessaging()
	{
		SimpleLock::AutoLock lock(m_Lock);
		free(m_Message.attachment);
		delete m_SessionInviteMessageAttachment;
		delete m_GameInviteAttachment;
		delete m_MessageAttachment;
	}

	void	CachedMessaging::InitMessage( void )
	{
		//	m_Message is of type sce::Toolkit::NP::MessageData
		//	On PS3 this contains non-POD types (STL list)
		//	We must therefore initialize carefully and cannot use memset on a struct with non-POD data elements
#if   PSP2_USING_WEBAPI
		// Re-initialise using the MessageData constructor, don't use memset.
		m_Message = MessageData();
#else
		memset(&m_Message,0,sizeof(MessageData));
#endif

		m_Message.availablePlatforms = SCE_TOOLKIT_NP_AVAILABLE_PLATFORM_PS4;		// was being over written by the memset
		m_Message.userInfo.userId = UnityPlugin::GetUserId();
	}

	void InGameMessageFIFO::Add(InGameDataMessage& gameDataMsg)
	{
		SimpleLock::AutoLock lock(m_Lock);
		m_FIFO.push_back(gameDataMsg);
	}

	bool InGameMessageFIFO::HasData()
	{
		SimpleLock::AutoLock lock(m_Lock);
		return !m_FIFO.empty();
	}

	bool InGameMessageFIFO::GetFirst(InGameDataMessage* gameDataMsg)
	{
		SimpleLock::AutoLock lock(m_Lock);
		if(!m_FIFO.empty())
		{
			*gameDataMsg = m_FIFO.front();
			return true;
		}

		return false;
	}

	bool InGameMessageFIFO::RemoveFirst()
	{
		SimpleLock::AutoLock lock(m_Lock);
		if(!m_FIFO.empty())
		{
			InGameDataMessage img = m_FIFO.front();
			free(img.data);
			m_FIFO.pop_front();
			return true;
		}

		return false;
	}

	void InGameMessagePendingFIFO::Add(int gameDataMsgID)
	{
		SimpleLock::AutoLock lock(m_Lock);
		m_FIFO.push_back(gameDataMsgID);
	}

	bool InGameMessagePendingFIFO::HasData()
	{
		SimpleLock::AutoLock lock(m_Lock);
		return !m_FIFO.empty();
	}

	bool InGameMessagePendingFIFO::GetFirst(int* gameDataMsgID)
	{
		SimpleLock::AutoLock lock(m_Lock);
		if(!m_FIFO.empty())
		{
			*gameDataMsgID = m_FIFO.front();
			return true;
		}

		return false;
	}

	bool InGameMessagePendingFIFO::RemoveFirst()
	{
		SimpleLock::AutoLock lock(m_Lock);
		if(!m_FIFO.empty())
		{
			m_FIFO.pop_front();
			return true;
		}

		return false;
	}
	#define GETCOMMID ""
	bool CachedMessaging::ProcessEvent(const sce::Toolkit::NP::Event& event)
	{
		SimpleLock::AutoLock lock(m_Lock);
		bool handled = false;
		//int ret;

		switch(event.event)
		{
			case Event::messageSent:						// An event generated when a message has been sent.
				switch(event.returnCode)
				{
					case SCE_TOOLKIT_NP_SUCCESS:
						UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_MessagingSent);
						break;

					case 1:
						UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_MessagingCanceled);
						break;

					default:
						UnityPlugin::Messages::LogWarning("messageSent unknown return code - %s\n", LookupSceErrorCode(event.returnCode));
						UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_MessagingNotSent);
						break;
				}

				free(m_Message.attachment);
				m_Message.attachment = NULL;
				m_Message.attachmentSize = 0;

				m_Busy = false;
				handled = true;
				break;
			case Event::messageError:						// An event generated when a message failed to be received or sent. 
				// If the error is SCE_NP_BASIC_ERROR_BUSY then most likely the sending frequency is too high. SCE set limits on how often you can send a message.
				{
					if (event.returnCode == SCE_TOOLKIT_NP_MESSAGE_SERVICE_BUSY)
					{
						SceCommonDialogStatus status = sceInvitationDialogUpdateStatus();
						switch (status) 
						{
							case SCE_COMMON_DIALOG_STATUS_FINISHED:
							{
								//TTY::onScreenPrintf("SCE_COMMON_DIALOG_STATUS_FINISHED\n");
								break;
							}
							case SCE_COMMON_DIALOG_STATUS_NONE:
							case SCE_COMMON_DIALOG_STATUS_INITIALIZED:
							{
								m_Busy = false;
								return true;
							}
							case SCE_COMMON_DIALOG_STATUS_RUNNING:
							{
								sceInvitationDialogClose();
								break;
							}
						}
						SceCommonDialogResult result;
						SceInvitationDialogResult dialogResult;
						int ret = sceInvitationDialogGetResult(&dialogResult);
						if (ret >= 0)
						{
							result = dialogResult.result;
							ret = dialogResult.errorCode;
						}
						sceInvitationDialogTerminate();
						sceSysmoduleUnloadModule(SCE_SYSMODULE_INVITATION_DIALOG);
					}
					else
					{
						// created for SCE_NP_ERROR_LATEST_PATCH_PKG_EXIST ... patch support
						// generic error code returning ... doesn't this already exist?
						MessagingError errormessage(event.returnCode);
						Messages::PluginMessage* msg = new Messages::PluginMessage();
						msg->type = Messages::kNPToolKit_MessagingError;
						msg->SetData(&errormessage, sizeof(errormessage) );
						AddMessage(msg);
					}
				}
	
				m_Busy = false;
				handled = true;
				break;

			case Event::messageRetrieved:					// An event generated when a message attachment has been retrieved.
				if(m_FutureAttachment->getError() != SCE_TOOLKIT_NP_SUCCESS)
				{
					Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(m_FutureAttachment->getError()));
				}
				else
				{
					sce::Toolkit::NP::MessageAttachment* attachment = m_FutureAttachment->get();


					UnityPlugin::Messages::Log("messageRetrieved - %p, %d", attachment->getAttachmentData(), attachment->getAttachmentSize());
					UnityPlugin::Messages::Log("messageRetrieved - %p, %d, %s", attachment->getAttachmentData(), attachment->getAttachmentSize(), GETCOMMID );
					UnityPluginMessageHeader* header = (UnityPluginMessageHeader*)m_FutureAttachment->get()->getAttachmentData();
					if(memcmp(header->magic, sUnityMessageMagic, sizeof(header->magic)) == 0)
					{
						size_t dataSize = header->dataSize;
						SceChar8* data = (SceChar8*)(header + 1);

						switch(header->messageType)
						{
							case MESSAGE_TYPE_GAME_INVITE:
								{
									UnityPlugin::Messages::Log("messageRetrieved unityICD - %p, %d, %s", data, dataSize, GETCOMMID);


									delete m_GameInviteAttachment;
									m_GameInviteAttachment = new sce::Toolkit::NP::MessageAttachment();
									m_GameInviteAttachment->setAttachmentData(data, dataSize);

									UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_MessagingCustomInviteRetrieved);
								}
								break;

							case MESSAGE_TYPE_GAME_DATA:
								{
									UnityPlugin::Messages::Log("messageRetrieved unityCD - %p, %d, %s", data, dataSize, GETCOMMID);

									delete m_MessageAttachment;
									m_MessageAttachment = new sce::Toolkit::NP::MessageAttachment();
									m_MessageAttachment->setAttachmentData(data, dataSize);
									UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_MessagingDataMessageRetrieved);
								}
								break;

							default:
								UnityPlugin::Messages::LogError("messageRetrieved - Unknown message attachment type %d", header->messageType);
								break;
						}
					}
					else
					{
						// Assume it's a session invite.
						m_SessionInviteMessageAttachment = new sce::Toolkit::NP::MessageAttachment();
						m_SessionInviteMessageAttachment->setAttachmentData(attachment->getAttachmentData(), attachment->getAttachmentSize());
						UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_MessagingSessionInviteRetrieved);	// trigger a OnSessionInviteMessageRetrieved event
					}
				}
				m_Busy = false;
				handled = true;
				break;

			case Event::messageDialogTerminated:			// An event generated when a message dialog box is terminated.
				m_Busy = false;
				handled = true;
				break;

			case Event::messageInGameDataReceived:			// An event generated when an in-game data message has been received.
				if(event.returnCode < 0)
				{
					Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(event.returnCode));
				}

				m_InGameDataMessagePendingFIFO.Add(event.returnCode);

				handled = true;
				break;

			case Event::messageInGameDataRetrievalDone:		// An event generated when an in-game data message has been retrieved.
				if(event.returnCode != SCE_TOOLKIT_NP_SUCCESS)
				{
					Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(event.returnCode));
				}

				{
					sce::Toolkit::NP::ReceivedInGameDataMessage& msg = *m_FutureInGameDataMessageRecieved.get();
	
					InGameDataMessage igmMsg;
					igmMsg.messageID = msg.messageId;
					igmMsg.npID = (unsigned char*)&msg.from;
					igmMsg.npIDSize = sizeof(SceNpId);
					igmMsg.dataSize = msg.message.dataSize;
					igmMsg.data = malloc(SCE_NP_BASIC_IN_GAME_MESSAGE_SIZE_MAX);
					memcpy(igmMsg.data, msg.message.data, SCE_NP_BASIC_IN_GAME_MESSAGE_SIZE_MAX);
					m_InGameDataMessageFIFO.Add(igmMsg);
				}

				Messages::AddMessage(Messages::kNPToolKit_MessagingInGameDataMessageRetrieved);

				m_Busy = false;
				handled = true;
				break;

			case Event::npSessionInviteNotification:
				{
					//UnityPlugin::Messages::Log("Messaging - Received session invite message");
					UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_MessagingSessionInviteReceived);
				}
				m_Busy = false;
				handled = true;
				break;

			case Event::npSessionJoinResult:
				{
					//UnityPlugin::Messages::Log("Messaging - Received join message");
					UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_MessagingSessionInviteAccepted);
			    }
				m_Busy = false;
				handled = true;	
				break;
 
			default:
				UnityPlugin::Messages::LogWarning("Unexpected event from messaging service: event=%d\n", event.event);
				handled = true;
				break;
		}

		return handled;
	}

	bool CachedMessaging::IsBusy()
	{
		SimpleLock::AutoLock lock(m_Lock);
		return m_Busy;
	}
	bool CachedMessaging::SendInGameDataMessage(const unsigned char* npID, void* data, int dataSize)
	{
		SimpleLock::AutoLock lock(m_Lock);

		if(dataSize > SCE_NP_BASIC_IN_GAME_MESSAGE_SIZE_MAX)
		{
			Messages::LogError("Messaging::%s@L%d - data size > %d bytes", __FUNCTION__, __LINE__, SCE_NP_BASIC_IN_GAME_MESSAGE_SIZE_MAX);
			return false;
		}
		
		sce::Toolkit::NP::SendInGameMessageRequest  igm;
		memcpy(&igm.recipientNpId, npID, sizeof(SceNpId));
		igm.recipientPlatformType = SCE_NP_PLATFORM_TYPE_PS4;
		igm.userInfo.userId = GetUserId();
		memcpy(&igm.message.data, data, dataSize);
		igm.message.dataSize = dataSize;

		int ret = Messaging::Interface::sendInGameMessage(&igm);
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(ret));
			return false;
		}

		m_Busy = true;
		return true;
	}

	bool CachedMessaging::SendMessage(const MsgRequest* request)
	{
		void* data = request->data;
		int dataSize = request->dataSize;

		if(data == NULL)
		{
			static char noData[] = "No data";
			data = noData;
			dataSize = strlen(noData)+1;
		}

		InitMessage();
		m_Message.body = request->body;
		m_Message.expireMinutes = request->expireMinutes;
		int ret;

		m_Message.dialogFlag = SCE_TOOLKIT_NP_DIALOG_TYPE_USER_EDITABLE;
		m_Message.dataDescription = request->dataDescription;
		m_Message.dataName = request->dataName;
		m_Message.npIds = NULL;		// Array of npIDs to send the message to.
		m_Message.npIdsCount = request->npIDCount;	// Number of IDs that can be selected in the message dialog, or if npIds != NULL the number of IDs in the array.
		m_Message.iconPath = request->iconPath;
		memset(&m_Message.npSessionId, 0, sizeof(m_Message.npSessionId));
		
		int msgSize = sizeof(UnityPluginMessageHeader) + dataSize;
		SceChar8* buffer = (SceChar8*)malloc(msgSize);
		UnityPluginMessageHeader* msgHeader = (UnityPluginMessageHeader*)buffer;
		SceChar8* msgData = (SceChar8*)(msgHeader + 1);

		memcpy(msgHeader->magic, sUnityMessageMagic, sizeof(msgHeader->magic));
		msgHeader->messageType = MESSAGE_TYPE_GAME_DATA;
		msgHeader->dataSize = dataSize;
		memcpy(msgData, data, dataSize);
		
		m_Message.attachment = buffer;
		m_Message.attachmentSize = msgSize;

		ret = Messaging::Interface::sendMessage(&m_Message,SCE_TOOLKIT_NP_MESSAGE_TYPE_CUSTOM_DATA);
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(ret));
			return false;
		}

		return true;
	}

	// Game invite with custom data. NOTE for session invites use CachedMatching::InviteToSession instead.
	bool CachedMessaging::SendGameInvite(const MsgRequest* request)
	{
		void* data = request->data;
		int dataSize = request->dataSize;
		int expireMinutes = request->expireMinutes;

		if(data == NULL)
		{
			static char noData[] = "No data";
			data = noData;
			dataSize = strlen(noData)+1;
		}

		if(request->expireMinutes <= 0)		// Invites MUST have an expiry time > 0.
		{
			Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, "expireMinutes invalid");
			expireMinutes = 30;
		}

		InitMessage();
		m_Message.body = request->body;
		int msgSize = sizeof(UnityPluginMessageHeader) + dataSize;
		SceChar8* buffer = (SceChar8*)malloc(msgSize);
		UnityPluginMessageHeader* msgHeader = (UnityPluginMessageHeader*)buffer;
		SceChar8* msgData = (SceChar8*)(msgHeader + 1);

		memcpy(msgHeader->magic, sUnityMessageMagic, sizeof(msgHeader->magic));
		msgHeader->messageType = MESSAGE_TYPE_GAME_INVITE;
		msgHeader->dataSize = dataSize;
		memcpy(msgData, data, dataSize);

		m_Message.attachment = buffer;
		m_Message.attachmentSize = msgSize;
		m_Message.dataDescription = request->dataDescription;
		m_Message.dataName = request->dataName;
		m_Message.dialogFlag = SCE_TOOLKIT_NP_DIALOG_TYPE_USER_EDITABLE;
		m_Message.npIds = NULL;		// Array of npIDs to send the message to.
		m_Message.npIdsCount = request->npIDCount;	// Number of IDs that can be selected in the message dialog, or if npIds != NULL the number of IDs in the array.
		m_Message.iconPath = request->iconPath;
		memset(&m_Message.npSessionId, 0, sizeof(m_Message.npSessionId));
		
		int ret = Messaging::Interface::sendMessage(&m_Message, SCE_TOOLKIT_NP_MESSAGE_TYPE_INVITE, true);
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(ret));
			return false;
		}

		return true;
	}

	bool CachedMessaging::ShowArrivedInviteDialog()
	{
		sce::Toolkit::NP::DisplayMessageRequest messageRequest; 
		memset(&messageRequest,0,sizeof(messageRequest));
		messageRequest.userInfo.userId = GetUserId();
		int ret = Messaging::Interface::displayReceivedMessages(SCE_TOOLKIT_NP_MESSAGE_TYPE_INVITE, &messageRequest);
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(ret));
			return false;
		}

		return true;
	}

	bool CachedMessaging::ShowArrivedMessageDialog()
	{
		// NOTE: Currently not working, also doesn't work in the SCE api_np_toolkit sample project.
		sce::Toolkit::NP::DisplayMessageRequest messageRequest; 
		memset(&messageRequest,0,sizeof(messageRequest));
		messageRequest.userInfo.userId =  GetUserId();
		int ret = Messaging::Interface::displayReceivedMessages(SCE_TOOLKIT_NP_MESSAGE_TYPE_CUSTOM_DATA, &messageRequest);
		if (ret != SCE_TOOLKIT_NP_SUCCESS)
		{
			Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(ret));
			return false;
		}

		return true;
	}

	sce::Toolkit::NP::MessageAttachment* CachedMessaging::GetSessionInviteAttachment()
	{
		SimpleLock::AutoLock lock(m_Lock);
		return m_SessionInviteMessageAttachment;
	}

	bool CachedMessaging::GetMessageAttachement(MessageAttachment* attachement)
	{
		SimpleLock::AutoLock lock(m_Lock);
		if(m_MessageAttachment)
		{
			attachement->data = m_MessageAttachment->getAttachmentData();
			attachement->dataSize = m_MessageAttachment->getAttachmentSize();
			return true;
		}

		return false;
	}

	bool CachedMessaging::GetGameInviteAttachement(MessageAttachment* attachement)
	{
		SimpleLock::AutoLock lock(m_Lock);
		if(m_GameInviteAttachment)
		{
			attachement->data = m_GameInviteAttachment->getAttachmentData();
			attachement->dataSize = m_GameInviteAttachment->getAttachmentSize();
			return true;
		}

		return false;
	}

	bool CachedMessaging::HasInGameDataMessages()
	{
		return m_InGameDataMessageFIFO.HasData();
	}

	bool CachedMessaging::GetFirstInGameDataMessage(InGameDataMessage* message)
	{
		return m_InGameDataMessageFIFO.GetFirst(message);
	}

	bool CachedMessaging::RemoveFirstInGameDataMessage()
	{
		return m_InGameDataMessageFIFO.RemoveFirst();
	}

	void CachedMessaging::Update()
	{
		if(m_FutureInGameDataMessageRecieved.isBusy() == false)
		{
			// Process the incoming in-game message FIFO.
			int msgID;
			if(m_InGameDataMessagePendingFIFO.GetFirst(&msgID))
			{
				m_InGameDataMessagePendingFIFO.RemoveFirst();
				sce::Toolkit::NP::ReceiveInGameMessageRequest request; 
				request.userInfo.userId =  GetUserId();
				request.messageId = msgID;
				int ret = sce::Toolkit::NP::Messaging::Interface::retrieveInGameMessage(&request, &m_FutureInGameDataMessageRecieved);
				if(ret < 0)
				{
					Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(ret));
					m_Busy = false;
				}
			}
		}
	}

	// Retreive the message attachment from the invite message
	// ... will trigger a Event::messageRetrieved if successful
	// retrieveMessageAttachmentFromEvent() only exists on PS4
	bool CachedMessaging::ProcessMatchingInviteMessage(SceNpSessionInvitationEventParam * InviteEvent)
	{
		sce::Toolkit::NP::ReceiveMessageRequest request; 
		request.eventParamData = (const char*)InviteEvent;
		request.msgType = SCE_TOOLKIT_NP_MESSAGE_TYPE_INVITE;
		request.userInfo.userId =  GetUserId();

		if ( m_FutureAttachment->isBusy() )
		{
			// Issue 723029 : 
			m_FutureAttachment = new sce::Toolkit::NP::Utilities::Future<sce::Toolkit::NP::MessageAttachment>();
		}

		int ret = sce::Toolkit::NP::Messaging::Interface::retrieveMessageAttachmentFromEvent(&request, m_FutureAttachment);
		if(ret < 0)
		{
			Messages::LogError("Messaging::%s@L%d - %s", __FUNCTION__, __LINE__, LookupSceErrorCode(ret));
			return false;
		}
		return true;
	}

	void CachedMessaging::DumpSessionInviteMessageAttachment(SceChar8* messageData)
	{
		printf("dumping session invite message attachment\n");
		SessionInformation *sessionInfo = (SessionInformation *)messageData;	// only the data upto sessionAttributes is valid
		SessionInformation sessionCopy;
		size_t sessionAttribOffset = ((size_t)&sessionInfo->sessionAttributes - (size_t)&sessionInfo->sessionName) + sizeof(SceInt);

		memcpy(&sessionCopy, sessionInfo, sessionAttribOffset);

		printf("session name :%s\n", sessionInfo->sessionName);
		printf("numMembers:%d numSessionAttributes:%d\n", sessionInfo->numMembers, sessionInfo->numSessionAttributes);
			
		SessionAttribute *sessionAttributes = (SessionAttribute *)(messageData+sessionAttribOffset);
		for (int i=0; i<sessionInfo->numSessionAttributes; i++)
		{
			printf("Session Attribute %d, %s\n", i, sessionAttributes[i].attribute);
			sessionCopy.sessionAttributes.push_back(sessionAttributes[i]);
		}

		int memberOffset=sessionAttribOffset + (sessionInfo->numSessionAttributes * sizeof(SessionAttribute));
		for (int i=0; i<sessionInfo->numMembers; i++)
		{
			SessionMember *sessionMember = (SessionMember *)(messageData+memberOffset);
			SessionMember memberCopy;
			memcpy(&memberCopy, sessionMember, sizeof(SessionMember)- sizeof(SessionAttributeList));
			printf("member %d, %s\n",i, (char *)&sessionMember->userInfo);


			memberOffset += sizeof(SessionMember)- sizeof(SessionAttributeList);
			SceInt numMemAttributes;
			memcpy(&numMemAttributes, messageData+memberOffset, sizeof(SceInt));
			memberOffset += sizeof(SceInt);
			printf(" #Member Attributes:%d\n", numMemAttributes);
			SessionAttribute *memberAttributes = (SessionAttribute*) (messageData+memberOffset);
			for (int j=0; j<numMemAttributes; j++)
			{
				printf("attrib %d, %s\n", j, memberAttributes[j].attribute);
				memberCopy.memberAttributes.push_back(memberAttributes[j]);
			}
				
			sessionCopy.memberData.push_back(memberCopy);
			memberOffset+= (sizeof(SessionAttribute) * numMemAttributes );
		}
		
	}

}
