#include <np.h>
#include <string>


#include "UnityNP.h"
#include "ErrorCodesSony.h"
#include "NetCtlStatus.h"

#if	NP_HAS_ERROR_CODES
 #include "ErrorCodesSony.h"
#endif
#include "toolkit.h"
#include "MessagePipe.h"
#include "SignInSony.h"
#include "UserProfileSony.h"
#if NP_HAS_BANDWIDTH
 #include "NetInfo.h"
#endif
#if NP_HAS_FRIENDS_LIST
 #include "FriendsListSony.h"
#endif
#if	NP_HAS_ONLINE_PRESENCE
 #include "OnlinePresenceSony.h"
#endif
#if	NP_HAS_TROPHIES
 #include "TrophiesSony.h"
#endif
#if	NP_HAS_RANKING
 #include "RankingSony.h"
#endif
#if	NP_HAS_MATCHING
 #include "MatchingSony.h"
#endif
#if	NP_HAS_WORD_FILTER
 #include "WordFilterSony.h"
#endif
#if	NP_HAS_MESSAGING
 #include "MessagingSony.h"
#endif
#if	NP_HAS_TUSTSS
 #include "TusTssSony.h"
#endif
#if	NP_HAS_COMMERCE
 #include "CommerceSony.h"
#endif
#if	NP_HAS_NP_DIALOGS
 #include "NpDialogsSony.h"
#endif
#if	NP_HAS_NP_FACEBOOK
#include "FacebookSony.h"
#endif
#if NP_HAS_TWITTER
#include "TwitterSony.h"
#endif
#if NP_HAS_TICKETING
#include "Ticketing.h"
#endif
#if NP_HAS_INVITES
#include "Invites.h"
#endif
#if NP_HAS_NP_REQUESTS
#include "NpAsyncRequests.h"
#endif

#if defined(GLOBAL_EVENT_QUEUE)
UnityPlugin::PSP2SystemEventManager gSystemEventManager;
#endif

// Declare various interfaces to the player runtime.
IPluginUnity* g_IUnity = NULL;
IPluginSceAppParams* g_ISceAppParams = NULL;
IPluginSceNpParams* g_ISceNpParams = NULL;

void SetupRuntimeInterfaces()
{
	if(g_QueryInterface)
	{
#if defined(GLOBAL_EVENT_QUEUE)
		UnityEventQueue::IEventQueue* eventQueue =  GetRuntimeInterface<UnityEventQueue::IEventQueue>(PRX_PLUGIN_IFACE_ID_GLOBAL_EVENT_QUEUE);
		if (eventQueue)
		{
			gSystemEventManager.Initialize(eventQueue);
		}
#endif
		g_IUnity = GetRuntimeInterface<IPluginUnity>(PRX_PLUGIN_IFACE_ID_UNITY);
		g_ISceAppParams = GetRuntimeInterface<IPluginSceAppParams>(PRX_PLUGIN_IFACE_ID_SCE_APP_PARAMS);
		g_ISceNpParams = GetRuntimeInterface<IPluginSceNpParams>(PRX_PLUGIN_IFACE_ID_SCE_NP_PARAMS);
	}
}

using namespace sce::Toolkit::NP;
using namespace sce::Toolkit::NP::Utilities;
using namespace UnityPlugin;

bool gInitialized = false;
unsigned int gCreationFlags = 0;
static	bool	bIsShuttingDown = false;


bool	IsShuttingDown( void )
{
	return	bIsShuttingDown;
}

void	SetShutDown(bool shuttingDown=true)
{
	bIsShuttingDown = shuttingDown;
}

void myNpToolkitCallback(const sce::Toolkit::NP::Event& event)
{
	if( IsShuttingDown() )
	{
		UnityPlugin::Messages::LogWarning("NP request completed after after shutdown: service = %d, event = %d\n", event.service, event.event);
		return;
	}
	
	switch(event.service)
	{
	case core:
		UNITY_TRACE("Received core callback %d\n",event.event);

		switch(event.event)
		{
			case Event::enetDown:
				// Do nothing (Vita & PS4), this event is now handled by NetCtlStatusCallback() which can be found in NetCtlStatus.cpp
				// On PS3 this still needs looking into, the callback code doesn't seem to work.
				break;

			case Event::enetUp:
				UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_ConnectionUp);
				break;

			case Event::loggedIn:
				UnityPlugin::gSignedInState.ProcessEvent(event);;
				break;

			case Event::loggedOut:
				UnityPlugin::gSignedInState.ProcessEvent(event);;
				break;

			default:
				DBG_LOG_WARNING("core service event not handled: %d", event.event);
				break;
		}
		break;

	case netInfo:
#if NP_HAS_BANDWIDTH
		if(UnityPlugin::gNetInfo.ProcessEvent(event)) return;
#endif
		if(UnityPlugin::gSignedInState.ProcessEvent(event)) return;
		DBG_LOG_WARNING("netInfo service event not handled: %d", event.event);
		break;

#if NP_HAS_FRIENDS_LIST
	case friends:
		if(UnityPlugin::gFriendsList.ProcessEvent(event)) return;
		DBG_LOG_WARNING("friends service event not handled: %d", event.event);
		break;
#endif
#if NP_HAS_MATCHING
	case matching:
		if(UnityPlugin::gMatching.ProcessEvent(event)) return;
		DBG_LOG_WARNING("matching service event not handled: %d", event.event);
		break;
#endif
	case profile:
		if(UnityPlugin::gUserProfile.ProcessEvent(event)) return;
		DBG_LOG_WARNING("profile service event not handled: %d", event.event);
		break;

#if NP_HAS_TROPHIES
	case trophy:
		if(UnityPlugin::gTrophies.ProcessEvent(event)) return;
		DBG_LOG_WARNING("trophy service event not handled: %d", event.event);
		break;
#endif
#if NP_HAS_RANKING
	case ranking:
		if(UnityPlugin::gRanking.ProcessEvent(event)) return;
		DBG_LOG_WARNING("ranking service event not handled: %d", event.event);
		break;
#endif
#if NP_HAS_ONLINE_PRESENCE
	case presence:
		if(UnityPlugin::gPresence.ProcessEvent(event)) return;
		DBG_LOG_WARNING("presence service event not handled: %d", event.event);
		break;
#endif
#if NP_HAS_WORD_FILTER
	case wordFilter:
		if(UnityPlugin::gWordFilter.ProcessEvent(event)) return;
		DBG_LOG_WARNING("wordfilter service event not handled: %d", event.event);
		break;
#endif
#if NP_HAS_COMMERCE
	case commerce:
		if(UnityPlugin::gCommerce->ProcessEvent(event)) return;
		DBG_LOG_WARNING("commerce service event not handled: %d", event.event);
		break;
#endif

	case auth:

#if NP_HAS_TICKETING
		if(UnityPlugin::gTicketing.ProcessEvent(event)) return;
#endif

		DBG_LOG_WARNING("auth service event not handled: %d", event.event);
		break;

#if NP_HAS_NP_FACEBOOK
	case sns:
		if(UnityPlugin::gFacebook.ProcessEvent(event)) return;
		DBG_LOG_WARNING("sns service event not handled: %d", event.event);
		break;
#endif

#if NP_HAS_MESSAGING
	case messaging:
		if(UnityPlugin::gMessaging.ProcessEvent(event)) return;
		DBG_LOG_WARNING("messaging service event not handled: %d", event.event);
		break;
#endif



	case inGameMessage:		// A service sending in-game messages to other PSN users who are in same context.
		if(UnityPlugin::gMessaging.ProcessEvent(event)) return;
		DBG_LOG_WARNING("inGameMessage event not handled; event = %d", event.event);
		break;

	case sessions:			// A service providing sessions for invitation and session servers.
		if(UnityPlugin::gMessaging.ProcessEvent(event)) return;		// try messaging first
		if(UnityPlugin::gInvites.ProcessEvent(event)) return;		// is messaging fails, try invites
		DBG_LOG_WARNING("session event not handled; event = %d", event.event);
		break;

	case gameCustomData:	// A service providing game custom data messages to other PSN users.
		DBG_LOG_WARNING("gameCustomData event not handled; event = %d", event.event);
		break;

#if NP_HAS_NEAR
	case near:
		DBG_LOG_WARNING("near service event not handled: %d", event.event);
		break;
#endif

#if NP_HAS_TUSTSS
	case tss:
		if(UnityPlugin::gTusTss.ProcessEvent(event)) return;
		DBG_LOG_WARNING("tss service event not handled: %d", event.event);
		break;

	case tus:
		if(UnityPlugin::gTusTss.ProcessEvent(event)) return;
		DBG_LOG_WARNING("tus service event not handled: %d", event.event);
		break;
#endif

	default:
		DBG_LOG_WARNING("unknown service event not handled: %d", event.event);
		break;
	}
}


// Initialise toolkit interfaces that can no longer be constructed as a global (require external allocator to be initialised)
void InitialiseToolkitInterfaces()
{
	gCommerce = new CachedCommerce();
}



int InitializeToolkitPS4(unsigned int creationFlags, int npAgeRating)
{
	int ret = 0;

	sce::Toolkit::NP::NpTitleId nptTitleId;

	SceKernelCpumask OldAffinityMask;
	SceKernelCpumask NewAffinityMask = 0x3f;		// all cores
	scePthreadGetaffinity(scePthreadSelf(),&OldAffinityMask);

	scePthreadSetaffinity(scePthreadSelf(),NewAffinityMask);

	bool hasTrophyPack = false;
	if(g_ISceNpParams && g_ISceAppParams)
	{
		nptTitleId.setTitleSecret(*(SceNpTitleId*)g_ISceAppParams->TitleID(), *(SceNpTitleSecret*)g_ISceNpParams->NpTitleSecret());
		hasTrophyPack = g_ISceNpParams->NpHasTrophyPack();
	}
	else
	{
		// DEPRECATED; for backwards compatibility with old versions of Unity that don't support plugin interfaces.
		nptTitleId.setTitleSecret(*(SceNpTitleId*)g_AppInfo.m_TitleID, *(SceNpTitleSecret*)g_AppInfo.m_TitleSecret);
		hasTrophyPack = g_AppInfo.m_NpHasTrophyPack;
	}

	sce::Toolkit::NP::Parameters params(myNpToolkitCallback, nptTitleId);
	if(g_ISceNpParams && g_ISceAppParams)
	{
		params.m_ageRating = (npAgeRating > 0) ? npAgeRating : g_ISceNpParams->NpAgeRating();	// allow a npAgeRating of zero ... will not call sceNpSetContentRestriction()
		params.m_trial = g_ISceAppParams->IsTrialApp();
		params.m_pushNotificationFlag = g_ISceNpParams->NpPushNotifications();
	}
	else
	{
		// DEPRECATED; for backwards compatibility with old versions of Unity that don't support plugin interfaces.
		params.m_ageRating = (npAgeRating > 0) ? npAgeRating : g_AppInfo.m_NpAgeRating;	// allow a npAgeRating of zero ... will not call sceNpSetContentRestriction()
		params.m_trial = g_AppInfo.m_Trial;
		params.m_pushNotificationFlag = g_AppInfo.m_PushNotifcations;
	}
	static	const	int	ONE_MEGABYTE = (1<<20);
	params.m_sslPoolSize = ONE_MEGABYTE;
	
	ret = sce::Toolkit::NP::Interface::init(params);
	if (ret < 0 )
	{
		UnityPlugin::Messages::LogError("NP Toolkit init failed, ret = 0x%x\n", ret);
		return ret;
	}

	InitialiseToolkitInterfaces();

	// restore affinity
	scePthreadSetaffinity(scePthreadSelf(),OldAffinityMask);

#if	NP_HAS_TROPHIES
	if(hasTrophyPack)
	{
		UnityPlugin::gTrophies.RegisterTrophyPack((creationFlags & kNpToolkitCreate_CacheTrophyIcons) != 0);
		// NOTE: NP initialization isn't complete until the trophy pack registration has
		// completed (asynchronous) so we let the trophy event handler send the kNPToolKit_NPInitialized
		// message once it knows it's completed.
	}
	else
#endif
	{
		// No trophy pack to register so send the NP Initialized message now.
		UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_NPInitialized);
	}

	// only apply age rating if >0 ... this allows trophy only games to work
	if (params.m_ageRating>0)
	{
		// apply default age for content Restriction 
		SceNpContentRestriction npContentRestriction;
		npContentRestriction.size						= sizeof( SceNpContentRestriction );
		npContentRestriction.defaultAgeRestriction		= params.m_ageRating;
		npContentRestriction.ageRestrictionCount		= 0;
		npContentRestriction.ageRestriction				= NULL;
		ret = sceNpSetContentRestriction( &npContentRestriction );
		if (ret < 0 )
		{
			UnityPlugin::Messages::LogError("sceNpSetContentRestriction failed, ret = 0x%x\n", ret);
			return ret;
		}
	}

	gInitialized = true;
	return ret;
}


int InitializeToolkit(unsigned int creationFlags, int npAgeRating)
{
	if(gInitialized)
	{
		UnityPlugin::Messages::LogWarning("NP Toolkit already initialized\n");
		return 0;
	}

	// We might have previously called Shutdown, so clear the shutdown flag now.
	SetShutDown(false);

	gCreationFlags = creationFlags;

	RegisterNetCtlStatusCallback();

	SetupRuntimeInterfaces();


	return InitializeToolkitPS4(creationFlags, npAgeRating);
}

void	ShutDownToolkit( void )
{
	if( IsShuttingDown() )
	{
		return;
	}

#if defined(GLOBAL_EVENT_QUEUE)
	gSystemEventManager.Shutdown();
#endif

	SetShutDown();

	printf("Shutting down NPToolkit...\n");
	sce::Toolkit::NP::Interface::terminate();
	gInitialized = false;
}



void Update()
{
	if( IsShuttingDown() )
	{
		return;
	}
	

	UnityPlugin::gUserProfile.Update();

#if	NP_HAS_MESSAGING
	UnityPlugin::gMessaging.Update();
#endif
#if	NP_HAS_NP_DIALOGS
	UnityPlugin::gNpDialogs.Update();
#endif
#if	NP_HAS_TWITTER
	UnityPlugin::gTwitter.Update();
#endif
#if	NP_HAS_NP_COMMERCE
	UnityPlugin::gCommerce->Update();
#endif
#if	NP_HAS_INVITES
	UnityPlugin::gInvites.Update();
#endif
#if NP_HAS_NP_REQUESTS
	UnityPlugin::gRequests.Update();
#endif
}



extern "C" int module_start(SceSize sz, const void* arg)
{
	if (!ProcessPrxPluginArgs(sz, arg, "UnityNpToolkit"))
	{
		// Failed.
		return SCE_KERNEL_START_NO_RESIDENT;
	}

	return SCE_KERNEL_START_SUCCESS;
}

