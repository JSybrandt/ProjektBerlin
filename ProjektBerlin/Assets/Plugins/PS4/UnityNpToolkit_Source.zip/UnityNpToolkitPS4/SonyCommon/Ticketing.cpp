#include "Ticketing.h"
#include "SignInSony.h"
#include "MessagePipe.h"
#include "ErrorCodesSony.h"

using namespace sce::Toolkit::NP;
using namespace sce::Toolkit::NP::Utilities;

namespace UnityPlugin
{
#if NP_HAS_TICKETING
	Ticketing gTicketing;

	DO_EXPORT( bool, PrxTicketingIsBusy ) ()
	{
		return gTicketing.IsBusy();
	}

	DO_EXPORT( bool, PrxTicketingGetLastError) (ResultCode* result)
	{
		return gTicketing.GetLastError(result);
	}

	DO_EXPORT( ErrorCode, PrxTicketingRequestTicket) ()
	{
		return gTicketing.RequestTicket();
	}

	DO_EXPORT( ErrorCode, PrxTicketingRequestCachedTicket) ()
	{
		return gTicketing.RequestCachedTicket();
	}

	DO_EXPORT( ErrorCode, PrxTicketingGetTicket) (Ticket* ticket)
	{
		return gTicketing.GetTicket(ticket);
	}

	DO_EXPORT( ErrorCode, PrxTicketingGetTicketInfo) (const Ticket* ticket, TicketInfo* info)
	{
		return NP_ERR_NOT_SUPPORTED;
	}

	DO_EXPORT( ErrorCode, PrxTicketingGetEntitlementList) (const Ticket* ticket, TicketEntitlementArray* result)
	{
		return gTicketing.GetTicketEntitlementList(ticket, result);
	}


	Ticketing::Ticketing()
		: m_Busy(false)
		, m_LastResult("Ticketing")
	{
		memset(&m_Ticket, 0, sizeof(Ticket));
	}

	Ticketing::~Ticketing()
	{
	}

	bool Ticketing::ProcessEvent(const sce::Toolkit::NP::Event& event)
	{
		SimpleLock::AutoLock lock(m_Lock);
		bool handled = false;

		switch(event.event)
		{
			case Event::authGotTicket:
				// On PS3 the first time we get authGotTicket there is no result, the next
				// time there is. The PS3 SCE example gets around this by not using this event, instead it just sits in a loop
				// until hasResult() returns true. Fortunately it seems we get two authGotTicket events, one with no result, then
				// another which does have the result so all we need to do is ignore the one where there is no result (and stay busy).
				if(m_FutureTicket.hasResult())
				{
					m_Ticket.dataSize = m_FutureTicket.get()->size;
					free(m_Ticket.data);
					m_Ticket.data = (UInt8*)malloc(m_Ticket.dataSize);
					memcpy(m_Ticket.data, m_FutureTicket.get()->buffer, m_Ticket.dataSize);
					Messages::AddMessage(Messages::kNPToolKit_TicketingGotTicket);
					m_Busy = false;
				}
				handled = true;
				break;
				
			case Event::authGotCachedTicket:
				Messages::AddMessage(Messages::kNPToolKit_TicketingGotTicket);
				m_Ticket.dataSize = m_FutureTicket.get()->size;
				free(m_Ticket.data);
				m_Ticket.data = (UInt8*)malloc(m_Ticket.dataSize);
				memcpy(m_Ticket.data, m_FutureTicket.get()->buffer, m_Ticket.dataSize);
				m_Busy = false;
				handled = true;
				break;

			case Event::authError:
				m_LastResult.SetResultSCE(event.returnCode, true, __FUNCTION__, __LINE__);
				Messages::AddMessage(Messages::kNPToolKit_TicketingError);
				m_Busy = false;
				handled = true;
				break;

			default:
				UnityPlugin::Messages::LogWarning("Auth event not handled: event=%d\n", event.event);
				break;
		}

		return handled;
	}

	bool Ticketing::IsBusy()
	{
		SimpleLock::AutoLock lock(m_Lock);
		return m_Busy;
	}
	
	ErrorCode Ticketing::RequestTicket()
	{
		if(IsBusy())
		{
			return m_LastResult.SetResult(NP_ERR_BUSY, true);
		}
		SimpleLock::AutoLock lock(m_Lock);

		m_LastResult.Reset();

		m_FutureTicket.reset();
		int ret = Auth::Interface::getTicket(&m_FutureTicket);
		if (ret < 0)
		{
			return m_LastResult.SetResultSCE(ret, true, __FUNCTION__, __LINE__);
		}	
		
		m_Busy = true;
		return m_LastResult.GetResult();
	}

	ErrorCode Ticketing::RequestCachedTicket()
	{
		if(IsBusy())
		{
			return m_LastResult.SetResult(NP_ERR_BUSY, true);
		}
		SimpleLock::AutoLock lock(m_Lock);

		m_LastResult.Reset();

		int ret = Auth::Interface::getCachedTicket(&m_FutureTicket, true);
		if (ret < 0)
		{
			return m_LastResult.SetResultSCE(ret, true, __FUNCTION__, __LINE__);
		}	

		m_Busy = true;
		return m_LastResult.GetResult();
	}

	ErrorCode Ticketing::GetTicket(Ticket* ticket)
	{
		if(IsBusy())
		{
			return m_LastResult.SetResult(NP_ERR_BUSY, true);
		}
		SimpleLock::AutoLock lock(m_Lock);

		m_LastResult.Reset();

		*ticket = m_Ticket;

		return m_LastResult.GetResult();
	}


#else // Not supported

DO_EXPORT( bool, PrxTicketingIsBusy ) ()
{
	return false;
}

DO_EXPORT( bool, PrxTicketingGetLastError) (ResultCode* result)
{
	return false;
}

DO_EXPORT( ErrorCode, PrxTicketingRequestTicket) ()
{
	return NP_ERR_NOT_SUPPORTED;
}

DO_EXPORT( ErrorCode, PrxTicketingRequestCachedTicket) ()
{
	return NP_ERR_NOT_SUPPORTED;
}

DO_EXPORT( ErrorCode, PrxTicketingGetTicket) (Ticket* ticket)
{
	return NP_ERR_NOT_SUPPORTED;
}

DO_EXPORT( ErrorCode, PrxTicketingGetTicketInfo) (const Ticket* ticket, TicketInfo* info)
{
	return NP_ERR_NOT_SUPPORTED;
}

DO_EXPORT( ErrorCode, PrxTicketingGetEntitlementList) (const Ticket* ticket, TicketEntitlementArray* result)
{
	return NP_ERR_NOT_SUPPORTED;
}

#endif

}
