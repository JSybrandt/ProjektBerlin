#ifndef _TOOLKIT_H
#define _TOOLKIT_H

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>


enum NpToolkitInitFlags
{
	kNpToolkitCreate_CacheTrophyIcons = 1 << 0,
	kNpToolkitCreate_NoRanking = 1 << 1,
};

extern unsigned int gCreationFlags;

int InitializeToolkit(unsigned int creationFlags, int npAgeRating);
void Update();
void SigninConnect();
void ShutDownToolkit();

#endif
