#include "SignInSony.h"
#include "toolkit.h"
#include "UserProfileSony.h"
#include "MatchingSony.h"
#include "MessagePipe.h"
#include "ErrorCodesSony.h"

#if NP_HAS_RANKING
 #include "RankingSony.h"
#endif
using namespace sce::Toolkit::NP;
using namespace sce::Toolkit::NP::Utilities;

namespace UnityPlugin
{
	SignedInState gSignedInState;
	int gCurrentPS4UserId=0;

	DO_EXPORT( ErrorCode, PrxSignin ) ()
	{
		return gSignedInState.SignIn();
	}

	DO_EXPORT( bool, PrxSigninIsBusy ) ()
	{
		return gSignedInState.IsBusy();
	}

	DO_EXPORT( bool, PrxIsSignedIn ) ()
	{
		return gSignedInState.IsSignedIn();
	}

	DO_EXPORT( bool, PrxSigninGetLastError ) (ResultCode* result)
	{
		return gSignedInState.GetLastError(result);
	}

	DO_EXPORT( int, PrxSetCurrentUserId ) (int UserId)
	{
		int lastValue = gCurrentPS4UserId;
		gCurrentPS4UserId = UserId;
		return lastValue;
	}

	DO_EXPORT( int, PrxGetCurrentUserId ) ()
	{
		return gCurrentPS4UserId;
	}

	DO_EXPORT( int, PrxLogOutUser ) (int UserId)
	{
		return sce::Toolkit::NP::Interface::userLoggedOut(UserId);
	}

	DO_EXPORT( int, PrxGetUserSigninStatus ) (int userID, void **npid)
	{
		return gSignedInState.GetUserSigninStatus(userID, npid );
	}

	
	
	SignedInState::SignedInState()
		: m_Busy(false)
		, m_DialogOpen(false)
		, m_ApplicationSignedIn(false)
		, m_LastResult("SignIn")
	{
		memset(&m_signedInUsers, 0 ,sizeof(m_signedInUsers) );
	}

	bool SignedInState::IsBusy()
	{
		SimpleLock::AutoLock lock(m_Lock);
		return m_Busy;
	}

	ErrorCode SignedInState::SignIn()
	{
		bool TriggerSignInSuccessful = false;
		{
			if(IsBusy())
			{
				return m_LastResult.SetResult(NP_ERR_BUSY, true);
			}

			SimpleLock::AutoLock lock(m_Lock);

			if(m_DialogOpen)
			{
				return m_LastResult.SetResult(NP_ERR_BUSY, true);
			}

			m_LastResult.Reset();

			m_DialogOpen = false;	// no psn login dialog on ps4 (we do still get the Event::loggedIn though)
			m_Busy = false;
			// we don't want to trigger a sign in successfull event ... as this function does not actually signIn on ps4 (it only happens externally)
//			TriggerSignInSuccessful = true;
				
		}

		if (TriggerSignInSuccessful == true)	// this has to be done outside of the lock 
		{
			SignInSuccessful(0);
		}

		return m_LastResult.GetResult();
	}

	bool SignedInState::ProcessEvent(const sce::Toolkit::NP::Event& npevent)
	{
		SimpleLock::AutoLock lock(m_Lock);
		bool handled = false;
		
		switch(npevent.event)
		{
		case Event::loggedIn:
			// This only signifies that the user is logged into PSN, not that the application is.
			SetUserSigninStatus(npevent.userInformation);
			SignInSuccessful(npevent.userInformation.userId);
			handled = true;
			break;

		case Event::loggedOut:
			{
				SetUserSigninStatus(npevent.userInformation);
				// only sign out the application if the initial user signs out
				SceUserServiceUserId initialUserID = SCE_USER_SERVICE_USER_ID_INVALID;
				sceUserServiceGetInitialUser(&initialUserID); 
				if (npevent.userInformation.userId == initialUserID)
				{
					// only send the signedout if it's the initial user id that is signing out (this makes Sony.NP.User.IsSignedIn work)
					m_ApplicationSignedIn = false;
				}
	
				UnityPlugin::gMatching.UserSignedOut();	// User has signed out so make sure they leave any active session

				Messages::AddUserMessage(Messages::kNPToolKit_SignedOut, npevent.userInformation.userId);	
		}
			handled = true;
			break;
			
		case Event::netInfoDialogComplete:
			if(npevent.returnCode == 0)
			{
				SignInSuccessful(0);
			}
			else if(npevent.returnCode == 1)	// Dialog canceled.
			{
				m_LastResult.SetResult(NP_ERR_NOT_SIGNED_IN, true, __FUNCTION__, __LINE__);
				Messages::AddMessage(Messages::kNPToolKit_SignInError);
			}
			else
			{
				m_LastResult.SetResultSCE(npevent.returnCode, true, __FUNCTION__, __LINE__);
				Messages::AddMessage(Messages::kNPToolKit_SignInError);
			}

			m_Busy = false;
			m_DialogOpen = false;
			handled = true;
			break;

		default:
			break;
		}

		return handled;
	}


	// a user has successfully signed into PSN, the local UserId is passed in on platforms where it's relevant
	void SignedInState::SignInSuccessful(int UserId)
	{
		m_ApplicationSignedIn = true;
		Messages::AddUserMessage(Messages::kNPToolKit_SignedIn, UserId);
	}





	SceUserServiceUserId GetUserId()
	{
		if (gCurrentPS4UserId == 0)
		{
			SceUserServiceUserId userId = SCE_USER_SERVICE_USER_ID_INVALID;
			int ret = sceUserServiceGetInitialUser(&userId); 
			if( ret == 0 ) 
			{
				gCurrentPS4UserId = userId;
			} 
		}
		return gCurrentPS4UserId;
		
	}

	// hunt to see if we have a slot for this user, if we have update the status ... if we haven't find empty slot to fill with the status
	void SignedInState::SetUserSigninStatus(const sce::Toolkit::NP::UserInfo &userinfo)
	{

		int firstMatch = -1;
		int firstEmpty = -1;
		for (int i=0; i<MAX_NUM_USERS_SIGNED_IN; i++)
		{
			if (m_signedInUsers[i].userId == 0)
				firstEmpty = i;
			if (m_signedInUsers[i].userId == userinfo.userId)
				firstMatch = i;
		}

		if (firstMatch != -1)
		{
			m_signedInUsers[firstMatch] = userinfo;	// unexpected update of status ... or sign out!
			return;
		}

		if (userinfo.state == SCE_NP_STATE_SIGNED_IN)
		{
			if (firstEmpty != -1)		
			{
				m_signedInUsers[firstEmpty] = userinfo;	// do we have an empty slot for it
			}
			else
			{
				printf("no empty slots for user 0x%x\n",userinfo.userId);	// this should only happen if we don't get a signed out event message
			}
		}
	}

	int SignedInState::GetUserSigninStatus(int userID, void **outdata)
	{
		SceNpId *destnpid = NULL;
		if (outdata!= NULL)
			destnpid = (SceNpId *)*outdata;

		for (int i=0; i<MAX_NUM_USERS_SIGNED_IN; i++)
		{
			if (m_signedInUsers[i].userId == userID)
			{
				if (destnpid)
					*destnpid = m_signedInUsers[i].npId;

				return (int)m_signedInUsers[i].state;
			}
		}
		return (int)SCE_NP_STATE_UNKNOWN;
	}

	// returns a slot from 0 to MAX_NUM_USERS_SIGNED_IN for this userid
	int SignedInState::GetSignInSlotFromUserID( int userid)
	{
		for (int i=0; i<MAX_NUM_USERS_SIGNED_IN; i++)
		{
			if (m_signedInUsers[i].userId == userid)
			{
				return i;
			}
		}
		return -1;
	}



} // namespace UnityPlugin
