Unity NP Toolkit plugin extension for PS4.

NOTE: For convenience this source zip is distributed inside a unity package, before building you should move it outside of your projects assets folder to avoid the files within this source being treated as Unity assets.

Folders in this project...

PS4 - Contains a Visual Studio 2010 solution for building the native plugin.
Assemblies - Contains a MonoDevelop project which builds a managed assembly that interfaces between the native plugin and the scripts.
SonyCommon - Contains the majority of the source files(.cpp & .h) for the plugin, some others are in the PS4 folder.

Building the UnityNPToolkit native plugin.

When building the plugin the resulting module is automatically copied to the plugins folder in the example project, this is done as a post-build step by running copybuilds.bat, depending on the layout of your project you may need to edit this file to copy to the correct location.

Before building the native plugin you must first edit PS4/copybuilds.bat and make the following changes...

Set the UNITY_INTERNAL var to 0.
Set the UNITY_PROJECT_PATH var to where the plugin should be copied to, this should be the root of your Unity project.

Load UnityNpToolkit.sln into Visual Studio 2010.
Select the build configuration, debug or release.
Build the solution.

Building the managed assembly.

Before building the managed assembly you must first edit Assemblies/SonyNP/copybuilds.bat and make the following changes...
Set the UNITY_PROJECT_PATH var to where the assembly should be copied to, this should be the root of your Unity project.

Navigate to the assembly project and load the SonyNP.sln into MonoDevelop. You must use MonoDevelop, not Visual Studio for this otherwise the assembly will not work with Unity.

After building the assembly the resulting DLL is automatically copied to the example project.

This is an example native plugin for Unity that provides a wrapper to SCE's NPToolkit libraries and functionality. Full native (C++) and managed (C#) source code is provided.
Please note that this example project should not be expected to be fully TRC compliant. Planning for TRC compliance should be done early in your project to minimize risk.
The source code is provided as is : you are free to extend / specialize / amend as your project requires. 
The Unity for PlayStation Development Team will also welcome submissions / suggestions for alterations to source code if they have general ongoing utility for other developers.