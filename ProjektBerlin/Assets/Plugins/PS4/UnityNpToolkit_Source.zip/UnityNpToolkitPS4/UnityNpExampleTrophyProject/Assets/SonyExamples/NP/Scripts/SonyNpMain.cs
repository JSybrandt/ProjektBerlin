using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class SonyNpMain : MonoBehaviour, IScreen
{
	MenuStack menuStack = null;
	MenuLayout menuMain;

	SonyNpTrophy trophies;

	
    void Start()
	{
	    menuMain = new MenuLayout(this, 450, 34);
		menuStack = new MenuStack();
		menuStack.SetMenu(menuMain);

		// Register a callback for completion of NP initialization.
        Sony.NP.Main.OnNPInitialized += OnNPInitialized;

        // Initialize the NP Toolkit.
        OnScreenLog.Add("Initializing NP");

#if UNITY_PS4
		// Some PS4 Np APIs require a session image, specifically sending messages.
		string sessionImage = Application.streamingAssetsPath + "/PS4SessionImage.jpg";
		Sony.NP.Main.SetSessionImage(sessionImage);
		
		UnityEngine.PS4.PS4Input.OnUserServiceEvent = ((uint eventtype, uint userid) => 
		{
			int SCE_USER_SERVICE_EVENT_TYPE_LOGOUT = 1;
			if (eventtype == SCE_USER_SERVICE_EVENT_TYPE_LOGOUT)
				Sony.NP.User.LogOutUser((int)userid);
		} );
#endif
		
		// Enable/Disable internal logging, log messages are handled by the OnLog, OnLogWarning and OnLogError event handlers.
		Sony.NP.Main.enableInternalLogging = true;

		// Add NP event handlers.
		Sony.NP.Main.OnLog += OnLog;
		Sony.NP.Main.OnLogWarning += OnLogWarning;
		Sony.NP.Main.OnLogError += OnLogError;

		// Initialise with the age rating that was set in the editor player settings...
		//
		// NOTE: If your application does not make use of NP ranking then you must specify the
		// Sony.NP.Main.kNpToolkitCreate_NoRanking flag when initializing otherwise you will be
		// in violation of "TRC R3002 - Title calls NpScore",
		//
		// For example...
		//
		// int npCreationFlags = Sony.NP.Main.kNpToolkitCreate_CacheTrophyIcons | Sony.NP.Main.kNpToolkitCreate_NoRanking;
		// Sony.NP.Main.Initialize(npCreationFlags);
		//
		int npCreationFlags = Sony.NP.Main.kNpToolkitCreate_CacheTrophyIcons;
		Sony.NP.Main.Initialize(npCreationFlags);

		// Alternatively you can initialise with an age rating override.
		//Sony.NP.Main.InitializeWithNpAgeRating(npCreationFlagss, 12);

		// System events.
		Sony.NP.System.OnConnectionUp += OnSomeEvent;
		Sony.NP.System.OnConnectionDown += OnConnectionDown;
		Sony.NP.System.OnSysResume += OnSomeEvent;
        Sony.NP.System.OnSysNpMessageArrived += OnSomeEvent;
		Sony.NP.System.OnSysEvent += OnSomeEvent;	// Some other event.
		
       // User events.
        Sony.NP.User.OnSignedIn += OnSignedIn;
		Sony.NP.User.OnSignedOut += OnSomeEvent;
		Sony.NP.User.OnSignInError += OnSignInError;

		trophies = new SonyNpTrophy();

#if UNITY_PSP2
		// Test the upgradable/trial app flag.
		// Note that this only works with packages, when running PC Hosted skuFlags always equals 'None'.
		UnityEngine.PSVita.Utility.SkuFlags skuf = UnityEngine.PSVita.Utility.skuFlags;
		if (skuf == UnityEngine.PSVita.Utility.SkuFlags.Trial)
		{
			OnScreenLog.Add("Trial Mode, purchase the full app to get extra features.");
		}
#endif
    }


	void Update()
	{
		Sony.NP.Main.Update();
	}

    void OnNPInitialized(Sony.NP.Messages.PluginMessage msg)
    {
		OnScreenLog.Add("Begin sign in");
		Sony.NP.User.SignIn();        // NP has been fully initialized so it's now safe to sign in etc.
    }

    void MenuMain()
    {
        menuMain.Update();

		bool signedIn = Sony.NP.User.IsSignedIn;
		
		//if (menuMain.AddItem("Trophies", signedIn))
		{
			menuStack.PushMenu(trophies.GetMenu());
		}
	}

	public void OnEnter()
	{
	}

	public void OnExit()
	{
	}

	public void Process(MenuStack stack)
	{
		MenuMain();
	}

	void OnGUI()
    {
		MenuLayout activeMenu = menuStack.GetMenu();
		activeMenu.GetOwner().Process(menuStack);
    }

    void OnLog(Sony.NP.Messages.PluginMessage msg)
    {
        OnScreenLog.Add(msg.Text);
    }

    void OnLogWarning(Sony.NP.Messages.PluginMessage msg)
    {
        OnScreenLog.Add("WARNING: " + msg.Text);
    }

    void OnLogError(Sony.NP.Messages.PluginMessage msg)
    {
        OnScreenLog.Add("ERROR?: " + msg.Text);
    }

    void OnSignedIn(Sony.NP.Messages.PluginMessage msg)
    {
        OnScreenLog.Add("Signed In");

		// Determine whether or not the Vita is in flight mode, i.e. signed in but no network connection.
		Sony.NP.ResultCode result = new Sony.NP.ResultCode();
		Sony.NP.User.GetLastSignInError(out result);
		if (result.lastError == Sony.NP.ErrorCode.NP_SIGNED_IN_FLIGHT_MODE)
		{
			OnScreenLog.Add("INFO: Signed in but flight mode is on");
		}
		else if (result.lastError != Sony.NP.ErrorCode.NP_OK)
		{
			OnScreenLog.Add("Error: " + result.className + ": " + result.lastError + ", sce error 0x" + result.lastErrorSCE.ToString("X8"));
		}
    }

    void OnSomeEvent(Sony.NP.Messages.PluginMessage msg)
    {
        OnScreenLog.Add("Event: " + msg.type);
    }

	void OnConnectionDown(Sony.NP.Messages.PluginMessage msg)
	{
		OnScreenLog.Add("Connection Down");

		// Determining the reason for loss of connection...
		//
		// When connection is lost we can call Sony.NP.System.GetLastConnectionError() to obtain
		// the NetCtl error status and reason for loss of connection.
		//
		// ResultCode.lastError will be either NP_ERR_NOT_CONNECTED
		// or NP_ERR_NOT_CONNECTED_FLIGHT_MODE.
		//
		// For the case where ResultCode.lastError == NP_ERR_NOT_CONNECTED further information about
		// the disconnection reason can be inferred from ResultCode.lastErrorSCE which contains
		// the SCE NetCtl error code relating to the disconnection (please refer to SCE SDK docs when
		// interpreting this code).

		// Get the reason for loss of connection...
		Sony.NP.ResultCode result = new Sony.NP.ResultCode();
		Sony.NP.System.GetLastConnectionError(out result);
		OnScreenLog.Add("Reason: " + result.lastError + ", sce error 0x" + result.lastErrorSCE.ToString("X8"));
	}

	void OnSignInError(Sony.NP.Messages.PluginMessage msg)
	{
		Sony.NP.ResultCode result = new Sony.NP.ResultCode();
		Sony.NP.User.GetLastSignInError(out result);
		OnScreenLog.Add(result.className + ": " + result.lastError + ", sce error 0x" + result.lastErrorSCE.ToString("X8"));
	}
}
