#include "NetCtlStatus.h"
#include "MessagePipe.h"
#include "ErrorCodesSony.h"

namespace UnityPlugin
{
	int gNetCtlStatusCallbackID = 0;
	ResultCode gConnectionError = ResultCode("Connection");

	void NetCtlStatusCallback( int event_type, void* arg )
	{
		int error = SCE_OK;
		int ret = SCE_OK;
		if (event_type == SCE_NET_CTL_EVENT_TYPE_DISCONNECTED)
		{
			ret = sceNetCtlGetResult(event_type, &error);
			if (ret!= SCE_OK)
			{
				printf("NetCtlStatusCallback: Disconnected: %08x\n", error);
				return;
			}

			ErrorCode npError = NP_ERR_NOT_CONNECTED;

			gConnectionError.SetResult(npError, error, false, __FUNCTION__, __LINE__);
			UnityPlugin::Messages::AddMessage(UnityPlugin::Messages::kNPToolKit_ConnectionDown);
		}
		else if (event_type == SCE_NET_CTL_EVENT_TYPE_IPOBTAINED)
		{
			gConnectionError.Reset();
		}
	}

	void RegisterNetCtlStatusCallback()
	{
		int ret = sceNetCtlRegisterCallback(NetCtlStatusCallback, NULL, &gNetCtlStatusCallbackID);
		if(ret != SCE_OK) 
		{
			printf("ERROR: Failed to register NetCtlStatus callback\n");
		}
	}

	DO_EXPORT( bool, PrxNetCtlGetLastConnectionError )(ResultCode* result)
	{
		*result = gConnectionError;
		return gConnectionError.GetResult() == NP_OK;
	}

};
