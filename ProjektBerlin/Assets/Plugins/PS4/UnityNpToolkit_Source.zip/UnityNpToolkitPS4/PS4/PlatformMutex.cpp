#include <stdio.h>
#include "PlatformMutex.h"

namespace UnityPlugin
{
	PlatformMutex::PlatformMutex()
	{
		Create();
	}

	PlatformMutex::~PlatformMutex()
	{
		Destroy();
	}

	void PlatformMutex::Create()
	{
		if(m_Mutex)
		{
			return;
		}
		ScePthreadMutexattr attr;
		scePthreadMutexattrInit(&attr);
		scePthreadMutexattrSettype(&attr, SCE_PTHREAD_MUTEX_RECURSIVE);
		int ret = scePthreadMutexInit(&m_Mutex,&attr,"UnityPluginMutex");
		Assert(ret >= 0);
		return;
	}

	void PlatformMutex::Destroy()
	{
		SceUID ret = scePthreadMutexDestroy(&m_Mutex);
		Assert(ret == SCE_OK);
		return;
	}

	void PlatformMutex::Lock()
	{
		SceUID ret = scePthreadMutexLock(&m_Mutex);
		Assert(ret == SCE_OK);
	}

	void PlatformMutex::Unlock()
	{
		SceUID ret = scePthreadMutexUnlock(&m_Mutex);
		Assert(ret == SCE_OK);
	}


	PlatformSemaphore::PlatformSemaphore()
	{
		Create();
	}

	PlatformSemaphore::~PlatformSemaphore()
	{
		Destroy();
	}

	void PlatformSemaphore::Reset()
	{
		Destroy();
		Create();
	}

	void PlatformSemaphore::Create()
	{
		SceInt32 result = sceKernelCreateSema(&m_Semaphore, "UnityPluginSemaphore", 0, 0, 128, NULL);
		Assert(result == SCE_OK);
	}

	void PlatformSemaphore::Destroy()
	{
		SceInt32 result = sceKernelDeleteSema(m_Semaphore);
		Assert(result == SCE_OK);
	}

	void PlatformSemaphore::WaitForSignal()
	{
		SceInt32 result = sceKernelWaitSema(m_Semaphore, 1, NULL);
		Assert(!(result < SCE_OK));
	}

	void PlatformSemaphore::Signal()
	{
		SceInt32 result = sceKernelSignalSema(m_Semaphore, 1);
		Assert(!(result < SCE_OK));
	}

} //namespace UnityPlugin
