

// We need to provide an export to force the expected stub library to be generated
__declspec (dllexport) void dummy()
{
}
