
#include <np\np_signaling.h>

class SignalingContext
{

	uint32_t m_SignalingContextId;

	SceNpSignalingHandler m_SignalingHandler;
	void * m_HandlerArg;

public:
	int ActivateConnection(SceNpId *npId);
	int DeativateConnection(uint32_t commId);
	int TerminateConnection(uint32_t commId);

	int GetConnectionStatus(int connectionId, int *connStatus, int *peerAddr, int *peerPort);


	SignalingContext(SceNpId *npId, SceNpSignalingHandler handler, void * arg);
	~SignalingContext();
	void EventHandler(uint32_t ctxId, uint32_t subjectId, int event, int errorCode);
};


extern "C" __declspec (dllexport) SignalingContext * CreateContext(int userId, SceNpSignalingHandler handler, void * arg);


