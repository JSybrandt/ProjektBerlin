
#include <np\np_lookup.h>

class NpLookupContext
{

	struct LookupData
	{
		__int128 onlineId;
		SceNpId *npId;
	};

	uint32_t m_TitleContextId;
	std::map <int, LookupData > m_PendingLookupsList;
public:

	NpLookupContext(int userId);
	~NpLookupContext();

	int AddSearch(const void *onlineId, SceNpId * npId, bool Async);
	
	int PollAsync(int id);
	int Update();
};


