
#include <stdio.h>
#include <stdlib.h>
#include <np.h>
#include <libsysmodule.h>


#define PRX_EXPORT extern "C" __declspec (dllexport)



#include "signaling.h"


#if NDEBUG
#define PRINT(x,...)
#define EPRINT(x,...)
#define TRACE(x,...)
#else
#define PRINT					printf
#define EPRINT					printf("Error : %s at %d\n  ", __FILE__, __LINE__ ); \
									printf
#define TRACE					printf("-- %s, %s : %d\n", __FILE__, __FUNCTION__, __LINE__)
#endif


class SignalingSystem
{
	size_t m_poolSize;
	int32_t m_threadPriority;
	int32_t m_cpuAffinityMask;
	size_t m_threadStackSize;

public:
	SignalingSystem();
	void Init();


	static void signalingHandler(uint32_t ctxId, uint32_t subjectId, int event, int errorCode, void *arg);

};


SignalingSystem * s_SignalingSystem = NULL;


PRX_EXPORT SignalingContext * CreateContext(int userId, SceNpSignalingHandler handler, void * arg)
{
	if (s_SignalingSystem == NULL)
	{
		s_SignalingSystem = new SignalingSystem();
		s_SignalingSystem->Init();
	}


	SceNpId npId;
	if (userId == 0)
	{
		sceUserServiceGetInitialUser(&userId);
	}

	int ret = sceNpGetNpId(userId, &npId);
	if (ret < 0) 
	{
		EPRINT("unable to get npid 0x%x\n", ret);
		// Error handling
	}
//	NpLookup

	return new SignalingContext(&npId, handler, arg);
}


PRX_EXPORT int SignalingActivateConnection(void *ctx, char **npId)
{
	SignalingContext *nplCtx = (SignalingContext *)ctx;
	return nplCtx->ActivateConnection((SceNpId *)*npId);
}


PRX_EXPORT int SignalingGetConnectionStatus(void *ctx, int connectionId, int *connStatus, int *peerAddr, int *peerPort)
{
	SignalingContext *nplCtx = (SignalingContext *)ctx;
	return nplCtx->GetConnectionStatus(connectionId, connStatus, peerAddr, peerPort);
}



PRX_EXPORT int SignalingTerminateConnection(void *ctx, int connectionId)
{
	SignalingContext *nplCtx = (SignalingContext *)ctx;
	return nplCtx->TerminateConnection(connectionId);
}


SignalingSystem::SignalingSystem()
{
	m_poolSize = 0;
	m_threadPriority = 0;
	m_cpuAffinityMask = 0;
	m_threadStackSize = 0;
}

void SignalingSystem::Init(void)
{
	int res;
	res = sceSysmoduleLoadModule(SCE_SYSMODULE_NP_SIGNALING);
	if (res!= SCE_OK)
	{
		EPRINT("error during sceSysmoduleLoadModule 0x%x\n", res);
	}


	res = sceNpSignalingInitialize(m_poolSize, m_threadPriority, m_cpuAffinityMask, m_threadStackSize);
	if (res != SCE_OK)
	{
		EPRINT("error during sceNpSignalingInitialize 0x%x\n", res);
	}
}


SignalingContext::SignalingContext(SceNpId *npId, SceNpSignalingHandler handler, void * arg)
{
	m_SignalingHandler = handler;
	m_HandlerArg = arg;
	int res = sceNpSignalingCreateContext(npId, SignalingSystem::signalingHandler, (void*)this, &m_SignalingContextId);
	if (res != SCE_OK)
	{
		printf("error during sceNpSignalingInitialize 0x%x\n", res);
	}
}


SignalingContext::~SignalingContext()
{
	int res = sceNpSignalingDeleteContext(m_SignalingContextId);
	if (res != SCE_OK)
	{
		EPRINT("error during sceNpSignalingDeleteContext 0x%x\n", res);
	}
}

int SignalingContext::ActivateConnection(SceNpId *npId)
{
	uint32_t connId;

	int res = sceNpSignalingActivateConnection(m_SignalingContextId, npId, &connId);
	if (res == SCE_OK)
	{
		PRINT("[Chat.Signaling] Activating signalling connection to %s ... connId:0x%x\n", npId->handle.data, connId);
		return connId;
	}
	else
	{
		switch (res)
		{
		case SCE_NP_SIGNALING_ERROR_OWN_NP_ID:
			PRINT("[Chat.Signaling] Activating signalling connection to %s ... OWN_NP_ID aborting...\n", npId->handle.data);
			break;
		default:
			EPRINT("error during sceNpSignalingActivateConnection 0x%x\n", res);
			break;
		}
	}
	return res;
}


int SignalingContext::GetConnectionStatus(int connectionId, int *connStatus, int *peerAddr, int *peerPort)
{
	int res = sceNpSignalingGetConnectionStatus(m_SignalingContextId, connectionId, connStatus, (SceNetInAddr *)peerAddr, (SceNetInPort_t *) peerPort);
	return res;
}

int SignalingContext::DeativateConnection(uint32_t commId)
{
	int res = sceNpSignalingDeactivateConnection(m_SignalingContextId, commId);
	if (res != SCE_OK)
	{
		EPRINT("error during sceNpSignalingDeactivateConnection 0x%x\n", res);
	}
	return res;
}

int SignalingContext::TerminateConnection(uint32_t commId)
{
	int res = sceNpSignalingTerminateConnection(m_SignalingContextId, commId);
	if (res != SCE_OK)
	{
		EPRINT("error during sceNpSignalingTerminateConnection 0x%x\n", res);
	}
	return res;
}

void SignalingSystem::signalingHandler(uint32_t ctxId, uint32_t subjectId, int event, int errorCode, void *arg)
{
	SignalingContext *sigClass = (SignalingContext*)arg;
	sigClass->EventHandler(ctxId, subjectId, event, errorCode);


}


void SignalingContext::EventHandler(uint32_t ctxId, uint32_t subjectId, int eventVal, int errorCode)
{
	PRINT("signaling event ctxId:0x%x subjectId:0x%x event:0x%x errorCode:0x%x\n",
		ctxId, subjectId, eventVal, errorCode);
	if (errorCode == SCE_NP_SIGNALING_ERROR_TIMEOUT)
	{
		PRINT("... SCE_NP_SIGNALING_ERROR_TIMEOUT\n");
	}
	switch (eventVal)
	{
	case SCE_NP_SIGNALING_EVENT_DEAD:
		PRINT("SCE_NP_SIGNALING_EVENT_DEAD\n");
		break;
	case SCE_NP_SIGNALING_EVENT_ESTABLISHED:
	{
		PRINT("SCE_NP_SIGNALING_EVENT_ESTABLISHED\n");
		int connStatus;
		SceNetInAddr peerAddr;
		SceNetInPort_t peerPort;
			int res = sceNpSignalingGetConnectionStatus(ctxId, subjectId, &connStatus, &peerAddr, &peerPort);
			switch (connStatus)
			{
			case SCE_NP_SIGNALING_CONN_STATUS_INACTIVE:
				PRINT("SCE_NP_SIGNALING_CONN_STATUS_INACTIVE\n");
				break;
			case SCE_NP_SIGNALING_CONN_STATUS_PENDING:
				PRINT("SCE_NP_SIGNALING_CONN_STATUS_PENDING\n");
				break;
			case SCE_NP_SIGNALING_CONN_STATUS_ACTIVE:
				PRINT("SCE_NP_SIGNALING_CONN_STATUS_ACTIVE\n");
				break;

			}
			PRINT("sceNpSignalingGetConnectionStatus 0x%x\n", connStatus);
	}
		break;
	case SCE_NP_SIGNALING_EVENT_NETINFO_ERROR:
		PRINT("SCE_NP_SIGNALING_EVENT_NETINFO_ERROR\n");
		break;
	case SCE_NP_SIGNALING_EVENT_PEER_ACTIVATED:
		PRINT("SCE_NP_SIGNALING_EVENT_PEER_ACTIVATED\n");
		break;
	case SCE_NP_SIGNALING_EVENT_PEER_DEACTIVATED:
		PRINT("SCE_NP_SIGNALING_EVENT_PEER_DEACTIVATED\n");
		break;
	case SCE_NP_SIGNALING_EVENT_MUTUAL_ACTIVATED:
		PRINT("SCE_NP_SIGNALING_EVENT_MUTUAL_ACTIVATED\n");
		break;
	}

	switch (errorCode)
	{
	case SCE_NP_SIGNALING_ERROR_PEER_UNREACHABLE:
		PRINT("SCE_NP_SIGNALING_ERROR_PEER_UNREACHABLE\n");
	}


	if (m_SignalingHandler)
	{
		m_SignalingHandler(ctxId, subjectId, eventVal, errorCode, m_HandlerArg);
	}

}


