


#include <stdio.h>
#include <stdlib.h>

#include <libsysmodule.h>
#include <user_service.h>
#include <voice_qos.h>
#include <net.h>
#include <np\np_common.h>
#include <np\np_error.h>
#include <np_toolkit.h>

#include <string.h>
#include <map>

#include "NPLookup.h"
#include "signaling.h"


#if NDEBUG
#define PRINT(x,...)
#define EPRINT(x,...)
#define TRACE(x,...)
#else
#define PRINT					printf
#define EPRINT					printf("Error : %s at %d\n  ", __FILE__, __LINE__ ); \
									printf
#define TRACE					printf("-- %s, %s : %d\n", __FILE__, __FUNCTION__, __LINE__)
#endif


#define PRX_EXPORT extern "C" __declspec (dllexport)

PRX_EXPORT int CreateRemoteEndpoint(int ip, int port);



enum ChatDirtyMask
{
	eOnlineId = 1,		// the online id has changed and so we need to lookup the npid
	ePendingLookup = 2,	// we have issued a npid lookup and we are waiting for the result
	eStartSignaling /*NpId*/ = 4,			// the npId has changed so we need to update the signaling peerAddr/port
	ePendingSignaling = 8,	// we have waiting signaling results

	ePendingTimeout = 64,
	eChannelMembership = 128,	// the channel membership has changed, so we need to check all the connections

};


class NetChatMember
{
public:
	NetChatMember()
	{

	}
	NetChatMember(uint16_t mask)
	{
//		m_currentStatus = eIdle;
		m_remoteId = -1;
		m_connectionId = -1;
		m_peerAddr.s_addr = 0;
		m_peerPort = 0;
		m_ChannelMemberMask = mask;
		m_DirtyFlags = eOnlineId;
		m_LastError = 0;
		m_SignalingConnectionId = -1;
		m_IsLocalPlayer = false;
	}

	NetChatMember(uint16_t mask, SceNpId *NpId, SceNetInAddr peerAddr, SceNetInPort_t peerPort, int SignalingconnectionId)
	{
//		m_currentStatus = eIdle;
		m_remoteId = -1;
		m_connectionId = -1;
		m_peerAddr = peerAddr;
		m_peerPort = peerPort;
		m_ChannelMemberMask = mask;
		m_DirtyFlags = eChannelMembership;
		m_LastError = 0;
		m_IsLocalPlayer = false;
		m_NpId = *NpId;
		m_SignalingConnectionId = SignalingconnectionId;
	}

//	ChatStatus m_currentStatus;
	char m_DirtyFlags;		// see ChatDirtyMask
	bool m_IsLocalPlayer;
	SceVoiceQoSRemoteId m_remoteId;
	SceVoiceQoSConnectionId m_connectionId;		// connection id between the local machine and this person
	//	SceNpOnlineId m_OnlineId;	// this is the important bit ... char data[SCE_NP_ONLINEID_MAX_LENGTH];
	SceNpId m_NpId;
	SceNetInAddr m_peerAddr;
	SceNetInPort_t m_peerPort;
	uint16_t m_ChannelMemberMask;		// bit mask saying which channels ChatMember has joined
	int m_LastError;
	int m_LookupReqId;		// NpLookup request id when ePendingLookup is working
	int m_SignalingConnectionId;  // signaling connection id during 
	uint64_t m_TimeoutEnd;
	uint64_t m_TimeLastUpdatedFromPSN;


	void Disconnect();
	void Shutdown();
};


class NetChatSystem
{
public:
	NetChatSystem()
	{
		m_Initialised = false;
	}

	bool m_Initialised;
	
	void Initialise(int userId, int deviceInId, int deviceOutId);

	SceNetId m_chatRecvSocket;	// UDP socket waiting for data
	class NpLookupContext * m_NpLookupContext;
	class SignalingContext * m_SignalingContext;

	SceVoiceQoSLocalId m_LocalId;

	ScePthreadRwlock m_connectionLock;	// locking access to the lists
	ScePthreadRwlock m_remoteEndpointLock;	// locking access to the lists
	ScePthreadRwlock m_membersLock;	// locking access to the lists

	std::map <SceVoiceQoSRemoteId, SceVoiceQoSConnectionId > m_connectionList;
	std::map <SceVoiceQoSRemoteId, SceNetSockaddr> m_remoteEndpointList;
	std::map<__int128, NetChatMember> m_NetChatMembers;	// map of online id (stored as a 128bit value to NetChatMember class

	uint64_t m_TimeLastUpdatedFromPSN;

	static const int InputBufferSize = 8192;
	char m_InputBuffer[InputBufferSize];

	static const int SendBufferSize = 8192;
	char m_SendBuffer[SendBufferSize];

	void *NetChatRecv();

	void NetChatUpdate(void);
	void NetChatSendUpdate(void);
	void NetMemberUpdate(void);

	int CreateLocalEndpoint(int userId, int deviceInId, int deviceOutId);

	int CreateRemoteEndpoint(int ip, int port);
	int CreateRemoteEndpoint(SceNetSockaddr *remoteAddress);

	void signalHandler(uint32_t ctxId, uint32_t subjectId, int ievent, int errorCode);

	void UpdateNetChatMember(__int128 onlineId, uint16_t channelMask);
	void UpdateNetChatMember(__int128 onlineId, sce::Toolkit::NP::SessionMember * memberInfo, uint16_t channelMask);
	void DisconnectNetChatMember(__int128 onlineId);
	void RemoveNetChatMember(__int128 onlineId);



	SceVoiceQoSConnectionId GetConnectionIdFromAddr(SceNetSockaddr *addr);
};


NetChatSystem s_NetChat;


// entry function called upon start processing 
extern "C" int module_start(size_t argc, const void*argv)
{
	PRINT("netchat plugin started\n");

	int res = 0;

	return res;
}




void NetChatMember::Disconnect()
{
	NetChatSystem * Netchat = &s_NetChat;
	PRINT("NetChatMember Disconnect\n");
	if (m_connectionId != -1)
	{
		SceVoiceQoSError res = sceVoiceQoSDisconnect(m_connectionId);
		if (res != SCE_OK)
		{
			EPRINT("sceVoiceQoSDisconnect failed 0x%x\n", res);
		}
		m_connectionId = -1;
	}

	if (m_remoteId != -1)
	{
		scePthreadRwlockWrlock(&Netchat->m_connectionLock);
		auto connection = Netchat->m_connectionList.find(m_remoteId);
		if (connection != Netchat->m_connectionList.end())
		{
			Netchat->m_connectionList.erase(connection);
		}
		else
		{
			EPRINT("shutdown: remote id 0x%x not found in connection list\n", m_remoteId);
		}
		scePthreadRwlockUnlock(&Netchat->m_connectionLock);

		scePthreadRwlockWrlock(&Netchat->m_remoteEndpointLock);
		auto signalAddress = Netchat->m_remoteEndpointList.find(m_remoteId);
		if (signalAddress != Netchat->m_remoteEndpointList.end())
		{
			Netchat->m_remoteEndpointList.erase(signalAddress);
		}
		else
		{
			EPRINT("shutdown: remote id 0x%x not found in remoteEndpointList list\n", m_remoteId);
		}
		scePthreadRwlockUnlock(&Netchat->m_remoteEndpointLock);

		sceVoiceQoSDeleteLocalEndpoint(m_remoteId);
		m_remoteId = -1;

	}

	m_peerAddr.s_addr = 0;
	m_peerPort = 0;
	m_SignalingConnectionId = -1;

	m_DirtyFlags |= eStartSignaling;		// go back to attempting to signal 

}


void NetChatMember::Shutdown()
{
	Disconnect();
	m_DirtyFlags = 0;
}

void NetChatSystem::UpdateNetChatMember(__int128 onlineId, uint16_t channelMask)
{
	auto member = m_NetChatMembers.find(onlineId);
	if (member == m_NetChatMembers.end())
	{
		m_NetChatMembers.emplace(onlineId, channelMask);		// creates in place using constructor NetChatMember(mask)
	}
	else
	{
		if (member->second.m_ChannelMemberMask == channelMask)		// if mask hasn't changed we don't need to update
			return;

		member->second.m_ChannelMemberMask = channelMask;
		member->second.m_DirtyFlags |= eChannelMembership;
	}
}


void NetChatSystem::UpdateNetChatMember(__int128 onlineId, sce::Toolkit::NP::SessionMember * memberInfo, uint16_t channelMask)
{
	auto member = m_NetChatMembers.find(onlineId);
	if (member == m_NetChatMembers.end())
	{

		bool useNPToolkitSignalling = false;		// if true we can use the signaling connection data from nptoolkit (doesn't seem to work)

		NetChatMember ChatMember(channelMask, &memberInfo->userInfo, memberInfo->memberConnInfo.addr, memberInfo->memberConnInfo.port, -1);

		if ((useNPToolkitSignalling == false) || (memberInfo->memberConnInfo.addr.s_addr == 0) || (memberInfo->memberConnInfo.port == 0))
		{
			PRINT("no connection info ... commencing signaling\n");
			ChatMember.m_DirtyFlags = eStartSignaling;		// do signaling
		}
		else
		{
			// no need for signalling
			PRINT("connection info found ... no need for signaling\n");
			ChatMember.m_remoteId = CreateRemoteEndpoint(ChatMember.m_peerAddr.s_addr, ChatMember.m_peerPort);
		}
		ChatMember.m_TimeLastUpdatedFromPSN = m_TimeLastUpdatedFromPSN;
		m_NetChatMembers.insert(std::pair<__int128, NetChatMember>(onlineId, ChatMember));
	}
	else
	{
		member->second.m_TimeLastUpdatedFromPSN = m_TimeLastUpdatedFromPSN;
		if (member->second.m_ChannelMemberMask == channelMask)		// if mask hasn't changed we don't need to update
			return;

		member->second.m_ChannelMemberMask = channelMask;
		member->second.m_DirtyFlags |= eChannelMembership;
	}
}

PRX_EXPORT void UpdateNetChatSessionInformation(void * sessionInfoPtr)
{
	sce::Toolkit::NP::SessionInformation * sessionInfo = (sce::Toolkit::NP::SessionInformation *)sessionInfoPtr;
	// should we have to make a local copy of the data ...?

	// timestamp so we can tell which ones need removing
	s_NetChat.m_TimeLastUpdatedFromPSN = sceKernelGetProcessTime();

	for (int i = 0; i < sessionInfo->numMembers; i++)
	{
		__int128 iOnlineId = 0;

		sce::Toolkit::NP::SessionMember * member = &sessionInfo->memberData[i];
		PRINT("[Chat] processing member %d of %d [%s]\n", i, sessionInfo->numMembers, member->userInfo.handle.data);
		strncpy((char *)&iOnlineId, member->userInfo.handle.data, SCE_NP_ONLINEID_MAX_LENGTH);

		uint16_t channelMask = 0x1;
		s_NetChat.UpdateNetChatMember(iOnlineId, member, channelMask);
	}

	auto member = std::begin(s_NetChat.m_NetChatMembers);
	while (member != std::end(s_NetChat.m_NetChatMembers))
	{
		// if we didn't update the member in this session information ... then he must have gone from the PSN session
		if (member->second.m_TimeLastUpdatedFromPSN != s_NetChat.m_TimeLastUpdatedFromPSN)
		{
			PRINT("[Chat] removing member from chat [%s]\n", member->second.m_NpId.handle.data);
			member->second.Shutdown();
			s_NetChat.m_NetChatMembers.erase(member++);
		}
		else
		{
			++member;
		}
	}

}


PRX_EXPORT void UpdateNetChatMember(const char *onlineId, int channelMask)
{
	__int128 iOnlineId = 0;
	strncpy((char *)&iOnlineId, onlineId, SCE_NP_ONLINEID_MAX_LENGTH);
	s_NetChat.UpdateNetChatMember(iOnlineId, (uint16_t)channelMask);
}

void NetChatSystem::DisconnectNetChatMember(__int128 onlineId)
{
	auto member = m_NetChatMembers.find(onlineId);
	if (member == m_NetChatMembers.end())
	{

	}
	else
	{
		member->second.Disconnect();
	}
}
PRX_EXPORT void DisconnectNetChatMember(const char *onlineId)
{
	__int128 iOnlineId = 0;
	strncpy((char *)&iOnlineId, onlineId, SCE_NP_ONLINEID_MAX_LENGTH);
	s_NetChat.DisconnectNetChatMember(iOnlineId);
}




void NetChatSystem::RemoveNetChatMember(__int128 onlineId)
{
	auto member = m_NetChatMembers.find(onlineId);
	if (member == m_NetChatMembers.end())
	{

	}
	else
	{
		member->second.Shutdown();
		m_NetChatMembers.erase(member);
	}
}

PRX_EXPORT void RemoveNetChatMember(const char *onlineId)
{
	__int128 iOnlineId = 0;
	strncpy((char *)&iOnlineId, onlineId, SCE_NP_ONLINEID_MAX_LENGTH);
	s_NetChat.RemoveNetChatMember(iOnlineId);
}



PRX_EXPORT void RemoveAllNetChatMembers()
{
	auto member = std::begin(s_NetChat.m_NetChatMembers);
	while (member != std::end(s_NetChat.m_NetChatMembers))
	{
		member->second.Shutdown();
		s_NetChat.m_NetChatMembers.erase(member++);
	}
}

SceVoiceQoSConnectionId NetChatSystem::GetConnectionIdFromAddr(SceNetSockaddr *addr)
{
	SceNetSockaddrIn *addrIn = (SceNetSockaddrIn *)addr;
	int ConnectionCount = 0;
	scePthreadRwlockRdlock(&m_remoteEndpointLock);
	for (auto & remoteEndpoint : m_remoteEndpointList)
	{
		SceNetSockaddrIn *addrRemote = (SceNetSockaddrIn *)&remoteEndpoint.second; 
		ConnectionCount++;
		if (addrIn->sin_addr.s_addr == addrRemote->sin_addr.s_addr)
		{
			if (addrIn->sin_port == addrRemote->sin_port)
			{
				scePthreadRwlockRdlock(&m_connectionLock);
				auto connection = m_connectionList.find(remoteEndpoint.first);
				if (connection == m_connectionList.end())
				{
					scePthreadRwlockUnlock(&m_connectionLock);
					EPRINT("no connection match found\n");
				}
				else
				{
					SceVoiceQoSConnectionId result = connection->second;
					scePthreadRwlockUnlock(&m_connectionLock);
					scePthreadRwlockUnlock(&m_remoteEndpointLock);
//					PRINT("connection match found!\n");

					return (result);
				}
			}
		}
	}
	scePthreadRwlockUnlock(&m_remoteEndpointLock);

	EPRINT("GetConnectionIdFromAddr failed, tested ip 0x%x on %d connections\n", addrIn->sin_addr.s_addr, ConnectionCount);
	return 0;
}

// we have to becareful we don't get confused with the polling method of checking signalling
void NetChatSystem::signalHandler(uint32_t ctxId, uint32_t subjectId, int ievent, int errorCode)
{
	// disconnect member if we get a loss of signaling, placed member in a state to retry signaling
	if (ievent == SCE_NP_SIGNALING_EVENT_DEAD)
	{
		uint32_t signalingConnectionId = subjectId;

		auto member = std::begin(m_NetChatMembers);
		while (member != std::end(m_NetChatMembers))
		{
			if (member->second.m_SignalingConnectionId == signalingConnectionId)
			{
				if (member->second.m_DirtyFlags & ePendingSignaling)
				{
					PRINT("awaiting a signaling result ... not disconnecting\n");
				}
				else
				{
					member->second.Disconnect();
				}
			}
			++member;
		}
	}

#if(0)
	// attempt to create a connection just based on a received signaling event ... we get a peer activated, but not sure how to respond
	if (ievent == SCE_NP_SIGNALING_EVENT_PEER_ACTIVATED)
	{
		PRINT("receivent peer activated signal\n");
	}
	
	if (ievent == SCE_NP_SIGNALING_EVENT_MUTUAL_ACTIVATED)
	{
		uint32_t signalingConnectionId = subjectId;
		SceNetInAddr peerAddr;
		SceNetInPort_t peerPort;
		int connStatus;
		int res = sceNpSignalingGetConnectionStatus(ctxId, signalingConnectionId, &connStatus, &peerAddr, &peerPort);
		if (res != SCE_OK)
		{
			EPRINT("sceNpSignalingGetConnectionStatus returned 0x%x\n", res);
			return;
		}
		if (connStatus == SCE_NP_SIGNALING_CONN_STATUS_ACTIVE)
		{
			auto member = std::begin(s_NetChatMembers);
			while (member != std::end(s_NetChatMembers))
			{
				if (member->second.m_SignalingConnectionId == signalingConnectionId)
				{
					PRINT("SCE_NP_SIGNALING_EVENT_PEER_ACTIVATED called from an already existing connecion\n");
					return;
				}
				++member;
			}
			SceNpSignalingConnectionInfo info;
			res = sceNpSignalingGetConnectionInfo(ctxId, signalingConnectionId, SCE_NP_SIGNALING_CONN_INFO_PEER_NPID, &info);
			if (res != SCE_OK)
			{
				EPRINT("sceNpSignalingGetConnectionInfo returned 0x%x\n", res);
			}
			uint16_t defaultChannelMask = 0x1;
			__int128 iOnlineId = 0;
			strncpy((char *)&iOnlineId, info.npId.handle.data, SCE_NP_ONLINEID_MAX_LENGTH);
			//	NetChatMember(uint16_t mask, SceNpId *NpId, SceNetInAddr peerAddr, SceNetInPort_t peerPort, int SignalingconnectionId)
			// chat with someone based on the fact they have been signalling us
			NetChatMember ChatMember(defaultChannelMask, &info.npId, peerAddr, peerPort, signalingConnectionId);
			ChatMember.m_remoteId = CreateRemoteEndpoint(ChatMember.m_peerAddr.s_addr, ChatMember.m_peerPort);
			s_NetChatMembers.insert(std::pair<__int128, NetChatMember>(iOnlineId, ChatMember));
		}

	}
#endif
}


uint16_t localChannelMembership = 1;		// TODO: implement correctly

void NetChatSystem::NetMemberUpdate(void)
{

	bool ConfirmAllConnections = false;	// if the local player has changed his channels, then we have to re-confiem all the connections on this machine to other players

	for (auto &member : m_NetChatMembers)
	{
		if (member.second.m_IsLocalPlayer)
		{
			if (member.second.m_DirtyFlags&eChannelMembership)
				ConfirmAllConnections = true;
			break;
		}
	}

	for (auto &member : m_NetChatMembers)
	{
		// if any of the dirty flags are set, then we have work to do
		if (member.second.m_DirtyFlags)
		{
			NetChatMember & chatMember = member.second;
			auto onlineId = member.first;

			// if we are waiting for a timeout ... then don't do anything else
			if (chatMember.m_DirtyFlags & ePendingTimeout)
			{
				if (sceKernelGetProcessTime() > chatMember.m_TimeoutEnd)
				{
					PRINT("timeout ending ... dirtflags:0x%x\n", chatMember.m_DirtyFlags);
					chatMember.m_DirtyFlags &= ~ePendingTimeout;
				}
				continue;	// don't do anymore work
			}


			if (chatMember.m_DirtyFlags & eOnlineId)
			{
				chatMember.m_DirtyFlags &= ~eOnlineId;
				int res = m_NpLookupContext->AddSearch(&onlineId, &chatMember.m_NpId, true);
				if (res < 0)
				{
					EPRINT("lookup failed 0x%x\n", res);
					chatMember.m_LastError = res;
				}
				else
				{
					chatMember.m_LookupReqId = res;
					chatMember.m_DirtyFlags |= ePendingLookup;
				}
			}

			if (chatMember.m_DirtyFlags & ePendingLookup)
			{
				
				int res = m_NpLookupContext->PollAsync(chatMember.m_LookupReqId);
				if (res == SCE_NP_LOOKUP_POLL_ASYNC_RET_RUNNING)
					continue;

				chatMember.m_LookupReqId = -1;
				chatMember.m_DirtyFlags &= ~ePendingLookup;

				if (res == SCE_NP_LOOKUP_POLL_ASYNC_RET_FINISHED)
				{
					PRINT("we have a good npid ... preceeding with signalling\n");
					chatMember.m_DirtyFlags |= eStartSignaling;		// we have a good npid
				}
				else
				{
					EPRINT("lookup failed 0x%x\n", res);
					chatMember.m_LastError = res;
				}
			}


			if (chatMember.m_DirtyFlags & eStartSignaling)
			{
				chatMember.m_DirtyFlags &= ~eStartSignaling;
				int res = m_SignalingContext->ActivateConnection(&chatMember.m_NpId);
				if (res < 0)
				{
					if (res == SCE_NP_SIGNALING_ERROR_OWN_NP_ID)
					{
						chatMember.m_IsLocalPlayer = true;
					}
					else
					{
						EPRINT("signaling unable to activate 0x%x\n", res);
					}
				}
				else
				{
					chatMember.m_IsLocalPlayer = false;

					chatMember.m_SignalingConnectionId = res;
					chatMember.m_DirtyFlags |= ePendingSignaling;
				}
			}


			if (chatMember.m_DirtyFlags & ePendingSignaling)
			{
				int connStatus = 0;
				int peerAddr;
				int peerPort;
				int res = m_SignalingContext->GetConnectionStatus(chatMember.m_SignalingConnectionId, &connStatus, &peerAddr, &peerPort);
				if (res < 0)
				{
					EPRINT("signaling errored with 0x%x\n", res);
					chatMember.m_DirtyFlags &= ~ePendingSignaling;
				}
				else
				{
					if (connStatus == SCE_NP_SIGNALING_CONN_STATUS_PENDING)
						continue;

					if (connStatus == SCE_NP_SIGNALING_CONN_STATUS_INACTIVE)
					{
						PRINT("signaling failed  ... 10 second timeout\n");
						chatMember.m_TimeoutEnd = sceKernelGetProcessTime() + (10 * 1000 * 1000);		// retry in 10 seconds
						chatMember.m_DirtyFlags &= ~ePendingSignaling;
						chatMember.m_DirtyFlags |= ePendingTimeout;		// wait for the timeout
						chatMember.m_DirtyFlags |= eStartSignaling;				// then re-start the signalling

					}
					else
					{
						PRINT("[Chat] signaling completed successfully\n");
						chatMember.m_DirtyFlags &= ~ePendingSignaling;

						chatMember.m_peerAddr.s_addr = peerAddr;
						chatMember.m_peerPort = (SceNetInPort_t)peerPort;

						chatMember.m_DirtyFlags |= eChannelMembership;		// rebuild connection matrix based in channel membership

						if (chatMember.m_remoteId == -1)
						{
							chatMember.m_remoteId = CreateRemoteEndpoint(chatMember.m_peerAddr.s_addr, chatMember.m_peerPort);
							PRINT("[Chat]  RemoteEndpoint Id created 0x%x\n", chatMember.m_remoteId);
						}
						else
						{
							PRINT("remote endpoint already created : 0x%x\n", chatMember.m_remoteId);
						}



					}
				}

				

			}

			// 
			if ((chatMember.m_DirtyFlags & eChannelMembership) || (ConfirmAllConnections))
			{
				chatMember.m_DirtyFlags &= ~eChannelMembership;
				if (chatMember.m_IsLocalPlayer)
				{
					// if this is all about us, then what do we do?
					continue;
				}

				if (chatMember.m_peerAddr.s_addr == 0)	// no signaling address
				{
					continue;
				}
				// do we want a connection with between the local machine and this player ?


				bool RequireConnection = false;
				if (localChannelMembership & chatMember.m_ChannelMemberMask)
					RequireConnection = true;

				scePthreadRwlockRdlock(&m_connectionLock);

				auto connection = m_connectionList.find(chatMember.m_remoteId);
				if (connection == m_connectionList.end())
				{
					PRINT("[Chat] no VoiceQoS connection found for remoteId 0x%x\n", chatMember.m_remoteId);
					if (RequireConnection)
					{
						if (chatMember.m_remoteId == -1)
						{
							chatMember.m_remoteId = CreateRemoteEndpoint(chatMember.m_peerAddr.s_addr, chatMember.m_peerPort);
							PRINT("[Chat] remote id created 0x%x\n", chatMember.m_remoteId);
						}
						PRINT("[Chat] Creating VoiceQoS connection localid:0x%x remoteId:0x%x\n", m_LocalId, chatMember.m_remoteId);
						SceVoiceQoSError res = sceVoiceQoSConnect(&chatMember.m_connectionId, m_LocalId, chatMember.m_remoteId);
						if (res == SCE_OK)
						{
							printf("unlock read lock\n");
							scePthreadRwlockUnlock(&m_connectionLock);
							printf("entering rw connection lock\n");
							scePthreadRwlockWrlock(&m_connectionLock);
							m_connectionList.insert({ chatMember.m_remoteId, chatMember.m_connectionId });		// c++11 method of inserting into maps
							scePthreadRwlockUnlock(&m_connectionLock);

							PRINT("[Chat] Created VoiceQoS connection connectionId:0x%x\n", chatMember.m_connectionId);

							printf("relocking read lock\n");
							scePthreadRwlockRdlock(&m_connectionLock);
						}
						else
						{
							if (res == SCE_VOICE_ERROR_PORT_INVALID)
							{
								PRINT("sceVoiceQoSConnect failed with SCE_VOICE_ERROR_PORT_INVALID, localid:0x%x remoteId:0x%x\n", m_LocalId, chatMember.m_remoteId);
							}
							else
							{
								PRINT("error during sceVoiceQoSConnect 0x%x\n", res);
							}
						}
					}
				}
				else
				{
					if (!RequireConnection)
					{
						SceVoiceQoSError res = sceVoiceQoSDisconnect(connection->second);
						if (res != SCE_OK)
						{
							EPRINT("error during sceVoiceQoSDisconnect 0x%x\n", res);
						}
						chatMember.m_connectionId = -1;

						PRINT("unlock read lock\n");
						scePthreadRwlockUnlock(&m_connectionLock);

						scePthreadRwlockWrlock(&m_connectionLock);
						m_connectionList.erase(connection);
						scePthreadRwlockUnlock(&m_connectionLock);

						PRINT("relocking read lock\n");
						scePthreadRwlockRdlock(&m_connectionLock);

					}
				}

				scePthreadRwlockUnlock(&m_connectionLock);

			}
		}
	}
}


void NetChatSystem::NetChatSendUpdate(void)
{
//	PRINT("[Chat.Send] update\n");
	scePthreadRwlockRdlock(&m_connectionLock);
	for (auto const &connection : m_connectionList)
	{
		unsigned int size = SendBufferSize;
		int res = sceVoiceQoSReadPacket(connection.second, m_SendBuffer, &size);
		if (res < 0)
		{
			if (res == SCE_VOICE_ERROR_LIBVOICEQOS_ARGUMENT_INVALID)
			{
				EPRINT("sceVoiceQoSReadPacket returned LIBVOICEQOS_ARGUMENT_INVALID id:0x%x\n", connection.second);
			}
			else
			{
				EPRINT("sceVoiceQoSReadPacket failed 0x%x\n", res);
			}
		}
		else
		{
			if (size > 0)
			{
//				PRINT("[Chat.Send] sending voice packet, size:%d\n", size);
				SceVoiceQoSRemoteId RemoteId = connection.first;

				scePthreadRwlockRdlock(&m_remoteEndpointLock);
				auto it = m_remoteEndpointList.find(RemoteId);
				bool found = (it == m_remoteEndpointList.end());
				scePthreadRwlockUnlock(&m_remoteEndpointLock);

				if (found)
				{
					scePthreadRwlockUnlock(&m_remoteEndpointLock);
					EPRINT("no endpoint found in connection list, 0x%x\n", RemoteId);
				}
				else
				{
					int flags = 0;
					SceNetSocklen_t addrlen = sizeof(SceNetSockaddr);

					SceNetSockaddr * sockAddr = &it->second;
#if !NDEBUG
//					SceNetSockaddrIn * sockAddrIn = (SceNetSockaddrIn *)sockAddr;
//					PRINT("to ip:0x%x port:0x%x\n", sockAddrIn->sin_addr.s_addr, sockAddrIn->sin_port);
#endif
					res = sceNetSendto(m_chatRecvSocket, m_SendBuffer, size, flags, sockAddr, addrlen);
					if (res != size)
					{
						EPRINT("exepected error calling sceNetSendto, 0x%x\n", res);
					}

				}
			}
		}
	}

	scePthreadRwlockUnlock(&m_connectionLock);
}


void NetChatSystem::NetChatUpdate(void)
{
	NetMemberUpdate();
	NetChatSendUpdate();		// send data over network if some is available
}



void *NetChatRecv(void *threadInputData)
{
	NetChatSystem * NetChat = (NetChatSystem *)threadInputData;
	return NetChat->NetChatRecv();
}


void *NetChatSystem::NetChatRecv()
{
	PRINT("Chat.Recvthread\n");
	while (1)
	{
		int flags = 0;
		SceNetSockaddr addr;
		SceNetSocklen_t addrlen = sizeof(SceNetSockaddr);

		int res = sceNetRecvfrom(m_chatRecvSocket, m_InputBuffer, InputBufferSize, flags, &addr, &addrlen);
//		PRINT("Chat.Recvthread sceNetRecvfrom returned:0x%x\n", res);
		if (res < 0)
		{
			if (res == SCE_NET_ERROR_EWOULDBLOCK)	// timeout, check to see if there is anything to send
			{
				NetChatUpdate();
			}
			else
			{
				EPRINT("sceNetRecvfrom returned 0x%x\n", res);
			}

		}
		else
		{
			static int s_numTotalDataSize = 0;
			static int s_numPacketsIn = 0;

			s_numTotalDataSize += res;
			if (((s_numPacketsIn++) % 100)==0)
			{
				PRINT("[Chat.Recv] Recevied %d chat packets, avg size:%d\n", s_numPacketsIn, s_numTotalDataSize / s_numPacketsIn);
			}
			

			SceVoiceQoSConnectionId connectionId = GetConnectionIdFromAddr(&addr);
			unsigned int size = res;
			res = sceVoiceQoSWritePacket(connectionId, m_InputBuffer, &size);
			if (res < 0)
			{
				EPRINT("sceVoiceQoSWritePacket failed 0x%x\n", res);
			}
			else
			{
//				PRINT("sceVoiceQoSWritePacket wrote 0x%x bytes\n", size);
			}
		}
	}


	return NULL;
}



#define VOICECHAT_VPORT (12345)

const static int s_sendingInterval = 100;		// time to wait after which we check for outgoing chat


void Handler(uint32_t ctxId, uint32_t subjectId, int ievent, int errorCode, void *arg)
{
	NetChatSystem * netChat = (NetChatSystem *)arg;

	netChat->signalHandler(ctxId, subjectId, ievent, errorCode);
}


PRX_EXPORT int  InitialiseNetChat(int userId, int deviceInId, int deviceOutId)
{
	int res;
	if (userId == 0)
	{
		res = sceUserServiceGetInitialUser(&userId);
	}

	if (s_NetChat.m_Initialised == true)
	{
		return SCE_OK;
	}
	res = sceSysmoduleLoadModule(SCE_SYSMODULE_VOICEQOS);
	if (res != SCE_OK)
	{
		PRINT("NetChat: failed to load SCE_SYSMODULE_VOICEQOS : 0x%x\n", res);
		return res;
	}
	uint32_t memSize = SCE_VOICE_MEMORY_CONTAINER_SIZE;
	void *pMemBlock = malloc(memSize);
	int32_t appType = SCE_VOICE_APPTYPE_GAME_V2;

	res = sceVoiceQoSInit(pMemBlock, memSize, appType);
	if (res != SCE_OK)
	{
		PRINT("NetChat: sceVoiceQoSInit failed: 0x%x\n", res);

	}

	s_NetChat.m_chatRecvSocket = sceNetSocket("NetChatRecv", SCE_NET_AF_INET, SCE_NET_SOCK_DGRAM_P2P, 0);

	SceNetSockaddrIn addr;
	memset(&addr, 0, sizeof(SceNetSockaddrIn));
	addr.sin_len = sizeof(SceNetSockaddrIn);
	addr.sin_family = SCE_NET_AF_INET;
	addr.sin_port = sceNetHtons(SCE_NP_PORT);
	addr.sin_vport = sceNetHtons(VOICECHAT_VPORT);
//	addr.sin_addr = SCE_NET_INADDR_ANY;


	res = sceNetBind(s_NetChat.m_chatRecvSocket, (const SceNetSockaddr *)&addr, sizeof(SceNetSockaddrIn));
	if (res != 0)
	{
		EPRINT("sceNetBind failed 0x %x\n", res);
	}


	int level = SCE_NET_SOL_SOCKET;
	int optname = SCE_NET_SO_RCVTIMEO;
	int optval = s_sendingInterval;
	res = sceNetSetsockopt(s_NetChat.m_chatRecvSocket, level, optname, &optval, sizeof(optval));
	if (res != 0)
	{
		EPRINT("SO_RCVTIMEO failed 0x %x\n", res);
	}


	// Creating a thread to receive the data
	ScePthreadAttr threadattr;
	scePthreadAttrInit(&threadattr);
	scePthreadAttrSetstacksize(&threadattr, 1024 * 1024);
	//	scePthreadAttrSetinheritsched(&threadattr, SCE_PTHREAD_EXPLICIT_SCHED);
	//	scePthreadAttrSetschedpolicy(&threadattr, SCE_KERNEL_SCHED_RR);
	scePthreadAttrSetaffinity(&threadattr, 63);

	ScePthread NetChatRecvThread;
	res = scePthreadCreate(&NetChatRecvThread, &threadattr, NetChatRecv, (void *)&s_NetChat, "NetChatRecv");
	scePthreadAttrDestroy(&threadattr);

	s_NetChat.Initialise(userId, deviceInId, deviceOutId);

	return SCE_OK;
}


void NetChatSystem::Initialise(int userId, int deviceInId, int deviceOutId)
{
	ScePthreadRwlockattr rwAttr;
	scePthreadRwlockattrInit(&rwAttr);


	scePthreadRwlockInit(&m_connectionLock, &rwAttr, "chat_connection_lock");
	scePthreadRwlockInit(&m_remoteEndpointLock, &rwAttr, "chat_remoteEndpoint_lock");
	scePthreadRwlockInit(&m_membersLock, &rwAttr, "chat_member_lock");

	scePthreadRwlockattrDestroy(&rwAttr);

	m_NpLookupContext = new NpLookupContext(userId);
	m_SignalingContext = CreateContext(userId, Handler, &s_NetChat);

	CreateLocalEndpoint(userId, deviceInId, deviceOutId);



	m_Initialised = true;
}

int NetChatSystem::CreateLocalEndpoint(int userId, int deviceInId, int deviceOutId)
{
	SceVoiceQoSRemoteId localId;	
	SceVoiceQoSError result = sceVoiceQoSCreateLocalEndpoint(&localId, userId, deviceInId, deviceOutId);
	if (result == SCE_OK)
	{
		m_LocalId = localId;
		return localId;
	}
	else
	{
		EPRINT("sceVoiceQoSCreateLocalEndpoint failed 0x%x\n", result);
	}
	return result;
}


int NetChatSystem::CreateRemoteEndpoint(SceNetSockaddr *remoteAddress)
{
	SceVoiceQoSRemoteId remoteId;	// remote endpoint identifier
	SceVoiceQoSError result = sceVoiceQoSCreateRemoteEndpoint(&remoteId);
	if (result == SCE_OK)
	{
		scePthreadRwlockWrlock(&m_remoteEndpointLock);
		m_remoteEndpointList.insert({ remoteId, *remoteAddress });		// c++11 method of inserting into maps
		scePthreadRwlockUnlock(&m_remoteEndpointLock);

		return remoteId;
	}
	return result;
}

int NetChatSystem::CreateRemoteEndpoint(int ip, int port)
{

	SceNetSockaddrIn addr;
	memset(&addr, 0, sizeof(SceNetSockaddrIn));
	addr.sin_len = sizeof(SceNetSockaddrIn);
	addr.sin_family = SCE_NET_AF_INET;
	addr.sin_port = port;		//sin_port: Port number actually opened by the recipient as seen from the internet
	addr.sin_vport = sceNetHtons(VOICECHAT_VPORT);	//sin_vport: Port number specified by the application
	addr.sin_addr.s_addr = ip;

	return CreateRemoteEndpoint((SceNetSockaddr*)&addr);
}

PRX_EXPORT int CreateRemoteEndpoint(int ip, int port)
{
	return s_NetChat.CreateRemoteEndpoint(ip, port);
}



PRX_EXPORT int DeleteRemoteEndpoint(int remoteEndpointId)
{
	SceVoiceQoSError result = sceVoiceQoSDeleteRemoteEndpoint(remoteEndpointId);
	return result;
}


PRX_EXPORT int Connect(int localEndpointId, int remoteEndpointId)
{
	SceVoiceQoSConnectionId ConnectionId;
	SceVoiceQoSError result = sceVoiceQoSConnect(&ConnectionId, localEndpointId, remoteEndpointId);
	if (result == SCE_OK)
	{
		s_NetChat.m_connectionList.insert({ remoteEndpointId, ConnectionId });		// c++11 method of inserting into maps
		return ConnectionId;
	}
	return result;
}


PRX_EXPORT int Disconnect(int connectionId)
{
	return sceVoiceQoSDisconnect(connectionId);
}




