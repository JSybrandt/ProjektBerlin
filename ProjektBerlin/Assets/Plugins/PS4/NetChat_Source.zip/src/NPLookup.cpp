


#include <stdio.h>
#include <stdlib.h>
#include <np.h>
#include <libsysmodule.h>
#include <map>


#include "NPLookup.h"


#if NDEBUG
#define PRINT(x,...)
#define EPRINT(x,...)
#define TRACE(x,...)
#else
#define PRINT					printf
#define EPRINT					printf("Error : %s at %d\n  ", __FILE__, __LINE__ ); \
									printf
#define TRACE					printf("-- %s, %s : %d\n", __FILE__, __FUNCTION__, __LINE__)
#endif


#define PRX_EXPORT extern "C" __declspec (dllexport)


static bool sLookupInit = false;


PRX_EXPORT NpLookupContext * NpIdLookupCreateContext(int userId)
{

	return new NpLookupContext(userId);
}


PRX_EXPORT int NpIdLookupAddSearch(void *ctx, const char *onlineId, SceNpId ** npId, bool Async)
{
	PRINT("adding npid lookup using %s\n", onlineId);
	NpLookupContext *nplCtx = (NpLookupContext *)ctx;
	return nplCtx->AddSearch(onlineId, *npId, Async);
}


NpLookupContext::NpLookupContext(int userId)
{
	SceNpId selfNpId;
	int res;


	if (sLookupInit == false)
	{
		if (sceSysmoduleIsLoaded(SCE_SYSMODULE_NP_UTILITY) != SCE_OK)
		{
			int res = sceSysmoduleLoadModule(SCE_SYSMODULE_NP_UTILITY);
			if (res != SCE_OK)
			{
				EPRINT("NpLookupContext failed during sceNpLookupCreateTitleCtx, error 0x%x\n", res);
				//Error handling
			}
		}

		sLookupInit = true;
	}

	if (userId == 0)
	{
		res = sceUserServiceGetInitialUser(&userId);
	}
	res = sceNpGetNpId(userId, &selfNpId);
	if (res != 0)
	{
		EPRINT("NpLookupContext failed during sceNpGetNpId, error 0x%x\n", res);
	}

	res = sceNpLookupCreateTitleCtx(&selfNpId);
	if (res < 0)
	{
		EPRINT("NpLookupContext failed during sceNpLookupCreateTitleCtx, error 0x%x\n", res);
	}

	m_TitleContextId = res;

}





int NpLookupContext::AddSearch(const void *onlineId, SceNpId * npId, bool Async)
{
	int ret;


	SceNpOnlineId fullOnlineId;
	memset(&fullOnlineId, 0, sizeof(SceNpOnlineId));
	strncpy(fullOnlineId.data, (const char *)onlineId, SCE_NP_ONLINEID_MAX_LENGTH);


	if (Async)
	{
		SceNpLookupCreateAsyncRequestParameter param;
		memset(&param, 0, sizeof(param));
		param.size = sizeof(param);
		param.cpuAffinityMask = SCE_KERNEL_CPUMASK_USER_ALL;
		param.threadPriority = SCE_KERNEL_PRIO_FIFO_DEFAULT;

		ret = sceNpLookupCreateAsyncRequest(m_TitleContextId, &param);
		if (ret < 0) 
		{
			// Error handling
		}
		int reqId = ret;

		// Request
		ret = sceNpLookupNpId(reqId, &fullOnlineId, npId, NULL);
		if (ret < 0) 
		{
			EPRINT("error during sceNpLookupNpId, 0x%x\n", ret);
		}
		else
		{
			LookupData data;
			memcpy(&data.onlineId, onlineId, SCE_NP_ONLINEID_MAX_LENGTH);
			data.npId = npId;
			m_PendingLookupsList.insert({ reqId, data });
		}
		return reqId;

	}
	else
	{
		ret = sceNpLookupCreateRequest(m_TitleContextId);
		if (ret < 0) 
		{
			EPRINT("error during sceNpLookupCreateRequest, 0x%x\n", ret);
			return ret;
		}

		int reqId = ret;

		ret = sceNpLookupNpId(reqId, &fullOnlineId, npId, NULL);
		if (ret < 0)
		{
			EPRINT("error during sceNpLookupNpId, 0x%x\n", ret);
			sceNpLookupDeleteRequest(reqId);
		}

		int delret = sceNpLookupDeleteRequest(reqId);
		if (delret < 0)
		{
			EPRINT("error during sceNpLookupDeleteRequest, 0x%x\n", delret);
		}

	}

	return ret;
}



int NpLookupContext::Update()
{
	auto lookup = std::begin(m_PendingLookupsList);
	while (lookup != std::end(m_PendingLookupsList))
	{
		int result;
		bool remove = false;
		int res = sceNpLookupPollAsync(lookup->first, &result);
		if (res != 0)
		{
			EPRINT("sceNpLookupPollAsync returned 0x%x\n", res);
		}
		if (result == SCE_NP_LOOKUP_POLL_ASYNC_RET_RUNNING)
		{
			PRINT("stilling checking 0x%x\n", lookup->first);
		}
		else if (result == SCE_NP_LOOKUP_POLL_ASYNC_RET_FINISHED)
		{
			PRINT("lookup completed, npid:0x%p\n", lookup->second.npId);
			remove = true;
		}
		else
		{
			EPRINT("error during Nplookup 0x%x\n", result);
			remove = true;
		}

		if (remove)
		{
			res = sceNpLookupDeleteRequest(lookup->first);
			if (res != 0)
			{
				EPRINT("error during sceNpLookupDeleteRequest 0x%x\n", res);
			}
			lookup = m_PendingLookupsList.erase(lookup);
		}
		else
		{
			++lookup;
		}

	}
	return 0;
}


int NpLookupContext::PollAsync(int id)
{
	int result = 0;
	bool remove = false;

	int res = sceNpLookupPollAsync(id, &result);

	if (res == SCE_NP_LOOKUP_POLL_ASYNC_RET_RUNNING)
	{
		return res;
	}
	else if (res == SCE_NP_LOOKUP_POLL_ASYNC_RET_FINISHED)
	{
		remove = true;
	}
	else
	{
		EPRINT("error during Nplookup 0x%x\n", res);
		remove = true;
	}

	if (remove)
	{
		int res = sceNpLookupDeleteRequest(id);
		if (res != 0)
		{
			EPRINT("error during sceNpLookupDeleteRequest 0x%x\n", res);
		}
		m_PendingLookupsList.erase(id);
	}
	return result;
}


