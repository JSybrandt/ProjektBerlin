#include "ErrorDialog.h"
#include "MessagePipe.h"
#include "ErrorCodes.h"
#include <libsysmodule.h>

namespace UnityCommonDialog
{

	PRX_EXPORT bool PrxCommonDialogErrorMessage(int errorCode)
	{
		ErrorDialogParams params;
		params.errorCode = errorCode;
		
		sceUserServiceGetInitialUser(&params.userId);	// use default user

		return gErrorDialog.StartDialog(&params);
	}

	PRX_EXPORT bool PrxErrorDialogIsDialogOpen()
	{
		return gErrorDialog.IsDialogOpen();
	}

	PRX_EXPORT bool PrxErrorDialogOpen(ErrorDialogParams* params)
	{
		return gErrorDialog.StartDialog(params);
	}

	PRX_EXPORT bool PrxErrorDialogGetResult(ErrorDialogResult* result)
	{
		return gErrorDialog.Get(result);
	}

	ErrorDialog gErrorDialog;

	ErrorDialog::ErrorDialog() :
	m_DialogOpen(false)
	, m_DialogInitialized(false)
	{
	}

	ErrorDialog::~ErrorDialog()
	{

	}

	bool ErrorDialog::StartDialog(const ErrorDialogParams* params)
	{
		if(m_DialogOpen)
		{
			Messages::Log("ImeDIalog is already open\n");
			return false;
		}

		m_CachedParams.errorCode = params->errorCode;
		m_CachedParams.userId = params->userId;

		return StartDialog(m_CachedParams);
	}

	bool ErrorDialog::StartDialog(const Params& params)
	{
		if(m_DialogOpen)
		{
			Messages::Log("ImeDialog is already open\n");
			return false;
		}


		int32_t ret = sceSysmoduleIsLoaded(SCE_SYSMODULE_ERROR_DIALOG);
		if (ret != SCE_OK)
		{
			if (ret == SCE_SYSMODULE_ERROR_UNLOADED)
			{
				ret =  sceSysmoduleLoadModule(SCE_SYSMODULE_ERROR_DIALOG);
			}
			
			if (ret != SCE_OK)
			{
				Messages::LogError("CommonDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
				return false;
			}
		}

		ret = sceErrorDialogInitialize();
		if (ret != SCE_OK )
		{
			Messages::LogError("CommonDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
			return false;
		}
		m_DialogInitialized = true;

		m_DialogOpen = true;


		SceErrorDialogParam errorParams;
		sceErrorDialogParamInitialize(&errorParams);

		errorParams.errorCode = params.errorCode;
		errorParams.userId = params.userId;

		ret = sceErrorDialogOpen(&errorParams);
		if (ret < 0)
		{
			Messages::LogError("ImeDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
			m_DialogOpen = false;
			return false;
		}

		m_DialogOpen = true;
		return true;
	}

	bool ErrorDialog::Update()
	{
		if (m_DialogOpen == false)
		{
			return true;
		}
		if (m_DialogInitialized == false) return true;

		SceErrorDialogStatus cdStatus = sceErrorDialogUpdateStatus();
		switch (cdStatus)
		{
		case SCE_ERROR_DIALOG_STATUS_NONE:
		case SCE_ERROR_DIALOG_STATUS_INITIALIZED:
		case SCE_ERROR_DIALOG_STATUS_RUNNING:
			return true;
		case SCE_ERROR_DIALOG_STATUS_FINISHED:
			break;
		}


		sceErrorDialogTerminate();
		m_DialogInitialized = false;

		m_DialogOpen = false;
		return true;
	}


	// For use when calling directly from scripts.
	bool ErrorDialog::Get(ErrorDialogResult* result)
	{
		result->result = m_CachedResult.result;
		result->button = m_CachedResult.button;
		result->text = m_CachedResult.text;

		return true;
	}

} // namespace UnityNp
