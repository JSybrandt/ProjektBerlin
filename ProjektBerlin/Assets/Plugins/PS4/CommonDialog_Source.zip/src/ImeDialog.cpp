﻿#include "ImeDialog.h"
#include "MessagePipe.h"
#include "ErrorCodes.h"
#include <libsysmodule.h>

namespace UnityCommonDialog
{
	PRX_EXPORT bool PrxImeDialogIsDialogOpen()
	{
		return gImeDialog.IsDialogOpen();
	}

	PRX_EXPORT bool PrxImeDialogOpen(SceImeDialogParam* params, SceImeParamExtended* extended)
	{
		return gImeDialog.StartDialog(params, extended);
	}

	PRX_EXPORT bool PrxImeDialogGetResult(ImeDialogResult* result)
	{
		return gImeDialog.Get(result);
	}

	ImeDialog gImeDialog;

	ImeDialog::ImeDialog() :
	m_DialogOpen(false)
		,m_DialogInitialized(false)
		,m_DefaultInputBuffer(NULL)
		,m_DefaultResultString(NULL)
	{
	}

	ImeDialog::~ImeDialog()
	{
		free(m_DefaultInputBuffer);
		free(m_DefaultResultString);
	}

	bool ImeDialog::StartDialog(const SceImeDialogParam* params, const SceImeParamExtended *extended)
	{
		if(m_DialogOpen)
		{
			Messages::Log("ImeDIalog is already open\n");
			return false;
		}

		m_CachedParams.callback = DefaultResultCallback;
		if(m_DefaultInputBuffer)
		{
			free(m_DefaultInputBuffer);
		}
		m_DefaultInputBuffer = (wchar_t*)malloc(sizeof(wchar_t) * (SCE_IME_MAX_PREEDIT_LENGTH + params->maxTextLength));

		m_CachedParams.params = *params;
		m_CachedParams.extended = *extended;
		memset(&m_CachedParams.params.reserved, 0, sizeof(m_CachedParams.params.reserved));
		memset(&m_CachedParams.extended.reserved, 0, sizeof(m_CachedParams.extended.reserved));

		if (m_CachedParams.params.userId == 0)
		{
			sceUserServiceGetInitialUser(&m_CachedParams.params.userId);	// use default user
		}

		return StartDialog(m_CachedParams);
	}

	bool ImeDialog::StartDialog(Params& params)
	{
		if(m_DialogOpen)
		{
			Messages::Log("ImeDialog is already open\n");
			return false;
		}


		int32_t ret = sceSysmoduleIsLoaded(SCE_SYSMODULE_IME_DIALOG);
		if (ret != SCE_OK)
		{
			if (ret == SCE_SYSMODULE_ERROR_UNLOADED)
			{
				ret =  sceSysmoduleLoadModule(SCE_SYSMODULE_IME_DIALOG);
			}
			
			if (ret != SCE_OK)
			{
				Messages::LogError("CommonDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
				return false;
			}
		}

		m_DialogInitialized = true;
		m_DialogOpen = true;
		memset(m_DefaultInputBuffer, 0,(sizeof(wchar_t) * (SCE_IME_MAX_PREEDIT_LENGTH + params.params.maxTextLength)));

		if (params.params.inputTextBuffer)
		{ 
			wcsncpy((wchar_t*)m_DefaultInputBuffer, (wchar_t*)params.params.inputTextBuffer, (params.params.maxTextLength+1) );
		}
		params.params.inputTextBuffer = m_DefaultInputBuffer;

		m_ResultCallback = params.callback;

		ret = sceImeDialogInit( &params.params, &params.extended );
		if (ret < 0)
		{
			Messages::LogError("ImeDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
			m_DialogOpen = false;
			return false;
		}

		m_DialogOpen = true;
		return true;
	}

	bool ImeDialog::Update()
	{
		if (m_DialogOpen == false)
		{
			return true;
		}
		if (m_DialogInitialized == false) return true;

		SceImeDialogStatus cdStatus = sceImeDialogGetStatus();
		switch (cdStatus)
		{
		case SCE_IME_DIALOG_STATUS_NONE:
		case SCE_IME_DIALOG_STATUS_RUNNING:
			return true;
		case SCE_IME_DIALOG_STATUS_FINISHED:
			break;
		}

		SceImeDialogResult imeResult;
		memset(&imeResult, 0x00, sizeof(imeResult));
		int ret = sceImeDialogGetResult(&imeResult);
		if (ret < 0)
		{
			Messages::LogError("ImeDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
			m_DialogOpen = false;
			return false;
		}

		ret = sceImeDialogTerm();
		if (ret < 0)
		{
			Messages::LogError("ImeDialog::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(ret));
			m_DialogOpen = false;
			return false;
		}

		m_DialogInitialized = false;

		if (m_ResultCallback)
		{
			m_ResultCallback(&imeResult);
			m_ResultCallback = NULL;
		}

		m_DialogOpen = false;
		return true;
	}

	void ImeDialog::DefaultResultCallback(const SceImeDialogResult *result)
	{
		if (result->endstatus == SCE_IME_DIALOG_END_STATUS_OK)
		{
			if(gImeDialog.m_DefaultResultString)
			{
				free(gImeDialog.m_DefaultResultString);
			}
			gImeDialog.m_DefaultResultString = (char*)malloc(SCE_IME_MAX_PREEDIT_LENGTH + gImeDialog.m_CachedParams.params.maxTextLength);
			wcstombs(gImeDialog.m_DefaultResultString, (wchar_t*)gImeDialog.m_DefaultInputBuffer, sizeof(wchar_t)*(SCE_IME_MAX_PREEDIT_LENGTH + gImeDialog.m_CachedParams.params.maxTextLength));

			gImeDialog.m_CachedResult.result = result->endstatus;
			gImeDialog.m_CachedResult.text = gImeDialog.m_DefaultResultString;
		}
		else
		{
			gImeDialog.m_CachedResult.result = result->endstatus;
			gImeDialog.m_CachedResult.text = gImeDialog.m_DefaultResultString;
		}

		Messages::AddMessage(Messages::kDialog_GotIMEDialogResult);
	}

	// For use when calling directly from scripts.
	bool ImeDialog::Get(ImeDialogResult* result)
	{
		result->result = m_CachedResult.result;
		result->text = m_CachedResult.text;

		return true;
	}

} // namespace UnityNp
