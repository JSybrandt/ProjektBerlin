#include <camera.h>
#include <string.h>

#define PRX_EXPORT extern "C" __declspec (dllexport)
#include <stdlib.h>

#include <hand.h>
#include <libsysmodule.h>
#include <kernel.h>
#include <sce_atomic.h>



namespace UnityCamera
{

	//int32_t onionSize,garlicSize;
	//off_t onionPhysAddr;
	//void* onionMem = NULL;
	//off_t garlicPhysAddr;
	//void* garlicMem = NULL;

	//ScePthread m_thread_padtracker;
	//SceKernelEqueue m_queue_padtracker;

	//const int numQueueEntrys = 8;
	//int64_t m_queuealloc_padtracker;

	bool m_active = false;

	SceHandDetectionDictPtr m_detectDictPtr=NULL;
	int m_detectWorkBufferSize=0;
	void *m_detectWorkBuffer=NULL;

//	static void* padTrackerThread(void* ptr);
	PRX_EXPORT int PrxPadTrackerUpdate(int64_t cameraimagehandle, int32_t *handles);

	

	PRX_EXPORT int PrxHandDetectionInitialise(void)
	{
		if (m_active == true) return -1;

		m_active = false;

		int result = sceSysmoduleLoadModule(SCE_SYSMODULE_HAND);
		if (result != SCE_OK) 
		{ 
			// we require the file to be phyiscally in the build folder
			printf("unable to load module SCE_SYSMODULE_HAND from sce_module folder\n");	// 
			return result; 
		}
		
		int imagewidth = 1280;
		int imageheight = 800;
		int rawstride = 1280;

		m_detectDictPtr = (SceHandDetectionDictPtr)malloc(SCE_HAND_DETECT_PAPER_DICT_SIZE);
		if (m_detectDictPtr == NULL) 
		{ 
			printf("HandDetectionInitialise malloc failed\n");
			return -1; 
		}

		FILE *dfp = fopen( ("/app0/media/StreamingAssets/" SCE_HAND_DETECT_PAPER_DICT), "rb");
		if (dfp) 
		{
			fread(m_detectDictPtr, SCE_HAND_DETECT_PAPER_DICT_SIZE, 1, dfp);
			fclose(dfp);
		} else 
		{
			printf("Unable to open hand detection dictionary %s from StreamingAssets folder\n", SCE_HAND_DETECT_PAPER_DICT);
			return -1;
		}


		result = sceHandDetectionGetWorkingMemorySize(imagewidth, imageheight, rawstride, m_detectDictPtr);
		if (result == 0) 
		{ 
			printf("sceHandDetectionGetWorkingMemorySize failed\n");
			return result; 
		}

		m_detectWorkBufferSize = result;
		m_detectWorkBuffer = malloc(result);


		m_active = true;

		return result;
	}

#if(0)
	static void* padTrackerThread(void* ptr)
	{
		int res;
		int num = 2;
		SceKernelEvent ev[num];
		while(1)
		{
			//if(s_GameEnd)
			//	break;

			int out = 0;
			res = sceKernelWaitEqueue(m_queue_padtracker,ev,num,&out,NULL);
			if (res<0)
			{
				printf("padTrackerThread queue returned with error 0x%x\n",res);
				break;
			}

			for (int evnt=0;evnt<out;evnt++)
			{
				SceKernelEvent *curEvent = &ev[evnt];
				int filter = sceKernelGetEventFilter(curEvent);
				if (filter !=  SCE_KERNEL_EVFILT_USER) continue;

				PadTrackingRequest *ptreq = (PadTrackingRequest *)sceKernelGetEventUserData(curEvent);
				int identry = sceKernelGetEventId(curEvent);

				PrxPadTrackerUpdate(ptreq->cameraimagehandle,ptreq->padhandles);

				// free the queue entry
				int64_t mask = (1<<identry);
				sceAtomicOr64(&m_queuealloc_padtracker, mask);	// set a bit to indicate that it is free

			}

		}
		scePthreadExit(NULL);
	}


	PRX_EXPORT int PrxPadTrackerQueueUpdate(int64_t cameraimagehandle, int32_t *handles)
	{
		int identry = -1;
		if (m_active == false) return -1;
		while(1)
		{
			identry = __builtin_ffsll(m_queuealloc_padtracker) -1;		// find first 1 bit
			if ((identry < 0)||(identry>=numQueueEntrys))
			{
				printf("no space in PrxPadTrackerAddQueue queue\n");
				return -1;
			}
			
			int64_t mask = ~(1<<identry);
			int64_t oldvalue = sceAtomicAnd64(&m_queuealloc_padtracker, mask);	// clear a bit to indicate that it is in use
		
			if ((oldvalue & (1<<identry))!=0) break;	// confirm that the bit is available (might have just been taken by another thread)
			printf("bit taken ... attempting retry\n");	
		}


		m_Requests[identry].cameraimagehandle = cameraimagehandle;
		m_Requests[identry].padhandles = handles;

		int res = sceKernelTriggerUserEvent(m_queue_padtracker, identry, &m_Requests[identry]);
		if (res<0)
		{
			printf("sceKernelTriggerUserEvent failed 0x%x\n",res);
		}
		return res;
	}


	PRX_EXPORT int PrxPadTrackerUpdate(int64_t cameraimagehandle, int32_t *handles)
	{
		if (m_active == false) return -1;
		ScePadTrackerInput input;
		memset(&input,0,sizeof(input));

		if (handles!=NULL)
		{
			memcpy(&input.handles[0],handles,SCE_PAD_TRACKER_CONTROLLER_MAX*sizeof(int32_t));
		}

		// Set up image 1 for tracking
		SceCameraFrameData *imagedata = (SceCameraFrameData *)cameraimagehandle;
		input.images[0].data = NULL;	// do not perform tracking for image 0, only image 1
		input.images[1].exposure = imagedata->meta.exposureGain[1].exposure;
		input.images[1].gain = imagedata->meta.exposureGain[1].gain;
		input.images[1].data = imagedata->pFramePointerList[1][0];
		input.images[1].width = 1280;
		input.images[1].height = 800;
		if (input.images[1].data == NULL)
		{
			printf("null data from camera for pad tracking\n");
		}

		int result = scePadTrackerUpdate(input);
//		printf("scePadTrackerUpdate result: 0x%x\n",result);
		return result;
	}


	PRX_EXPORT int PrxPadTrackerReadState(int32_t handle, ScePadTrackerData *PadData)
	{
		if (m_active == false) return -1;

		int result = scePadTrackerReadState(handle, PadData);
		if (result != 0)
		{
			printf("scePadTrackerReadState error:0x%x\n",result);
		}
		return result;
	}

	
	PRX_EXPORT int PrxPadTrackerReadState2(int32_t handle, ScePadTrackerData *PadData)
	{
		if (m_active == false) return -1;

		int result = scePadTrackerReadState(handle, PadData);
		if (result != 0)
		{
			printf("scePadTrackerReadState error:0x%x\n",result);
		}
		return result;
	}

	PRX_EXPORT int PrxPadTrackerShutdown(void)
	{
		m_queuealloc_padtracker=0;		// clear the allocations ... so that no new ones can start
		int result;

		if (m_active == false) return -1;

		for (int id=0;id<numQueueEntrys; id++)
		{
			result = sceKernelDeleteUserEvent(m_queue_padtracker, id);
			if (result<0)
			{
				printf("error during sceKernelDeleteUserEvent: 0x%x\n",result);
			}
		}
		
		result = sceKernelDeleteEqueue(m_queue_padtracker);
		if (result<0)
		{
			printf("error during sceKernelDeleteEqueue: 0x%x\n",result);
		}

//return 0;
	//	result = scePthreadCancel(m_thread_padtracker);
		if (result<0)
		{
			printf("error during scePthreadCancel: 0x%x\n",result);
		}

	
		result = scePthreadJoin(m_thread_padtracker, NULL);
		if (result<0)
		{
			printf("error during scePthreadJoin: 0x%x\n",result);
		}




		int errcode = SCE_OK;
		result = scePadTrackerTerm();
		if (result != SCE_OK) 
		{
			printf("scePadTrackTerm failed\n");
			errcode = result;
		}
		

		result = sceKernelReleaseDirectMemory( onionPhysAddr, onionSize );
		if (result != SCE_OK) 
		{
			printf("sceKernelReleaseDirectMemory (onion) failed\n");
			errcode = result;
		
		}
		onionPhysAddr=0;
		onionSize=0;

		result = sceKernelReleaseDirectMemory( garlicPhysAddr, garlicSize );
		if (result != SCE_OK) 
		{
			printf("sceKernelReleaseDirectMemory (garlic) failed\n");
			errcode = result;
		}
		garlicPhysAddr=0;
		garlicSize=0;


		result = sceSysmoduleUnloadModule(SCE_SYSMODULE_PAD_TRACKER);
		if (result != SCE_OK) 
		{
			printf("sceSysmoduleUnloadModule (SCE_SYSMODULE_PAD_TRACKER) failed\n");
			errcode = result;
		}

		m_active = false;

		return errcode;
	}

#endif

}
