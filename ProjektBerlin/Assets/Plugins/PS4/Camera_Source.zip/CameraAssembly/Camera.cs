﻿using System;
using System.Runtime.InteropServices;

using System.IO;
using UnityEngine;


using System.Runtime.CompilerServices;
using uei = UnityEngine.Internal;

//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

namespace UnityEngine
{



	public sealed partial class CameraTexture : Texture
	{

	  //  [WrapperlessIcall()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		extern public void testcamerafunction();

	}    
	
	namespace PS4
	{

		namespace IODevices
		{



			public class vars
			{
				public const int SCE_CAMERA_MAX_DEVICE_NUM = 2;
				public const int SCE_CAMERA_MAX_FORMAT_LEVEL_NUM = 4;

				public const int SCE_USER_SERVICE_USER_ID_SYSTEM = (0xff);
			}


			public enum SceCameraConfigType
			{
				SCE_CAMERA_CONFIG_TYPE1 = 0x01,
				SCE_CAMERA_CONFIG_TYPE2 = 0x02,
				SCE_CAMERA_CONFIG_TYPE3 = 0x03,
				SCE_CAMERA_CONFIG_TYPE4 = 0x04,
				SCE_CAMERA_CONFIG_EXTENTION = 0x10
			};

			public enum SceCameraAttributeExposureGainMode
			{
				MODE_0 = 0x0,
				MODE_1 = 0x1,
			};



			/* Camera Format */
			public enum SceCameraBaseFormat
			{
				SCE_CAMERA_FORMAT_YUV422		=	0x0,
				SCE_CAMERA_FORMAT_RAW16,				// HD only
				SCE_CAMERA_FORMAT_RAW8,					// HD only
				SCE_CAMERA_FORMAT_NO_USE		=	0x10,
				SCE_CAMERA_FORMAT_UNKNOWN		=	0xFF,
			};

			
			public enum SceCameraScaleFormat
			{
				SCE_CAMERA_SCALE_FORMAT_YUV422		=	0x0,
				SCE_CAMERA_SCALE_FORMAT_Y16			=	0x3,// Scale only
				SCE_CAMERA_SCALE_FORMAT_Y8,					// Scale only
				SCE_CAMERA_SCALE_FORMAT_NO_USE		=	0x10,
				SCE_CAMERA_SCALE_FORMAT_UNKNOWN		=	0xFF,
			};


			/* Camera Resolution */
			public enum SceCameraResolution
			{
				SCE_CAMERA_RESOLUTION_1280x800			=	0x0,	// In the future, it will be abolished.
				SCE_CAMERA_RESOLUTION_640x400,						// In the future, it will be abolished.
				SCE_CAMERA_RESOLUTION_320x200,						// In the future, it will be abolished.
				SCE_CAMERA_RESOLUTION_160x100,						// In the future, it will be abolished.
				SCE_CAMERA_RESOLUTION_SPECIFIED_WIDTH_HEIGHT,	// with uiWidth/uiHeight

				SCE_CAMERA_RESOLUTION_1280X800			=	0x0,
				SCE_CAMERA_RESOLUTION_640X400			=	0x1,
				SCE_CAMERA_RESOLUTION_320X200			=	0x2,
				SCE_CAMERA_RESOLUTION_160X100			=	0x3,

				SCE_CAMERA_RESOLUTION_UNKNOWN			=	0xFF,
			};

			/* Camera rate */
			public enum SceCameraFramerate
			{
				SCE_CAMERA_FRAMERATE_UNKNOWN		=	0,
				SCE_CAMERA_FRAMERATE_7_5			=	7,
				SCE_CAMERA_FRAMERATE_15				=	15,
				SCE_CAMERA_FRAMERATE_30				=	30,
				SCE_CAMERA_FRAMERATE_60				=	60,
				SCE_CAMERA_FRAMERATE_120			=	120,
				SCE_CAMERA_FRAMERATE_240			=	240,
			};


			[StructLayout(LayoutKind.Sequential, Pack = 0)]
			public struct SceCameraFormat
			{
				public SceCameraBaseFormat formatLevel0;
				public SceCameraScaleFormat formatLevel1;	//Scale Down  1/4;
				public SceCameraScaleFormat formatLevel2;	//Scale Down  1/16
				public SceCameraScaleFormat formatLevel3;	//Scale Down  1/64
			};


			[StructLayout(LayoutKind.Sequential, Pack = 0)]
			public struct SceCameraConfigExtention
			{
				public SceCameraFormat format;
				public SceCameraResolution resolution;
				public SceCameraFramerate framerate;
				public UInt32 width;
				public UInt32 height;
				public UInt32 reserved1;
				public IntPtr pBaseOption;
			};


			
		   [StructLayout(LayoutKind.Sequential, Pack = 0)]
			public struct SceCameraFramePosition
			{
				public UInt32 x;
				public UInt32 y;
				public UInt32 xSize;
				public UInt32 ySize;
			};


			[StructLayout(LayoutKind.Sequential, Pack = 0)]
			public struct SceCameraExposureGain
			{
				public UInt32 			exposureControl;
				public UInt32 			exposure;
				public UInt32 			gain;
				public UInt32 			mode;
			};

			[StructLayout(LayoutKind.Sequential, Pack = 0)]
			public struct SceCameraWhiteBalance
			{
				 public UInt32				whiteBalanceControl;
				 public UInt32				gainRed;
				 public UInt32				gainBlue;
				 public UInt32				gainGreen;
			};

			[StructLayout(LayoutKind.Sequential, Pack = 0)]
			public struct SceCameraGamma
			{
				public UInt32			gammaControl;
				public UInt32			value;
				public UInt32           reserved0, reserved1, reserved2, reserved3; //uint8_t				reserved[16];
			};


			[StructLayout(LayoutKind.Sequential, Pack = 0)]
			public struct SceFVector3
			{
				public SceFVector3(float _x, float _y, float _z)
				{
					x=_x; y=_y; z=_z;
				}
				public float x;
				public float y;
				public float z;
			};
			
			[StructLayout(LayoutKind.Sequential, Pack = 0)]
			public class SceCameraMeta
		   {

				public SceCameraMeta()
				{
					metaMode = 0;
					format = new UInt32[vars.SCE_CAMERA_MAX_DEVICE_NUM, vars.SCE_CAMERA_MAX_FORMAT_LEVEL_NUM];
					frame = new UInt64[vars.SCE_CAMERA_MAX_DEVICE_NUM];
					timestamp = new UInt64[vars.SCE_CAMERA_MAX_DEVICE_NUM];
					deviceTimestamp = new UInt32[vars.SCE_CAMERA_MAX_DEVICE_NUM];
					exposureGain = new SceCameraExposureGain[vars.SCE_CAMERA_MAX_DEVICE_NUM];
					whiteBalance = new SceCameraWhiteBalance[vars.SCE_CAMERA_MAX_DEVICE_NUM];
					gamma = new SceCameraGamma[vars.SCE_CAMERA_MAX_DEVICE_NUM];
					luminance = new UInt32[vars.SCE_CAMERA_MAX_DEVICE_NUM];
					acceleration = new SceFVector3(0,0,0);
					reserved = new UInt32[16];
				}

				public UInt32				metaMode;
				public UInt32		     	[,]	format;  //[SCE_CAMERA_MAX_DEVICE_NUM][SCE_CAMERA_MAX_FORMAT_LEVEL_NUM];
				public UInt64				[]frame; //[SCE_CAMERA_MAX_DEVICE_NUM];
				public UInt64				[]timestamp; //[SCE_CAMERA_MAX_DEVICE_NUM];
				public UInt32				[]deviceTimestamp; //[SCE_CAMERA_MAX_DEVICE_NUM];
				public SceCameraExposureGain	[]exposureGain; //[SCE_CAMERA_MAX_DEVICE_NUM];
				public SceCameraWhiteBalance	[]whiteBalance; //[SCE_CAMERA_MAX_DEVICE_NUM];
				public SceCameraGamma			[]gamma; //[SCE_CAMERA_MAX_DEVICE_NUM];
				public UInt32				[]luminance; //[SCE_CAMERA_MAX_DEVICE_NUM];
				public SceFVector3				acceleration;
				public UInt32			[]	reserved; //[16];
			};


   

			[StructLayout(LayoutKind.Sequential, Pack = 0)]
			public class SceCameraConfig_old_but_working
			{
				public UInt32 sizeThis;
				public SceCameraConfigType configType;

			   // [MarshalAs(UnmanagedType.ByValArray,  SizeConst = 2)]
				//public SceCameraConfigExtention[] configExtention;
				
				public SceCameraFormat configExtention0_format;
				public SceCameraResolution configExtention0_resolution;
				public SceCameraFramerate configExtention0_framerate;
				public UInt32 configExtention0_width;
				public UInt32 configExtention0_height;
				public UInt32 configExtention0_reserved1;
				public IntPtr configExtention0_pBaseOption;


				public SceCameraFormat configExtention1_format;
				public SceCameraResolution configExtention1_resolution;
				public SceCameraFramerate configExtention1_framerate;
				public UInt32 configExtention1_width;
				public UInt32 configExtention1_height;
				public UInt32 configExtention1_reserved1;
				public IntPtr configExtention1_pBaseOption;

			};

			// all the marshalling seems to work correctly for using this class as an input to C++ (including array)
			[StructLayout(LayoutKind.Sequential, Pack = 0)]
			public class SceCameraConfig
			{
				public SceCameraConfig()
				{
					sizeThis = 0x68;
					configExtention = new SceCameraConfigExtention[2];
				}

				public UInt32 sizeThis;
				public SceCameraConfigType configType;

				[MarshalAs(UnmanagedType.ByValArray, ArraySubType = UnmanagedType.I4, SizeConst = 12*2)]
				public SceCameraConfigExtention[] configExtention;
			};


			[Flags]
			public enum sceCameraFrameFormat : uint
			{
				SCE_CAMERA_FRAME_FORMAT_LEVEL0 = 0x01,
				SCE_CAMERA_FRAME_FORMAT_LEVEL1 = 0x02,
				SCE_CAMERA_FRAME_FORMAT_LEVEL2 = 0x04,
				SCE_CAMERA_FRAME_FORMAT_LEVEL3 = 0x08,

				SCE_CAMERA_FRAME_FORMAT_ALL = 0x0f
			};

		 
			[StructLayout(LayoutKind.Sequential, Pack = 0), Serializable]
			public class SceCameraStartParameter
			{
				public SceCameraStartParameter()
				{
					sizeThis = 0x18;
					formatLevel = new sceCameraFrameFormat[vars.SCE_CAMERA_MAX_DEVICE_NUM];
				}
				 public UInt32 sizeThis;

				// seems like this marshal correctly builds stack arrays, and allows you to pass the class to the native code and it appears as a pointer
				 [MarshalAs(UnmanagedType.ByValArray, ArraySubType = UnmanagedType.SysUInt, SizeConst = 2)]
				 public sceCameraFrameFormat[] formatLevel;   
				
				public IntPtr pStartOption;
			};


 
			public class SceCameraFrameData
			{
				public SceCameraFrameData()
				{
					sizeThis = 0x1e8;
					framePosition = new SceCameraFramePosition[vars.SCE_CAMERA_MAX_DEVICE_NUM, vars.SCE_CAMERA_MAX_FORMAT_LEVEL_NUM];
					pFramePointerList = new IntPtr[vars.SCE_CAMERA_MAX_DEVICE_NUM, vars.SCE_CAMERA_MAX_FORMAT_LEVEL_NUM];
					frameSize = new UInt32[vars.SCE_CAMERA_MAX_DEVICE_NUM, vars.SCE_CAMERA_MAX_FORMAT_LEVEL_NUM];
					status = new UInt32[vars.SCE_CAMERA_MAX_DEVICE_NUM];
					meta = new SceCameraMeta();
				}

				public UInt32 sizeThis;
				public UInt32 readMode;
				public SceCameraFramePosition[,] framePosition;
				public IntPtr[,] pFramePointerList;

//                [MarshalAs(UnmanagedType.ByValArray, ArraySubType = UnmanagedType.SysUInt, SizeConst = 8)]
				public UInt32[,] frameSize;

//                [MarshalAs(UnmanagedType.ByValArray, ArraySubType = UnmanagedType.SysUInt, SizeConst = 2)]
				public UInt32[] status;
				public SceCameraMeta meta;
			}

			[StructLayout(LayoutKind.Sequential, Pack = 0)]
			public class SceCameraFrameData_marshalled
			{
				public SceCameraFrameData_marshalled()
				{
					System.Console.WriteLine("SceCameraFrameData_marshalled constr\n");
					sizeThis = 0x1e8;
				}

				public UInt32 sizeThis;
				public UInt32 readMode;

				public IntPtr _framePosition;

			}


			[StructLayout(LayoutKind.Sequential, Pack = 0)]
			public class SceCameraFrameData_marshalled_out
			{

				public UInt32 sizeThis;
				public UInt32 readMode;
				public IntPtr framePosition;
			};


			public class PS4Camera      // ideally this would be called Camera ... but that clashes with UnityEngine.Camera
			{

				[DllImport("CameraPlugin")]
				static extern int PrxCameraIsAttached(int index);

				public static int IsAttached(int index) { return PrxCameraIsAttached(index); }

				[DllImport("CameraPlugin")]
				static extern void PrxCameraInit();
				public static void Init() { PrxCameraInit(); }

				[DllImport("CameraPlugin")]
				static extern void PrxCameraSetExposureGainMode(int camera0mode, int camera1mode);
				public static void SetExposureGainMode(SceCameraAttributeExposureGainMode camera0mode, SceCameraAttributeExposureGainMode camera1mode) { PrxCameraSetExposureGainMode((int)camera0mode, (int)camera1mode); }


				[DllImport("CameraPlugin")]
				static extern void PrxCameraShutdown();
				public static void Term() { PrxCameraShutdown(); }

				[DllImport("CameraPlugin")]
				static extern int PrxCameraOpen(int userId, int type, int index, IntPtr pParam);
				public static int Open(int userId, int type, int index, IntPtr pParam) { return PrxCameraOpen(userId, type, index, pParam); }

				[DllImport("CameraPlugin")]
				static extern int PrxCameraSetConfig(int handle, SceCameraConfig Config);

				[DllImport("CameraPlugin")]
				static extern int PrxSetCameraFrameCallback(UInt64 newcallback);
				
				[DllImport("CameraPlugin")]
				static extern int PrxCameraStart(int handle, SceCameraStartParameter pStart);

				[DllImport("CameraPlugin")]
				static extern int PrxCameraGetFrameData(int handle, UInt32 readmode, ref UInt64 framehandle);

				
				[DllImport("CameraPlugin")]
				static extern IntPtr PrxCameraGetFrameIntPtr(UInt64 framehandle, int device, int level);


				[DllImport("CameraPlugin")]
				static extern int PrxCameraIsValidFrameData(int handle, IntPtr pFrameData);

				[DllImport("CameraPlugin")]
				static extern int PrxCameraStop(int handle);

				[DllImport("CameraPlugin")]
				static extern int PrxCameraClose(int handle);

 
			   //[DllImport("CameraPlugin")]
			   // public static extern void PrxGetPixels32(UInt64 framehandle,  IntPtr colors);

			   //[DllImport("CameraPlugin")]
			   //public static extern void PrxGetPixels8(UInt64 framehandle, IntPtr colors);


			   //public static void GetPixels32(UInt64 framehandle, Color32[] colors)
			   //{
			   //    GCHandle handle = GCHandle.Alloc(colors, GCHandleType.Pinned);
			   //    IntPtr pointer = handle.AddrOfPinnedObject();
			   //    PrxGetPixels32(framehandle, pointer);
			   //    handle.Free();
			   //}

			   //public static void GetPixels8(UInt64 framehandle, byte[] colors)
			   //{
			   //    GCHandle handle = GCHandle.Alloc(colors, GCHandleType.Pinned);
			   //    IntPtr pointer = handle.AddrOfPinnedObject();
			   //    PrxGetPixels8(framehandle, pointer);
			   //    handle.Free();
			   //}

				
				public static int SetConfig(int handle, SceCameraConfig config)
				{
					int result = PrxCameraSetConfig(handle, config);

				//    IntPtr unmanagedAddr = Marshal.AllocHGlobal(Marshal.SizeOf(config));
				//    Marshal.StructureToPtr(config, unmanagedAddr, true);
				//    int result = PrxCameraSetConfig(handle, unmanagedAddr);
			   //     Marshal.FreeHGlobal(unmanagedAddr);
			   //     unmanagedAddr = IntPtr.Zero;
					return result;
				}

				public static int Start(int handle, SceCameraStartParameter start)
				{

					int result = PrxCameraStart(handle, start);
					return result;
				}

				public static int GetFrameData(int handle, UInt32 readmode, ref UInt64 framehandle)
				{
					return PrxCameraGetFrameData(handle, readmode, ref framehandle);
				}

				public static IntPtr getFrameIntPtr(UInt64 framehandle, int device, int level)
				{
					return PrxCameraGetFrameIntPtr(framehandle, device, level);
				}

				public static int SetCameraFrameCallback(UInt64 callback)
				{
					return PrxSetCameraFrameCallback(callback);
				}
			}
		}
	}
   
	

	
	




}
