﻿using System;
using System.Runtime.InteropServices;

using System.IO;
using UnityEngine;


using System.Runtime.CompilerServices;
using uei = UnityEngine.Internal;


// references http://www.mono-project.com/Interop_with_Native_Libraries


namespace UnityEngine
{


   namespace PS4
	{

		namespace Engines
		{

			[StructLayout(LayoutKind.Sequential, Pack = 0)]
			public struct SceMoveButtonData {
				public UInt16 digitalButtons;
				public UInt16 analogT;
			};

			[StructLayout(LayoutKind.Sequential, Pack = 0)]
			public struct SceMoveExtensionPortData {
				public UInt16 status;
				public UInt16 digital1;
				public UInt16 digital2;
				public UInt16 analogRightX;
				public UInt16 analogRightY;
				public UInt16 analogLeftX;
				public UInt16 analogLeftY;
	
				public Byte custom0,custom1,custom2,custom3,custom4;  
			};


			[StructLayout(LayoutKind.Sequential, Pack = 0), Serializable]
			public struct SceMoveTrackerState 
			{
				public Vector3 position;
				public Vector3 velocity;
				public Vector3 acceleration;
				public Quaternion orientation;
				public Vector3 angularVelocity;
				public Vector3 angularAcceleration;
				public Vector3 accelerometerPosition;      
				public Vector3 accelerometerVelocity;
				public Vector3 accelerometerAcceleration;
				public float cameraPitchAngle;
				public float cameraRollAngle;
				public SceMoveButtonData pad;
				public SceMoveExtensionPortData ext;
				public UInt64 timestamp;
				public UInt32 flags;                      
			};




			public class MoveTracker
			{

				[DllImport("MoveTrackerPlugin")]
				static extern int PrxMoveTrackerInitialise();


				[DllImport("MoveTrackerPlugin")]
				static extern int PrxMoveTrackerShutdown();


				[DllImport("MoveTrackerPlugin")]
				static extern int PrxMoveTrackerCalibrate();


				[DllImport("MoveTrackerPlugin")]
				static extern int PrxMoveTrackerUpdate(UInt64 cameraFrameHandle, int[] controllerHandles, IntPtr controllerInputs);

				[DllImport("MoveTrackerPlugin")]
				static extern int PrxMoveTrackerQueueUpdate(UInt64 cameraFrameHandle, int[] controllerHandles, IntPtr controllerInputs);


				[DllImport("MoveTrackerPlugin")]
				static extern int PrxMoveTrackerReadState(int handle, out SceMoveTrackerState data);

				[DllImport("MoveTrackerPlugin")]
				static extern int PrxMoveTrackerReadState(int handle, IntPtr ptr);

				public static int Init()
				{
					return PrxMoveTrackerInitialise();
				}

				public static int Term()
				{
					return PrxMoveTrackerShutdown();
				}

				public static int Calibrate()
				{
					return PrxMoveTrackerCalibrate();
				}

				public static int QueueUpdate(UInt64 cameraFrameHandle, int[] controllerHandles, IntPtr controllerInputs)
				{
					return PrxMoveTrackerQueueUpdate(cameraFrameHandle, controllerHandles, controllerInputs);
				}


				public static int Update(UInt64 cameraFrameHandle, int[] controllerHandles, IntPtr controllerInputs)
				{
					return PrxMoveTrackerUpdate(cameraFrameHandle, controllerHandles, controllerInputs);
				}

				// the data is output only
				// example of how to create a writeonly structure that contains an array of structures
				public static int ReadState(int controllerhandle, out SceMoveTrackerState data)
				{
					//IntPtr unmanagedAddr = Marshal.AllocHGlobal(160); //sizeof(SceMoveTrackerState )

					//data = new SceMoveTrackerState();
					//data.imageCoordinates = new SceMoveTrackerImageCoordinates[2];
					//float[] tempfloats = new float[3 * 2];

					int result = PrxMoveTrackerReadState(controllerhandle,out data);

					// copy the whole set of data into an array of floats
					//Marshal.Copy(unmanagedAddr, tempfloats, 0, 6);


					//data.imageCoordinates[0].status = (SceMoveTrackerStatus)Marshal.ReadInt32(unmanagedAddr, 0);
					//data.imageCoordinates[0].x = tempfloats[1];
					//data.imageCoordinates[0].y = tempfloats[2];

					//data.imageCoordinates[1].status = (SceMoveTrackerStatus)Marshal.ReadInt32(unmanagedAddr, 12);
					//data.imageCoordinates[1].x = tempfloats[4];
					//data.imageCoordinates[1].y = tempfloats[5];

					//Marshal.FreeHGlobal(unmanagedAddr);
					return result;
				}

			

			}



		}
   }

}