#include <camera.h>
#include <string.h>
#include "prx.h"
#include <vision/move_tracker.h>
#include <libsysmodule.h>
#include <kernel.h>
#include <sce_atomic.h>



namespace UnityCamera
{

	int32_t onionSize,garlicSize;
	off_t onionPhysAddr;
	void* onionMem = NULL;
	off_t garlicPhysAddr;
	void* garlicMem = NULL;

	ScePthread m_thread_movetracker;
	SceKernelEqueue m_queue_movetracker;

	const int numQueueEntrys = 32;
	int64_t m_queuealloc_movetracker;

	bool m_active = false;


	const int MaxTrackedMoves = 4;

	struct MoveTrackingRequest
	{
		int64_t cameraimagehandle;
		int32_t movehandles[MaxTrackedMoves];
		SceMoveTrackerControllerInput controllerInput[MaxTrackedMoves];
	};

	MoveTrackingRequest m_Requests[numQueueEntrys];
//	int m_queueIDs[numQueueEntrys];


	static void* moveTrackerThread(void* ptr);
	PRX_EXPORT int PrxMoveTrackerUpdate(int64_t cameraimagehandle, int32_t *handles, SceMoveTrackerControllerInput* controllerInputs);

	PRX_EXPORT int PrxMoveTrackerCalibrate(void)
	{
		if (m_active == false) return -1;
		return sceMoveTrackerCalibrateReset();
	}


	PRX_EXPORT int PrxMoveTrackerInitialise(void)
	{

		if (m_active == true) return -1;
		m_active = false;


		int result = sceSysmoduleLoadModule(SCE_SYSMODULE_MOVE_TRACKER);
		if (result != SCE_OK) { return result; }
		
		int32_t memalign = 16*1024;
		int memprot = SCE_KERNEL_PROT_CPU_READ|SCE_KERNEL_PROT_CPU_WRITE|SCE_KERNEL_PROT_GPU_READ|SCE_KERNEL_PROT_GPU_ALL;
		
		result = sceMoveTrackerGetWorkingMemorySize(&onionSize, &garlicSize);
		if (result != SCE_OK) { return result; }

		// allocate the memory

		result = sceKernelAllocateDirectMemory(0,SCE_KERNEL_MAIN_DMEM_SIZE, onionSize, memalign, SCE_KERNEL_WB_ONION,&onionPhysAddr);
		if (result != SCE_OK) { return result; }
		result = sceKernelMapDirectMemory( &onionMem, onionSize,memprot, 0,onionPhysAddr, memalign);
		if (result != SCE_OK) { return result; }

		result = sceKernelAllocateDirectMemory(0,SCE_KERNEL_MAIN_DMEM_SIZE, garlicSize, memalign, SCE_KERNEL_WC_GARLIC,&garlicPhysAddr);
		if (result != SCE_OK) { return result; }
		result = sceKernelMapDirectMemory( &garlicMem, garlicSize,memprot, 0,garlicPhysAddr, memalign);
		if (result != SCE_OK) { return result; }

		result = sceMoveTrackerInit(onionMem,garlicMem,4,3);
		if (result != SCE_OK) { return result; }


		result = sceKernelCreateEqueue(&m_queue_movetracker,"MoveTrackerQueue");
		if (result<0)
		{
			printf("error during sceKernelCreateEqueue: 0x%x\n",result);
			return result;
		}

		ScePthreadAttr attr;
		scePthreadAttrInit(&attr);

		result = scePthreadCreate(&m_thread_movetracker, &attr, moveTrackerThread, NULL, "MoveTrackerThread");
        if (0 > result) 
		{
            printf("scePthreadCreate() failed\n");
			return result;
        }

		scePthreadAttrDestroy(&attr);

		SceKernelSchedParam  schedparam;
		int policy;
		scePthreadGetschedparam(m_thread_movetracker, &policy, &schedparam);
		printf("policy:%d prio:%d\n",policy, schedparam.sched_priority);

		schedparam.sched_priority = 700+10;

		scePthreadSetschedparam(m_thread_movetracker, policy, &schedparam);

		//for (int id=0;id<numQueueEntrys; id++)
		//{
		//	result = sceKernelAddUserEvent(m_queue_movetracker, id);
		//	if (result<0)
		//	{
		//		printf("error during sceKernelAddUserEvent: 0x%x\n",result);
		//		return result;
		//	}
		//}
		m_queuealloc_movetracker=-1;

		m_active = true;

		return result;
	}


	static void* moveTrackerThread(void* ptr)
	{
		int res;
		int num = 32;
		SceKernelEvent ev[num];
		while(1)
		{
			//if(s_GameEnd)
			//	break;

			int out = 0;
			res = sceKernelWaitEqueue(m_queue_movetracker,ev,num,&out,NULL);
			if (res<0)
			{
				printf("moveTrackerThread queue returned with error 0x%x\n",res);
				break;
			}
//			printf("processing %d event\n", out);
			for (int evnt=0;evnt<out;evnt++)
			{
				SceKernelEvent *curEvent = &ev[evnt];
				int filter = sceKernelGetEventFilter(curEvent);
				if (filter !=  SCE_KERNEL_EVFILT_USER) continue;

				MoveTrackingRequest *ptreq = (MoveTrackingRequest *)sceKernelGetEventUserData(curEvent);
				int identry = sceKernelGetEventId(curEvent);

				PrxMoveTrackerUpdate(ptreq->cameraimagehandle,ptreq->movehandles,ptreq->controllerInput);


				res  = sceKernelDeleteUserEvent(m_queue_movetracker, identry);
				if (res<0)
				{
					printf("sceKernelDeleteUserEvent failed 0x%x\n", res);
				}
				// free the queue entry
				int64_t mask = (1<<identry);
				sceAtomicOr64(&m_queuealloc_movetracker, mask);	// set a bit to indicate that it is free

			}

		}
		scePthreadExit(NULL);
	}


	PRX_EXPORT int PrxMoveTrackerQueueUpdate(int64_t cameraimagehandle, int32_t *handles, SceMoveTrackerControllerInput* controllerInputs)
	{

		SceCameraFrameData *cameraImageData = (SceCameraFrameData *)cameraimagehandle;

		int identry = -1;
		if (m_active == false) return -1;
		while(1)
		{
			identry = __builtin_ffsll(m_queuealloc_movetracker) -1;		// find first 1 bit
			if ((identry < 0)||(identry>=numQueueEntrys))
			{

#if _DEBUG
				printf("no space in PrxMoveTrackerAddQueue queue\n");
#endif
				return -1;
			}
			
			int64_t mask = ~(1<<identry);
			int64_t oldvalue = sceAtomicAnd64(&m_queuealloc_movetracker, mask);	// clear a bit to indicate that it is in use
		
			if ((oldvalue & (1<<identry))!=0) break;	// confirm that the bit is available (might have just been taken by another thread)
			printf("bit taken ... attempting retry\n");	
		}

//		printf("PrxMoveTrackerQueueUpdate identry:%d timestamps: camera:0x%x \n",identry, cameraImageData->meta.timestamp[1]);

		int res = sceKernelAddUserEvent(m_queue_movetracker, identry);
		if (res<0)
		{
			printf("sceKernelAddUserEvent failed 0x%x\n", res);
		}



		m_Requests[identry].cameraimagehandle = cameraimagehandle;
		memcpy(m_Requests[identry].movehandles,handles,MaxTrackedMoves * sizeof(int32_t) );
		memcpy(&m_Requests[identry].controllerInput[0], controllerInputs, MaxTrackedMoves * sizeof(SceMoveTrackerControllerInput));
//		m_Requests[identry].movehandles = handles;

		res = sceKernelTriggerUserEvent(m_queue_movetracker, identry, &m_Requests[identry]);
		if (res<0)
		{
			printf("sceKernelTriggerUserEvent failed 0x%x\n",res);
		}
		return res;
	}


	PRX_EXPORT int PrxMoveTrackerUpdate(int64_t cameraimagehandle, int32_t *handles, SceMoveTrackerControllerInput* controllerInputs)
	{
		if (m_active == false) return -1;

		// Set up image 1 for tracking
		SceMoveTrackerImage images[2];
		SceCameraFrameData *imagedata = (SceCameraFrameData *)cameraimagehandle;
		images[0].data = NULL;	// do not perform tra8cking for image 0, only image 1
		images[1].exposure = imagedata->meta.exposureGain[1].exposure;
		images[1].gain = imagedata->meta.exposureGain[1].gain;
		images[1].data = (unsigned short*)imagedata->pFramePointerList[1][0];
		images[1].timestamp = imagedata->meta.timestamp[1];
		if (images[1].data == NULL)
			printf("null data from camera for move tracking\n");
		int result = sceMoveTrackerCameraUpdate(images, imagedata->meta.acceleration);
		result = sceMoveTrackerControllersUpdate(controllerInputs);

//		printf("move tracker update, timestamps: camera:0x%x controller[%d]:0x%x\n",imagedata->meta.timestamp[1], controllerInputs->num-1, controllerInputs->data[controllerInputs->num-1].timestamp);
		return result;
	}

	
	PRX_EXPORT int PrxMoveTrackerReadState(int32_t handle, SceMoveTrackerState* moveState)
	{
		if (m_active == false) return -1;
		int32_t result = sceMoveTrackerGetState(handle, sceKernelGetProcessTime()+SCE_MOVE_TRACKER_LATENCY , moveState);
		if (result>= 0)
		{
//			printf("sceMoveTrackerGetState result:0x%x trackerState.flags:0x%x trackerState.pad.digitalButtons:0x%x trackerState.pad.analogT:0x%x\n", result, moveState->flags,moveState->pad.digitalButtons,moveState->pad.analogT);
		}

		return result;
	}

	
	PRX_EXPORT int PrxMoveTrackerReadState2(int32_t handle, SceMoveTrackerState* moveState)
	{
		if (m_active == false) return -1;

		int result = sceMoveTrackerGetState(handle, SCE_MOVE_TRACKER_GET_STATE_IMAGE_TIME, moveState);
/*		if (result != 0)
		{
			printf("sceMoveTrackerGetState error:0x%x\n",result);
		}
*/		return result;
	}

	PRX_EXPORT int PrxMoveTrackerShutdown(void)
	{
		m_queuealloc_movetracker=0;		// clear the allocations ... so that no new ones can start
		int result;

		if (m_active == false) return -1;

		for (int id=0;id<numQueueEntrys; id++)
		{
			result = sceKernelDeleteUserEvent(m_queue_movetracker, id);
			if (result<0)
			{
				printf("error during sceKernelDeleteUserEvent: 0x%x\n",result);
			}
		}
		
		result = sceKernelDeleteEqueue(m_queue_movetracker);
		if (result<0)
		{
			printf("error during sceKernelDeleteEqueue: 0x%x\n",result);
		}

//return 0;
	//	result = scePthreadCancel(m_thread_movetracker);
		if (result<0)
		{
			printf("error during scePthreadCancel: 0x%x\n",result);
		}

	
		result = scePthreadJoin(m_thread_movetracker, NULL);
		if (result<0)
		{
			printf("error during scePthreadJoin: 0x%x\n",result);
		}




		int errcode = SCE_OK;
		result = sceMoveTrackerTerm();
		if (result != SCE_OK) 
		{
			printf("sceMoveTrackTerm failed\n");
			errcode = result;
		}
		

		result = sceKernelReleaseDirectMemory( onionPhysAddr, onionSize );
		if (result != SCE_OK) 
		{
			printf("sceKernelReleaseDirectMemory (onion) failed\n");
			errcode = result;
		
		}
		onionPhysAddr=0;
		onionSize=0;

		result = sceKernelReleaseDirectMemory( garlicPhysAddr, garlicSize );
		if (result != SCE_OK) 
		{
			printf("sceKernelReleaseDirectMemory (garlic) failed\n");
			errcode = result;
		}
		garlicPhysAddr=0;
		garlicSize=0;


		result = sceSysmoduleUnloadModule(SCE_SYSMODULE_MOVE_TRACKER);
		if (result != SCE_OK) 
		{
			printf("sceSysmoduleUnloadModule (SCE_SYSMODULE_MOVE_TRACKER) failed\n");
			errcode = result;
		}

		m_active = false;

		return errcode;
	}



}