#include "prx.h"

// We need to provide an export to force the expected stub library to be generated
__declspec (dllexport) void dummy()
{
}


// entry function called upon start processing 
int module_start(size_t argc, const void*argv)
{
	return 0;
}

// entry function called upon stop processing 
int module_stop(size_t argc, const void*argv)
{
	return 0;
}


//
//
//PRX_EXPORT int PrxPadTrackerInitialise()
//{
//	return 0;
//}
//
//PRX_EXPORT void PrxPadTrackerUpdate()
//{
//
//}
