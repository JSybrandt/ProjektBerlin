Saved Game plugin extension for Vita.

Folders in this project...

This folder - Contains a Visual Studio 2010 solution for building the native plugin.
Assemblies - Contails a MonoDevelop project which defines the interface between the native plugin and the scripts.
src - Contains all the source (.cpp & .h) for the plugin.
SavedGameExampleProject - Contains a Unity project which is used as a test harness and example on plugin usage.

Building the SavedGames native plugin.

When building the plugin the resulting module is automatically copied to the plugins folder in the example project, this is done as a post-build step by running copybuilds.bat.

Before you build you must first edit copybuilds.bat and at the top of the file change the line...

set UNITY_INTERNAL=1
...to...
set UNITY_INTERNAL=0

Load SavedGames.sln into Visual Studio 2010.
Select the build configuration, debug or release.
Build the solution.

Building the managed assembly.

Navigate to the assembly project and load the SonyVitaSavedGames.sln into MonoDevelop. You must use MonoDevelop, not Visual Studio for this otherwise the assembly will not work with Unity.

After building the assembly the resulting DLL is automatically copied to example project.
