using System.Runtime.InteropServices;

namespace Sony
{
	namespace PS4
	{
		namespace SavedGame
		{
			public class Main
			{
                // Initialisation.
                [DllImport("SavedGames")]
                private static extern int PrxSavedGamesInitialise();
                [DllImport("SavedGames")]
                private static extern int PrxSavedGamesTerminate();
				
				// House keeping.
				[DllImport("SavedGames")]
				private static extern int PrxSavedGamesUpdate();
				
				public static event Messages.EventHandler OnLog;
				public static event Messages.EventHandler OnLogWarning;
				public static event Messages.EventHandler OnLogError;
				
				public static void Initialise()
				{
					PrxSavedGamesInitialise();
				}

				public static void Terminate()
				{
					PrxSavedGamesTerminate();
				}

				public static void Update()
				{
					PrxSavedGamesUpdate();
					PumpMessages();
				}
				
				private static void PumpMessages()
				{
					while (Messages.HasMessage())
					{
						Messages.PluginMessage msg = new Messages.PluginMessage();
						Messages.GetFirstMessage(out msg);
						
						// Interpret the message and trigger corresponding events.
						// NOTE: If an event handler throws an exception we need to carry on processing the message pipe so wrap this code in a try/catch.
						try
						{
							SaveLoad.ProcessMessage(msg);

							switch (msg.type)
							{
								case Messages.MessageType.kSavedGame_Log:
									if (OnLog != null)
										OnLog(msg);
									break;
									
								case Messages.MessageType.kSavedGame_LogWarning:
									if (OnLogWarning != null)
										OnLogWarning(msg);
									break;
									
								case Messages.MessageType.kSavedGame_LogError:
									if (OnLogError != null)
										OnLogError(msg);
									break;
							}
						}
						catch (System.Exception ex)
						{
							UnityEngine.Debug.LogException(ex);
						}

						Messages.RemoveFirstMessage();
					}
				}
			}
		} // SavedGames
	} // PS4
} // Sony
