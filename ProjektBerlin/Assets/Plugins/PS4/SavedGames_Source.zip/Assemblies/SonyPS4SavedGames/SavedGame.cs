﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

namespace Sony
{
	namespace PS4
	{
		namespace SavedGame
		{
			public class SaveLoad
			{
				#region Types

				/// <summary>
				/// Structure defining a save game slot.
				/// </summary>
				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
				public struct SavedGameSlotParams
				{
					public int userId;

					/// <summary>
					/// Padding required for marshalling to strings
					/// </summary>
					private int reserved;

					public string titleId;

					public string dirName;
					public string fileName;

					public string newTitle;
					public string title;
					public string subTitle;
					public string detail;
					public string iconPath;
					public long sizeKiB;
				};

				/// <summary>
				/// Structure for retrieving a saved game that's just been loaded.
				/// </summary>
				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
				private struct SavedGameData
				{
					/// <summary>
					/// Size of the data in bytes.
					/// </summary>
					public int dataSize;
					private IntPtr _data;

					/// <summary>
					/// Byte array containing the data.
					/// </summary>
					public byte[] data
					{
						get
						{
							if ( _data != null && dataSize > 0 )
							{
								byte[] bytes = new byte[dataSize];
								Marshal.Copy(_data, bytes, 0, dataSize);
								return bytes;
							}
							return null;
						}
					}
				}

				[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 0)]
				public struct SaveGameSlotDetails
				{
					public long size;
					IntPtr _title;
					IntPtr _subTitle;
					IntPtr _detail;
					public int userParam;
					public long mtime;
					public UInt64 rtcTicktime;
					IntPtr _iconData;
					int iconDataSize;

					public string title { get { return Marshal.PtrToStringAnsi(_title); } }
					public string subTitle { get { return Marshal.PtrToStringAnsi(_subTitle); } }
					public string detail { get { return Marshal.PtrToStringAnsi(_detail); } }
					public UInt64 time { get { return rtcTicktime; } }

					public Texture2D icon
					{
						get
						{
							if ( iconDataSize > 0 )
							{
								byte[] bytes = new byte[iconDataSize];
								Marshal.Copy(_iconData, bytes, 0, iconDataSize);
								int iconWidth = 512;
								int iconHeight = 512;
								Texture2D icon = new Texture2D(iconWidth, iconHeight);
								icon.LoadImage(bytes);
								return icon;
							}
							return null;
						}
					}
					public bool hasIcon
					{
						get
						{
							return iconDataSize > 0;
						}
					}
				};

				#endregion

				#region Imported Native Methods

				[DllImport("SavedGames")] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxIsSavedGamesDialogOpen();
				[DllImport("SavedGames")] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxIsSavedGamesBusy();
				[DllImport("SavedGames")] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxSavedGameSave( byte[] data, int dataSize, ref SavedGameSlotParams slotParams, bool useDialogs );
				[DllImport("SavedGames")] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxSavedGameLoad( ref SavedGameSlotParams slotParams, bool useDialogs );
				[DllImport("SavedGames")]
				private static extern uint PrxSavedGameExists( ref SavedGameSlotParams slotParams );
				[DllImport("SavedGames")]
				private static extern uint PrxSavedGameGetDetails( ref SavedGameSlotParams slotParams, out SaveGameSlotDetails slotDetails );
				[DllImport("SavedGames")] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxSavedGameDelete( ref SavedGameSlotParams slotParams, bool useDialogs );
				[DllImport("SavedGames")] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxSavedGameGetGameData( out IntPtr data, out int dataSize );
				[DllImport("SavedGames")]
				private static extern int PrxSavedGamesInitialise();
				[DllImport("SavedGames")]
				private static extern int PrxSavedGamesTerminate();
				[DllImport("SavedGames")]
				private static extern int PrxSavedGamesUpdate();

				#endregion

				#region Event Handlers

				public static event Messages.EventHandler OnGameSaved;
				public static event Messages.EventHandler OnGameLoaded;
				public static event Messages.EventHandler OnGameDeleted;
				public static event Messages.EventHandler OnCanceled;
				public static event Messages.EventHandler OnSaveError;
				public static event Messages.EventHandler OnLoadError;
				public static event Messages.EventHandler OnLoadNoData;

				#endregion

				/// <summary>
				/// Is the save/load dialog open?
				/// </summary>
				public static bool IsDialogOpen
				{
					get { return PrxIsSavedGamesDialogOpen(); }
				}

				/// <summary>
				/// Is the save/load process busy?
				/// </summary>
				public static bool IsBusy
				{
					get { return PrxIsSavedGamesBusy(); }
				}

				/// <summary>
				/// When loading is complete the OnGameLoaded event will fire
				/// at which point <see cref="GetLoadedGame()"/> can be called
				/// to retrieve the data.
				/// </summary>
				/// <returns>
				/// False if the plugin is not initialized. Request will be ignored.
				/// </returns>
				public static bool LoadGame ( SavedGameSlotParams slotParams, bool useDialogs )
				{
					return PrxSavedGameLoad(ref slotParams, useDialogs);
				}

				/// <returns>
				/// An error code. -1 if the plugin is not initialized,
				/// otherwise the result of sceSaveDataMount.
				/// </returns>
				public static uint Exists ( SavedGameSlotParams slotParams )
				{
					return PrxSavedGameExists(ref slotParams);
				}

				/// <returns>
				/// An error code. -1 if the plugin is not initialized,
				/// otherwise the result of sceSaveDataMount.
				/// </returns>
				public static uint GetDetails ( SavedGameSlotParams slotParams,	 out SaveGameSlotDetails slotDetails )
				{
					slotDetails.size = 0x48;	// sizeof(SaveGameSlotDetails) from SaveGame.h
					return PrxSavedGameGetDetails(ref slotParams, out slotDetails);
				}

				/// <summary>
				/// Save a game to a specific slot with no dialogs (unless error).
				/// </summary>
				/// <returns>
				/// False if the plugin is not initialized. Request will be ignored.
				/// </returns>
				public static bool SaveGame ( byte[] data, SavedGameSlotParams slotParams, bool useDialogs )
				{
					return PrxSavedGameSave(data, data.Length,	ref slotParams, useDialogs);
				}

				/// <summary>
				/// Delete a game from a specific slot with no dialogs (unless error).
				/// </summary>
				/// <returns>
				/// False if the plugin is not initialized. Request will be ignored.
				/// </returns>
				public static bool Delete ( SavedGameSlotParams slotParams, bool useDialogs )
				{
					return PrxSavedGameDelete(ref slotParams, useDialogs);
				}

				/// <summary>
				/// Retrieve the data that was just loaded.
				/// </summary>
				public static byte[] GetLoadedGame ()
				{
				//	SavedGameData data = new SavedGameData();
					IntPtr _data;
					int dataSize;

					if ( PrxSavedGameGetGameData(out _data, out dataSize) )
					{
						byte[] bytes = new byte[dataSize];
						Marshal.Copy(_data, bytes, 0, dataSize);
						return bytes;
					}

					return null;
				}

				/// <summary>
				/// Process messages.
				/// </summary>
				internal static void ProcessMessage ( Messages.PluginMessage msg )
				{
					// Interpret the message and trigger corresponding events.
					switch ( msg.type )
					{
						case Messages.MessageType.kSavedGame_GameSaved:
							if ( OnGameSaved != null )
								OnGameSaved(msg);
							break;

						case Messages.MessageType.kSavedGame_GameLoaded:
							if ( OnGameLoaded != null )
								OnGameLoaded(msg);
							break;

						case Messages.MessageType.kSavedGame_GameDeleted:
							if ( OnGameDeleted != null )
								OnGameDeleted(msg);
							break;

						case Messages.MessageType.kSavedGame_Canceled:
							if ( OnCanceled != null )
								OnCanceled(msg);
							break;

						case Messages.MessageType.kSavedGame_SaveNoSpace:
						case Messages.MessageType.kSavedGame_SaveNotMounted:
						case Messages.MessageType.kSavedGame_SaveGenericError:
							if ( OnSaveError != null )
								OnSaveError(msg);
							break;

						case Messages.MessageType.kSavedGame_LoadCorrupted:
							if ( OnLoadError != null )
								OnLoadError(msg);
							break;
						case Messages.MessageType.kSavedGame_LoadNoData:
							if ( OnLoadNoData != null )
								OnLoadNoData(msg);
							break;
					}
				}
			}
		} // SavedGames
	} // PS4
} // Sony
