#include <stdio.h>
#include <kernel.h>

#include <libsysmodule.h>

#include "prx.h"
#include "SavedGame.h"
//#include "SavedGameList.h"		// todo
#include "IOThread.h"
#include "MessagePipe.h"

// standard results for module startup
#define SCE_KERNEL_START_SUCCESS		(0)
#define SCE_KERNEL_START_FAILED			(2)

int pluginstate = -1;		// pluginstate >=0 is good

extern "C" int module_start(size_t sz, const void*arg)
{
	bool res = SCE_KERNEL_START_SUCCESS;

	if (res == SCE_KERNEL_START_SUCCESS)
	{
		pluginstate = 0;
	}

	return res;
}

namespace UnitySavedGames
{
	IOThread s_IOThread;

	PRX_EXPORT int PrxSavedGamesInitialise()
	{
		if (pluginstate<0) return 0;
		gSavedGame.Initialise();
		gSavedGame.SetIOThread(&s_IOThread);
		return 0;
	}

	PRX_EXPORT int PrxSavedGamesTerminate()
	{
		if (pluginstate<0) return 0;
		gSavedGame.Terminate();
		return 0;
	}

	PRX_EXPORT void PrxSavedGamesUpdate()
	{
		if (pluginstate<0) return;
		gSavedGame.Update();
	}


	PRX_EXPORT bool PrxIsSavedGamesDialogOpen()
	{
		if (pluginstate<0) return false;
		return gSavedGame.IsDialogOpen();
	}

	PRX_EXPORT bool PrxIsSavedGamesBusy()
	{
		if (pluginstate<0) return false;
		return gSavedGame.IsBusy() ;
	}

	PRX_EXPORT bool PrxSavedGameGetGameData(void** data, int *size )
	{
		if (pluginstate<0) return false;
		if(s_IOThread.GetBuffer())
		{
			*data  = s_IOThread.GetBuffer();
			*size  = s_IOThread.GetBufferSize();
			return true;
		}

		Messages::LogError("SavedGame::%s@L%d - No data loaded", __FUNCTION__, __LINE__);
		return false;
	}

}; // UnitySavedGames
