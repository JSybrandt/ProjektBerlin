/* SCE CONFIDENTIAL
 * PlayStation(R)4 Programmer Tool Runtime Library Release 01.600.051
 * Copyright (C) 2013 Sony Computer Entertainment Inc.
 * All Rights Reserved.
 */
#include <stdio.h>
#include <string.h>
#include <_fs.h>
#include <sceerror.h>
#include <save_data.h>
#include <save_data_dialog.h>
#include <stdlib.h>
#include "config.h"
#include "util.h"


namespace save_data {
namespace util {

static void setupSceSaveDataMount(SceSaveDataMount *mount,
								  const SceUserServiceUserId userId,
								  const SceSaveDataTitleId *titleId,
								  const SceSaveDataDirName *dirName,
								  const SceSaveDataMountMode mode, 
								  const size_t sizeKiB);
static int32_t setParam(const SceSaveDataMountPoint *mountPoint, const SceSaveDataDirName *dirName,  const char *title, const char *subTitle, const char *detail);
static int32_t createFile(const char *mountPoint, 
							const char *fileName, const size_t dataSize, const void *dataToSave,
							 bool dialogEnabled);
static int32_t writeFile(const char *mountPoint, const char *fileName,
						  const size_t dataSize, const void * fileData, bool dialogEnabled);
static int32_t loadFile(const char *mountPoint, const char *fileName, uint8_t** loadeddata, __int64_t *datasize, bool dialogEnabled );
static void dumpData(const char *title, const uint8_t *data, const size_t dataSize, const size_t dumpSize);
static int32_t saveIcon(SceSaveDataMountPoint *mountPoint, const char *pngFileName);



// create save data
int32_t create(const SceUserServiceUserId userId,
			   const SceSaveDataTitleId *titleId,
			   const SceSaveDataDirName *dirName,
				const char *fileName, const size_t fileSize,const void *fileData,
			   SceSaveDataBlocks *requiredBlocks,
			   const char *title,
			   const char *subTitle,
			   const char *detail,
			   const char *iconPath,
			   bool dialogEnabled
			   )
{
	TRACE;

	int32_t ret = SCE_OK;
	// mount
	uint32_t sizeKiB = (fileSize+1023)/1024;
	SceSaveDataMount mount;
	setupSceSaveDataMount(&mount,
						  userId,
						  titleId ? (titleId->data[0]!=0 ? titleId: NULL) : NULL,
						  dirName,
						  (SCE_SAVE_DATA_MOUNT_MODE_CREATE | SCE_SAVE_DATA_MOUNT_MODE_WRONLY),
						  sizeKiB
						 );
	SceSaveDataMountResult mountResult;
	memset(&mountResult, 0x00, sizeof(mountResult));
	ret = sceSaveDataMount(&mount, &mountResult);
	if(ret < SCE_OK)
	{
		EPRINT("sceSaveDataMount : 0x%08x(%s)\n", ret, dirName->data);
		if(requiredBlocks)
		{
			*requiredBlocks = mountResult.requiredBlocks;
		}	
		return ret;
	}

	SceSaveDataMountPoint *mountPoint = &mountResult.mountPoint;

	// set the parameters

	ret = setParam(mountPoint, dirName, title, subTitle, detail);
	if(ret < SCE_OK)
	{
		EPRINT("setParam : 0x%08x(%s)\n", ret, mountPoint->data);
		goto End;
	}

	// write file

	ret = createFile(mountPoint->data, fileName, fileSize, fileData,  dialogEnabled);
	if(ret < SCE_OK)
	{
		EPRINT("createFile : 0x%08x(%s/%s)\n", ret, mountPoint->data, SAVE_DATA_FILENAME0);
		goto End;
	}

	// write icon0.png
	{
		const char *pngFileName = iconPath;
		ret = saveIcon(mountPoint, pngFileName);
		if(ret < SCE_OK)
		{
			printf("unable to write savegame icon file, perhaps it's not the correct format?\n");
			EPRINT("saveIcon : 0x%x\n", ret);
			goto End;
		}
	}

	ret = SCE_OK;

End:

	// unmount

	int32_t ret2 = sceSaveDataUmount(mountPoint);
	if(ret2 < SCE_OK)
	{
		EPRINT("sceSaveDataUmount : 0x%08x\n", ret2);
		// through
	}

	return ret;
}


// read save data
int32_t read(const SceUserServiceUserId userId,
			 const SceSaveDataTitleId *titleId,
			 const SceSaveDataDirName *dirName,
			 const char *fileName, uint8_t **buffer, int64_t *filesize, SceSaveDataParam *param, bool dialogEnabled)
{
	TRACE;

	int32_t ret = SCE_OK;

	// mount

	SceSaveDataMount mount;
	setupSceSaveDataMount(&mount,
						userId,
						  titleId ? (titleId->data[0]!=0 ? titleId: NULL) : NULL,
						  dirName,
						  SCE_SAVE_DATA_MOUNT_MODE_RDONLY,		// read only
						  0  );
	SceSaveDataMountResult mountResult;
	memset(&mountResult, 0x00, sizeof(mountResult));
	ret = sceSaveDataMount(&mount, &mountResult);
	if(ret < SCE_OK)
	{
		EPRINT("sceSaveDataMount : 0x%08x(%s)\n", ret, dirName->data);
		return ret;
	}

	SceSaveDataMountPoint *mountPoint = &mountResult.mountPoint;

	// read file

	ret = loadFile(mountPoint->data, fileName, buffer,filesize, dialogEnabled);
	if(ret < SCE_OK)
	{
		EPRINT("loadFile : 0x%x(%s/%s)\n", ret, mountPoint->data, SAVE_DATA_FILENAME0);
		goto End;
	}

	ret = SCE_OK;

End:
	// unmount

	int32_t ret2 = sceSaveDataUmount(mountPoint);
	if(ret2 < SCE_OK)
	{
		EPRINT("sceSaveDataUmount : 0x%08x\n", ret2);
		// through
	}

	return ret;
}


// add save data
int32_t write(const SceUserServiceUserId userId,
			  const SceSaveDataTitleId *titleId,
			  const SceSaveDataDirName *dirName,
			  const char *fileName, const size_t fileSize, const void * fileData,
			  SceSaveDataBlocks *requiredBlocks,
			  bool dialogEnabled
			  )
{
	TRACE;

	int32_t ret = SCE_OK;

	// mount

	SceSaveDataMount mount;
	setupSceSaveDataMount(&mount,
						userId,
						  titleId ? (titleId->data[0]!=0 ? titleId: NULL) : NULL,
						  dirName,
						  SCE_SAVE_DATA_MOUNT_MODE_WRONLY,		// read/write
						  0);
	SceSaveDataMountResult mountResult;
	memset(&mountResult, 0x00, sizeof(mountResult));
	ret = sceSaveDataMount(&mount, &mountResult);
	if(ret < SCE_OK)
	{
		EPRINT("sceSaveDataMount : 0x%08x(%s)\n", ret, dirName->data);
		if(requiredBlocks)
		{
			*requiredBlocks = mountResult.requiredBlocks;
		}
		return ret;
	}

	SceSaveDataMountPoint *mountPoint = &mountResult.mountPoint;

	// add file
	ret = writeFile(mountPoint->data, fileName, fileSize,  fileData, dialogEnabled);
	if(ret < SCE_OK)
	{
		EPRINT("createFile : 0x%08x(%s/%s)\n", ret, mountPoint->data, fileName);
		goto End;
	}

	ret = SCE_OK;

End:
	// unmount

	int32_t ret2 = sceSaveDataUmount(mountPoint);
	if(ret2 < SCE_OK)
	{
		EPRINT("sceSaveDataUmount : 0x%08x\n", ret2);
		// through
	}

	return ret;
}


// add save data
int32_t writeWithParams(const SceUserServiceUserId userId,
 const SceSaveDataTitleId *titleId,
 const SceSaveDataDirName *dirName,
 const char *fileName, const size_t fileSize, const void * fileData,
 SceSaveDataBlocks *requiredBlocks,
 const char *title,
 const char *subTitle,
 const char *detail,
 const char *iconPath, bool dialogEnabled )
{
	TRACE;
	int32_t ret = SCE_OK;
	// mount
	SceSaveDataMount mount;
	setupSceSaveDataMount(&mount,
						  userId,
						  titleId ? (titleId->data[0]!=0 ? titleId: NULL) : NULL,
						  dirName,
						  SCE_SAVE_DATA_MOUNT_MODE_WRONLY, // read/write
						  0
						 );
	SceSaveDataMountResult mountResult;
	memset(&mountResult, 0x00, sizeof(mountResult));
	ret = sceSaveDataMount(&mount, &mountResult);
	if(ret < SCE_OK)
	{
		EPRINT("sceSaveDataMount : 0x%08x(%s)\n", ret, dirName->data);
		if(requiredBlocks)
		{
			*requiredBlocks = mountResult.requiredBlocks;
		}
		return ret;
	}

	SceSaveDataMountPoint *mountPoint = &mountResult.mountPoint;

	// set the parameters

	ret = setParam(mountPoint, dirName, title, subTitle, detail);
	if(ret < SCE_OK)
	{
		EPRINT("setParam : 0x%08x(%s)\n", ret, mountPoint->data);
		goto End;
	}

	// write file

	ret = writeFile(mountPoint->data, fileName, fileSize, fileData, dialogEnabled);
	if(ret < SCE_OK)
	{
		EPRINT("writeFile : 0x%08x(%s/%s)\n", ret, mountPoint->data, fileName);
		goto End;
	}

	// write icon0.png
	{
		const char *pngFileName = iconPath;
		ret = saveIcon(mountPoint, pngFileName);
		if(ret < SCE_OK)
		{
			printf("unable to write savegame icon file, perhaps it's not the correct format?\n");
			EPRINT("saveIcon : 0x%x\n", ret);
			goto End;
		}
	}

	ret = SCE_OK;

End:
	// unmount
	int32_t ret2 = sceSaveDataUmount(mountPoint);
	if(ret2 < SCE_OK)
	{
		EPRINT("sceSaveDataUmount : 0x%08x\n", ret2);
		// through
	}
	return ret;
}

// search save data directories
int32_t search(const SceUserServiceUserId userId,
			   const SceSaveDataTitleId *titleId,
			   SceSaveDataDirName *dirNames, const uint32_t dirNameNum, uint32_t *hitNum)
{
	TRACE;

	int32_t ret = SCE_OK;

	// search

	SceSaveDataDirNameSearchCond cond;
	memset(&cond, 0x00, sizeof(SceSaveDataDirNameSearchCond));
	cond.userId = userId;
	cond.titleId = titleId;
	cond.key = SCE_SAVE_DATA_SORT_KEY_DIRNAME;						// sort of dir name
	cond.order = SCE_SAVE_DATA_SORT_ORDER_DESCENT;					// descent

	SceSaveDataDirNameSearchResult result;
	memset(&result, 0x00, sizeof(result));
	result.dirNames = dirNames;
	result.dirNamesNum = dirNameNum;

	ret = sceSaveDataDirNameSearch(&cond, &result);
	if(ret < SCE_OK)
	{
		EPRINT("sceSaveDataDirNameSearch : 0x%08x\n", ret);
		return ret;
	}
	*hitNum = result.hitNum;

	if ( *hitNum >= dirNameNum )
	{
		EPRINT("sceSaveDataDirNameSearch : Found more than the max save games allowed. Max size of SceSaveDataDirName array is %d. sceSaveDataDirNameSearch returned %d save games. Clamping to array size.\n", dirNameNum, *hitNum);
		*hitNum = dirNameNum;
	}

	// show result

	PRINT("search success : \n");
	for(uint32_t i=0; i<result.hitNum; i++)
	{
		PRINT(" [%u] %s\n", i, result.dirNames[i].data);
	}

	return SCE_OK;
}


// delete save data
int32_t del(const SceUserServiceUserId userId,
			const SceSaveDataTitleId *titleId,
			const SceSaveDataDirName *dirName,
			 bool dialogEnabled)
{
	TRACE;

	int32_t ret = SCE_OK;

	// delete

	SceSaveDataDelete del;
	memset(&del, 0x00, sizeof(SceSaveDataDelete));
	del.userId = userId;
	del.titleId = titleId ? (titleId->data[0]!=0 ? titleId: NULL) : NULL,
	del.dirName = dirName;
	ret = sceSaveDataDelete(&del);
	if(ret < SCE_OK)
	{
		EPRINT("sceSaveDataDelete : 0x%08x\n", ret);
		return ret;
	}

	if (dialogEnabled)
	{
		sceSaveDataDialogProgressBarSetValue(SCE_SAVE_DATA_DIALOG_PROGRESSBAR_TARGET_BAR_DEFAULT, 100);
	}
	PRINT("delete success : %s\n", dirName->data);

	return SCE_OK;
}

static inline size_t ceil(size_t x, size_t a)
{
	return (((x) + ((a) - 1)) & ~((a) - 1));
}

//-----------------------------------------------------------------------------
// internal use API
//-----------------------------------------------------------------------------
// setup SceSaveDataMount
static void setupSceSaveDataMount(SceSaveDataMount *mount,
								  const SceUserServiceUserId userId,
								  const SceSaveDataTitleId *titleId,
								  const SceSaveDataDirName *dirName,
								  const SceSaveDataMountMode mode, 
								  const size_t sizeKiB)
{
	memset(mount, 0x00, sizeof(SceSaveDataMount));
	mount->userId = userId;
	mount->titleId = titleId;
	mount->dirName = dirName;

	// from save_data_orbis.cpp

	uint32_t fixedRequirement = 0x30;		// number of blocks required as an overhead ... this was calculated by calling sceSaveDataGetMountInfo() and watching available space (actually 0x2c is required)

	uint32_t dataBlockSizeKiB = SCE_SAVE_DATA_BLOCK_SIZE/1024;
	size_t alignedDataSizeKiB = ceil(sizeKiB, (SCE_SAVE_DATA_BLOCK_SIZE/1024));
	mount->blocks = alignedDataSizeKiB/dataBlockSizeKiB + fixedRequirement;

	// there is a minimumn size to save data
	if (mount->blocks < SCE_SAVE_DATA_BLOCKS_MIN ) { mount->blocks = SCE_SAVE_DATA_BLOCKS_MIN; }

	mount->mountMode = mode;
}


// setup parameters
static int32_t setParam(const SceSaveDataMountPoint *mountPoint, const SceSaveDataDirName *dirName,  const char *title, const char *subTitle, const char *detail)
{
	int32_t ret = SCE_OK;

	SceSaveDataParam param;
	memset(&param, 0x00, sizeof(param));


	strncpy(param.title, title, SCE_SAVE_DATA_TITLE_MAXSIZE-1);
	param.title[SCE_SAVE_DATA_TITLE_MAXSIZE-1] = '\0';

	strncpy(param.subTitle, subTitle, SCE_SAVE_DATA_SUBTITLE_MAXSIZE-1);
	param.subTitle[SCE_SAVE_DATA_SUBTITLE_MAXSIZE-1] = '\0';

	strncpy(param.detail, detail, SCE_SAVE_DATA_DETAIL_MAXSIZE-1);
	param.detail[SCE_SAVE_DATA_DETAIL_MAXSIZE-1] = '\0';

	param.userParam = SAVE_DATA_PARAM_USERPARAM;

	ret = sceSaveDataSetParam(mountPoint,
							  SCE_SAVE_DATA_PARAM_TYPE_ALL,
							  &param, sizeof(param));
	if(ret < SCE_OK)
	{
		EPRINT("sceSaveDataSetParam : 0x%08x\n", ret);
		return ret;
	}

	return SCE_OK;
}


static int32_t createFile(const char *mountPoint, 
							const char *fileName, const size_t dataSize, const void *dataToSave,
							 bool dialogEnabled)
{
	int32_t ret = SCE_OK;

	// write file
	char path[SAVE_DATA_FILEPATH_LENGTH + 1];
	snprintf(path, sizeof(path), "%s/%s", mountPoint, fileName);
	int fd = sceKernelOpen(path, SCE_KERNEL_O_WRONLY|SCE_KERNEL_O_TRUNC|SCE_KERNEL_O_CREAT, SCE_KERNEL_S_IRWU);
	if(fd < SCE_OK)
	{
		EPRINT("sceKernelOpen : 0x%08x(%s)\n", fd, path);
		return fd;
	}
	uint32_t BufSize=256*1024;

	size_t wsize = BufSize;
	uint32_t rate = 0;
	uint8_t *curWriteLocation = (uint8_t *)dataToSave;
	size_t totalWritten = 0;

	for(int i=0; i<dataSize; i+=BufSize)
	{
		if((dataSize - i) < BufSize)
			wsize = dataSize - i;

		ret = static_cast<int32_t>(sceKernelWrite(fd, curWriteLocation, wsize));
		if(ret < SCE_OK)
		{
			EPRINT("sceKernelWrite : 0x%08x(%s)\n", ret, path);
			sceKernelClose(fd);
			return ret;
		}
		totalWritten+=wsize;
		if (dialogEnabled)
		{
			rate = (totalWritten * 100)/dataSize;
			sceSaveDataDialogProgressBarSetValue(SCE_SAVE_DATA_DIALOG_PROGRESSBAR_TARGET_BAR_DEFAULT,
												 rate);
		}
		curWriteLocation+=wsize;
	}
	sceKernelClose(fd);
//	free(dummyBuf);

	if (dialogEnabled)
	{
		sceSaveDataDialogProgressBarSetValue(SCE_SAVE_DATA_DIALOG_PROGRESSBAR_TARGET_BAR_DEFAULT,
											 100);
	}

	TRACE;PRINT("create file success : %s\n", path);

	return SCE_OK;
}


// create file
static int32_t writeFile(const char *mountPoint, const char *fileName,
						  const size_t dataSize,  const void * fileData, bool dialogEnabled)
{
	int32_t ret = SCE_OK;

	// write file

	char path[SAVE_DATA_FILEPATH_LENGTH + 1];
	snprintf(path, sizeof(path), "%s/%s", mountPoint, fileName);
	int fd = sceKernelOpen(path, SCE_KERNEL_O_WRONLY|SCE_KERNEL_O_TRUNC|SCE_KERNEL_O_CREAT, SCE_KERNEL_S_IRWU);
	if(fd < SCE_OK)
	{
		EPRINT("sceKernelOpen : 0x%08x(%s)\n", fd, path);
		return fd;
	}
	uint32_t dummyBufSize = 64*1024;

	uint32_t wsize = dummyBufSize;
	uint32_t rate = 0;
	const char * curData = (const char *)fileData;
	for(int i=0; i<dataSize; i+=dummyBufSize)
	{
		if((dataSize - i) < dummyBufSize)
			wsize = dataSize - i;

		ret = static_cast<int32_t>(sceKernelWrite(fd, curData, wsize));
		if(ret < SCE_OK)
		{
			EPRINT("sceKernelWrite : 0x%08x(%s)\n", ret, path);
			sceKernelClose(fd);
			return ret;
		}
		
		if (dialogEnabled)
		{
			rate = (i * 100)/dataSize;
			sceSaveDataDialogProgressBarSetValue(SCE_SAVE_DATA_DIALOG_PROGRESSBAR_TARGET_BAR_DEFAULT,
											 rate);
		}
		curData+=wsize;
	}
	sceKernelClose(fd);

	if (dialogEnabled)
	{
		sceSaveDataDialogProgressBarSetValue(SCE_SAVE_DATA_DIALOG_PROGRESSBAR_TARGET_BAR_DEFAULT,
											 100);
	}

	TRACE;PRINT("create file success : %s\n", path);

	return SCE_OK;
}

// load and dump file
static int32_t loadFile(const char *mountPoint, const char *fileName, uint8_t** loadeddata, __int64_t *datasize, bool dialogEnabled )
{
	int32_t ret = SCE_OK;

	char path[SAVE_DATA_FILEPATH_LENGTH + 1];
	snprintf(path, sizeof(path), "%s/%s", mountPoint, fileName);
	SceKernelStat st;
	ret = sceKernelStat(path, &st);
	if(ret < SCE_OK)
	{
		EPRINT("sceKernelStat : 0x%08x(%s)\n", ret, path);
		return ret;
	}

	// allocate memory

	uint8_t *data = new uint8_t[st.st_size];
	if(!data)
	{
		EPRINT("data == NULL\n");
		return -1;
	}
	// load file

	int fd = sceKernelOpen(path, SCE_KERNEL_O_RDONLY, SCE_KERNEL_S_INONE);
	if(fd < SCE_OK)
	{
		EPRINT("sceKernelOpen : 0x%08x(%s)\n", fd, path);
		delete [] data;
		return fd;
	}


	size_t buffersize=64*1024;
	uint8_t *curData = data;
	size_t totalsize  =  static_cast<size_t>(st.st_size);
	size_t amountToRead =  totalsize;
	while(amountToRead>0)
	{
		size_t thisRead = amountToRead<buffersize ? amountToRead : buffersize;
		ret = static_cast<int32_t>(sceKernelRead(fd, curData, thisRead));
		if(ret < SCE_OK)
		{
			EPRINT("sceKernelRead : 0x%08x(%s)\n", ret, path);
			goto End;
		}

		amountToRead -= thisRead;
		curData+= thisRead;
		if (dialogEnabled)
		{
			sceSaveDataDialogProgressBarSetValue(SCE_SAVE_DATA_DIALOG_PROGRESSBAR_TARGET_BAR_DEFAULT, ((totalsize-amountToRead)*100)/totalsize);
		}
	};


	*loadeddata = data;
	*datasize = st.st_size;


	ret = SCE_OK;

End:
	sceKernelClose(fd);

	return ret;
}




int32_t loadFile(const char *path, uint8_t **data, size_t *data_size)
{
	int32_t ret = SCE_OK;

	SceKernelStat st;
	ret = sceKernelStat(path, &st);
	if(ret < SCE_OK)
	{
		EPRINT("sceKernelStat : 0x%08x(%s)\n", ret, path);
		return ret;
	}

	// allocate memory

	*data = new uint8_t[st.st_size];
	if(!*data)
	{
		EPRINT("*data == NULL\n");
		return -1;
	}

	// load file

	int fd = sceKernelOpen(path, SCE_KERNEL_O_RDONLY, SCE_KERNEL_S_INONE);
	if(fd < SCE_OK)
	{
		EPRINT("sceKernelOpen : 0x%08x(%s)\n", fd, path);
		delete [] data;
		return fd;
	}
	ret = static_cast<int32_t>(sceKernelRead(fd, *data, static_cast<size_t>(st.st_size)));
	if(ret < SCE_OK)
	{
		EPRINT("sceKernelRead : 0x%08x(%s)\n", ret, path);
		goto End;
	}
	sceKernelClose(fd);
	*data_size = st.st_size;

	return SCE_OK;

End:
	sceKernelClose(fd);
	delete [] *data;
	*data = NULL;

	return ret;
}


// save icon0.png
static int32_t saveIcon(SceSaveDataMountPoint *mountPoint, const char *pngPath)
{
	int32_t ret = SCE_OK;

	uint8_t *data = NULL;
	size_t data_size = 0;

	char filePath[SAVE_DATA_FILEPATH_LENGTH + 1];

	strncpy(filePath,pngPath,SAVE_DATA_FILEPATH_LENGTH);

	ret = loadFile(filePath, &data, &data_size);
	if(ret < SCE_OK)
	{
		EPRINT("loadFile : 0x%x\n", ret);
		return ret;
	}

	SceSaveDataIcon icon;
	memset(&icon, 0x00, sizeof(icon));
	icon.buf = data;
	icon.bufSize = data_size;
	icon.dataSize = data_size;

	ret = sceSaveDataSaveIcon(mountPoint, &icon);
	if(ret < SCE_OK)
	{
		EPRINT("sceSaveDataSaveIcon : 0x%x\n", ret);
		delete [] data;
		return ret;
	}
	delete [] data;

	return SCE_OK;
}
}	// namespace util {
}	// namespace save_data {
