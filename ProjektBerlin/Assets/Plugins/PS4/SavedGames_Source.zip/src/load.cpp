﻿/* SCE CONFIDENTIAL
 * PlayStation(R)4 Programmer Tool Runtime Library Release 01.600.051
 * Copyright (C) 2013 Sony Computer Entertainment Inc.
 * All Rights Reserved.
 */

#include <kernel.h>
#include <sceerror.h>
#include <save_data.h>
#include <save_data_dialog.h>
#include "config.h"
#include "util.h"
#include "util_dialog.h"

#include "SavedGame.h"

using namespace save_data::util_dialog;


namespace UnitySavedGames {



//-----------------------------------------------------------------------------
// Update
//-----------------------------------------------------------------------------
int32_t SavedGame::updateLoad(void)
{
	int32_t ret = SCE_OK;

	SceCommonDialogStatus status = sceSaveDataDialogUpdateStatus();
	//PRINT("status : %d, %d\n", m_loadState, status);

	// display

	// flow

	switch(m_loadState)
	{
	case Load::STATE_UNKNOWN:
		PRINT("STATE_UNKNOWN\n");
		if(m_IOThread->isReady())
		{
			m_loadState = Load::STATE_JOB_SEARCH_START;
		}
		break;

	case Load::STATE_JOB_SEARCH_START:
		PRINT("STATE_JOB_SEARCH_START\n");
		m_IOThread->startJob(iStartSearch, iEndSearch, this);
		m_loadState = Load::STATE_JOB_SEARCH;
		break;

	case Load::STATE_JOB_SEARCH:
		PRINT("STATE_JOB_SEARCH\n");
		if(m_IOThread->isJobRunning() == false)
		{
			if(m_errorCode < SCE_OK)
			{
				m_loadState = Load::STATE_SHOW_ERROR_START;
			}
			else
			{
				if(m_searchedDirNum == 0)
				{
					m_loadState = Load::STATE_SHOW_NODATA_START;
				}
				else
				{
					m_loadState = Load::STATE_SHOW_LIST_START;
				}
			}
		}
		break;

	case Load::STATE_SHOW_LIST_START:
		PRINT("STATE_SHOW_LIST_START\n");
		ret = openDialogList(SCE_SAVE_DATA_DIALOG_TYPE_LOAD,
							 m_userId, NULL, m_searchedDirNames, m_searchedDirNum, m_ioThreadedSlotParams.newTitle);
		if(ret < SCE_OK)
		{
			EPRINT("openDialogList : 0x%x\n", ret);
			return ret;
		}
		m_loadState = Load::STATE_SHOW_LIST;
		break;

	case Load::STATE_SHOW_LIST:
		//PRINT("STATE_SHOW_LIST\n");
		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			memset(&m_selectedDirName, 0x00, sizeof(m_selectedDirName));
			SceSaveDataParam param;
			memset(&param, 0x00, sizeof(param));

			SceSaveDataDialogResult result;
			memset(&result, 0x00, sizeof(SceSaveDataDialogResult));
			result.dirName = &m_selectedDirName;
			result.param = &param;

			ret = sceSaveDataDialogGetResult(&result);
			if(ret < SCE_OK)
			{
				EPRINT("sceSaveDataDialogGetResult : 0x%x\n", ret);
				m_loadState = Load::STATE_FINISH;
			}
			else
			{
				if(result.result == SCE_COMMON_DIALOG_RESULT_OK)
				{
					m_loadState = Load::STATE_SHOW_LOAD_START;
				}
				else if(result.result == SCE_COMMON_DIALOG_RESULT_USER_CANCELED)
				{
					m_loadState = Load::STATE_CANCELED;
				}
				else
				{
					m_loadState = Load::STATE_SHOW_ERROR_START;
					m_errorCode = result.result;
				}

				// display
				m_Result = result.result;
			}
		}
		break;

	case Load::STATE_SHOW_LOAD_START:
		PRINT("STATE_SHOW_LOAD_START : %d\n", status);
		// start thread
		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			m_callClose = false;
			ret = openDialogOperating(SCE_SAVE_DATA_DIALOG_TYPE_LOAD,
									  m_userId, NULL, &m_selectedDirName, m_ioThreadedSlotParams.newTitle);
			if(ret < SCE_OK)
			{
				EPRINT("openDialogOperating : 0x%x\n", ret);
				return ret;
			}
		}
		else if(SCE_COMMON_DIALOG_STATUS_RUNNING == status)
		{
			ret = sceSaveDataDialogIsReadyToDisplay();
			if(ret <= 0)
			{
				// not ready
				PRINT("sceSaveDataDialogIsReadyToDisplay : 0x%x\n", ret);
				break;
			}

			m_IOThread->startJob(iStartLoad, iEndLoad, this);
			m_loadState = Load::STATE_SHOW_LOAD;
		}
		break;

	case Load::STATE_SHOW_LOAD:
		//PRINT("STATE_SHOW_LOAD : status=%d, running=%d\n", status, m_job->IsJobRunning());
		if(m_IOThread->isJobRunning() == false)
		{
			if(SCE_COMMON_DIALOG_STATUS_RUNNING == status && m_callClose == false)
			{
				SceSaveDataDialogCloseParam closeParam;
				memset(&closeParam, 0x00, sizeof(closeParam));
				closeParam.anim = (m_errorCode < SCE_OK) ? SCE_SAVE_DATA_DIALOG_ANIMATION_OFF : SCE_SAVE_DATA_DIALOG_ANIMATION_ON;
				ret = sceSaveDataDialogClose(&closeParam);
				if(ret == SCE_OK)
				{
					m_callClose = true;
				}
			}
			else if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
			{
				PRINT("load job result : 0x%x\n", ret);
				if(m_errorCode < SCE_OK)		// check job result
				{
					m_loadState = Load::STATE_SHOW_ERROR_START;
				}
				else
				{
					m_loadState = Load::STATE_FINISH;
				}
			}
		}
		break;

	case Load::STATE_SHOW_ERROR_START:
		PRINT("STATE_SHOW_ERROR_START\n");
		ret = openDialogError(SCE_SAVE_DATA_DIALOG_TYPE_LOAD,
							  m_userId, NULL, &m_selectedDirName, m_errorCode, m_ioThreadedSlotParams.newTitle);
		if(ret < SCE_OK)
		{
			EPRINT("openDialogError : 0x%x\n", ret);
			return ret;
		}
		m_loadState = Load::STATE_SHOW_ERROR;
		break;

	case Load::STATE_SHOW_ERROR:
		//PRINT("STATE_SHOW_ERROR\n");
		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			SceSaveDataDialogResult result;
			memset(&result, 0x00, sizeof(SceSaveDataDialogResult));
			ret = sceSaveDataDialogGetResult(&result);
			m_loadState = Load::STATE_FINISH;

			// display
			m_Result = result.result;
		}
		break;

	case Load::STATE_SHOW_NODATA_START:
		PRINT("STATE_SHOW_NODATA_START\n");
		ret = openDialogSystemMessage(SCE_SAVE_DATA_DIALOG_TYPE_LOAD,
									  m_userId, NULL, NULL,
									  SCE_SAVE_DATA_DIALOG_SYSMSG_TYPE_NODATA, m_ioThreadedSlotParams.newTitle);
		if(ret < SCE_OK)
		{
			EPRINT("openDialogConfirm : 0x%x\n", ret);
			return ret;
		}
		m_loadState = Load::STATE_SHOW_NODATA;
		break;

	case Load::STATE_SHOW_NODATA:
		//PRINT("STATE_SHOW_NODATA\n");
		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			SceSaveDataDialogResult result;
			memset(&result, 0x00, sizeof(SceSaveDataDialogResult));
			ret = sceSaveDataDialogGetResult(&result);
			m_loadState = Load::STATE_CANCELED;

			// display
			m_Result = result.result;
		}
		break;

	case Load::STATE_CANCELED:
	case Load::STATE_FINISH:
	default:
		PRINT("state : %d\n", m_loadState);
		m_isFinished = true;
		break;
	}

	return SCE_OK;
}


//-----------------------------------------------------------------------------
// JOB
//-----------------------------------------------------------------------------
int32_t SavedGame::jobLoad()
{
	int32_t ret = SCE_OK;
	bool dialogEnabled = true;

	// load

	SceSaveDataParam param;
	uint8_t *buffer = NULL;
	int64_t filesize = 0;
	ret = save_data::util::read(m_userId, NULL, &m_selectedDirName, m_ioThreadedSlotParams.fileName, &buffer, &filesize, &param, dialogEnabled);
	if(ret < SCE_OK)
	{
		EPRINT("0x%x\n", ret);
		return ret;
	}
	m_IOThread->SetBuffer(filesize,buffer);
	return SCE_OK;
}


void SavedGame::jobLoadEnd(const int32_t errorCode)
{
	m_errorCode = errorCode;
}


//-----------------------------------------------------------------------------
// JOB I/F
//-----------------------------------------------------------------------------
int32_t SavedGame::iStartLoad(void *userData)
{
	SavedGame *load = static_cast<SavedGame *>(userData);

	return load->jobLoad();
}

void SavedGame::iEndLoad(const int32_t errorCode, void *userData)
{
	SavedGame *load = static_cast<SavedGame *>(userData);

	load->jobLoadEnd(errorCode);
}
}	// namespace save_data {
