﻿/* SCE CONFIDENTIAL
 * PlayStation(R)4 Programmer Tool Runtime Library Release 01.600.051
 * Copyright (C) 2013 Sony Computer Entertainment Inc.
 * All Rights Reserved.
 */

#ifndef	_SCE_SAMPLE_COMMONDIALOG_SAVE_DATA_DIALOG_DIALOG_UTIL_H
#define	_SCE_SAMPLE_COMMONDIALOG_SAVE_DATA_DIALOG_DIALOG_UTIL_H

#include <user_service.h>
#include <save_data.h>
#include <save_data_dialog.h>


namespace save_data {
	namespace util_dialog {

		int32_t openDialogList(const SceSaveDataDialogType type,
							   const SceUserServiceUserId userId,
							   const SceSaveDataTitleId *titleId,
							   const SceSaveDataDirName *dirNames,
							   const uint32_t hitNum,
							   const char *newItemTitle,
								   void *newIconBuf=NULL, const size_t newIconSize=0);
		int32_t openDialogConfirm(const SceSaveDataDialogType type,
								  SceUserServiceUserId userId,
								  SceSaveDataTitleId *titleId,
								  SceSaveDataDirName *dirName,
								  const SceSaveDataDialogSystemMessageType systemMessageType,
								  const char *newItemTitle,
								  void *newIconBuf=NULL, const size_t newIconSize=0);
		int32_t openDialogOperating(const SceSaveDataDialogType type,
									SceUserServiceUserId userId,
									SceSaveDataTitleId *titleId,
									SceSaveDataDirName *dirName,
									const char *newItemTitle,
									void *newIconBuf=NULL, const size_t newIconSize=0);
		int32_t openDialogError(const SceSaveDataDialogType type,
								SceUserServiceUserId userId,
								SceSaveDataTitleId *titleId,
								SceSaveDataDirName *dirName,
								const int32_t errorCode,
								const char *newItemTitle,
								void *newIconBuf=NULL, const size_t newIconSize=0);
		int32_t openDialogSystemMessage(const SceSaveDataDialogType type,
										SceUserServiceUserId userId,
										SceSaveDataTitleId *titleId,
										SceSaveDataDirName *dirName,
										SceSaveDataDialogSystemMessageType msgType,
										const char *newItemTitle,
										uint64_t value=0,
										void *newIconBuf=NULL, const size_t newIconSize=0);

		
	}	// namespace util_dialog
}	// namespace save_data {
#endif	//_SCE_SAMPLE_COMMONDIALOG_SAVE_DATA_DIALOG_DIALOG_UTIL_H
