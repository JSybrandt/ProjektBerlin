﻿/* SCE CONFIDENTIAL
 * PlayStation(R)4 Programmer Tool Runtime Library Release 01.600.051
 * Copyright (C) 2013 Sony Computer Entertainment Inc.
 * All Rights Reserved.
 */

#include <kernel.h>
#include <sceerror.h>
#include <save_data.h>
#include <save_data_dialog.h>
#include "config.h"
#include "util.h"
#include "util_dialog.h"

#include "SavedGame.h"

using namespace save_data::util_dialog;


namespace UnitySavedGames {

//-----------------------------------------------------------------------------
// Update
//-----------------------------------------------------------------------------
int32_t SavedGame::updateSave(void)
{
	int32_t ret = SCE_OK;

	SceCommonDialogStatus status = sceSaveDataDialogUpdateStatus();

	// display


	// flow

	switch(m_saveState)
	{
	case Save::STATE_UNKNOWN:
		PRINT("STATE_UNKNOWN\n");
		if(m_IOThread->isReady())
		{
			m_saveState = Save::STATE_JOB_PREPARE_START;
		}
		break;

	case Save::STATE_JOB_PREPARE_START:
		PRINT("STATE_JOB_PREPARE_START\n");
		m_IOThread->startJob(iStartPrepare, iEndPrepare, this);
		m_saveState = Save::STATE_JOB_PREPARE;
		break;

	case Save::STATE_JOB_PREPARE:
		PRINT("STATE_JOB_PREPARE\n");
		if(m_IOThread->isJobRunning() == false)
		{
			if(m_errorCode < SCE_OK)
			{
				m_saveState = Save::STATE_SHOW_ERROR_START;
			}
			else
			{
				m_saveState = Save::STATE_SHOW_LIST_START;
			}
		}
		break;

	case Save::STATE_SHOW_LIST_START:
		PRINT("STATE_SHOW_LIST_START : dirNum=%u\n", m_searchedDirNum);
		{
			ret = openDialogList(SCE_SAVE_DATA_DIALOG_TYPE_SAVE,
								 m_userId, NULL, m_searchedDirNames, m_searchedDirNum
								 , m_ioThreadedSlotParams.newTitle
								 ,m_newIconBuf, m_newIconSize);
			if(ret < SCE_OK)
			{
				EPRINT("openDialogList : 0x%x\n", ret);
				return ret;
			}
			m_saveState = Save::STATE_SHOW_LIST;
		}
		break;

	case Save::STATE_SHOW_LIST:
		//PRINT("STATE_SHOW_LIST\n");
		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			memset(&m_selectedDirName, 0x00, sizeof(m_selectedDirName));
			SceSaveDataParam param;
			memset(&param, 0x00, sizeof(param));

			SceSaveDataDialogResult result;
			memset(&result, 0x00, sizeof(SceSaveDataDialogResult));
			result.dirName = &m_selectedDirName;
			result.param = &param;

			// Read Save dialog result and copy values into result.
			// This will wrtie the dirName into the address of m_selectedDirName
			// If a file that already exists is selected m_selectedDirName will contain the dirName.
			// If a new entry is selected m_selectedDirName will be empty.
			ret = sceSaveDataDialogGetResult(&result);
			if(ret < SCE_OK)
			{
				EPRINT("sceSaveDataDialogGetResult : 0x%x\n", ret);
				m_saveState = Save::STATE_FINISH;
			}
			else
			{
				m_Result = result.result;
				if(m_Result == SCE_OK)
				{
					m_saveState = Save::STATE_SHOW_SAVE_START;

					if(m_selectedDirName.data[0] == '\0')
					{
						strncpy(m_selectedDirName.data, m_ioThreadedSlotParams.dirName.data, SCE_SAVE_DATA_DIRNAME_DATA_MAXSIZE);
						if(m_selectedDirName.data[0] != '\0')
						{
							m_new = true;
							m_saveState = Save::STATE_SHOW_SAVE_START;
						}
						else
						{
							EPRINT("getDirName : 0x%x\n", ret);
							m_saveState = Save::STATE_FINISH;
						}
					}
					else
					{
						// over write confirm
						m_saveState = Save::STATE_SHOW_CONFIRM_OVERWRITE_START;
					}
				}
				else
				{
					// cancelled

					m_saveState = Save::STATE_FINISH;
				}

				// display

			}
		}
		break;

	case Save::STATE_SHOW_SAVE_START:
		PRINT("STATE_SHOW_SAVE_START : %d\n", status);
		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			m_callClose = false;
			ret = openDialogOperating(SCE_SAVE_DATA_DIALOG_TYPE_SAVE,
									  m_userId, NULL, m_new ? NULL : &m_selectedDirName,
									  m_ioThreadedSlotParams.title,
									  m_newIconBuf, m_newIconSize);
			if(ret < SCE_OK)
			{
				EPRINT("openDialogOperating : 0x%x\n", ret);
				return ret;
			}
		}
		else if(SCE_COMMON_DIALOG_STATUS_RUNNING == status)
		{
			ret = sceSaveDataDialogIsReadyToDisplay();
			if(ret <= 0)
			{
				// not ready
				PRINT("sceSaveDataDialogIsReadyToDisplay : 0x%x\n", ret);
				break;
			}

			m_IOThread->startJob(iStartSave, iEndSave, this);
			m_saveState = Save::STATE_SHOW_SAVE;
		}
		break;

	case Save::STATE_SHOW_SAVE:
		//PRINT("STATE_SHOW_SAVE\n");
		if(m_IOThread->isJobRunning() == false)
		{
			if(SCE_COMMON_DIALOG_STATUS_RUNNING == status && m_callClose == false)
			{
				SceSaveDataDialogCloseParam closeParam;
				memset(&closeParam, 0x00, sizeof(closeParam));
				closeParam.anim = (m_errorCode < SCE_OK) ? SCE_SAVE_DATA_DIALOG_ANIMATION_OFF : SCE_SAVE_DATA_DIALOG_ANIMATION_ON;
				ret = sceSaveDataDialogClose(&closeParam);
				if(ret == SCE_OK)
				{
					m_callClose = true;
				}
			}
			else if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
			{
				PRINT("save job result : 0x%x\n", ret);
				if(m_errorCode < SCE_OK)		// check job result
				{
					if(m_errorCode == SCE_SAVE_DATA_ERROR_NO_SPACE_FS)
					{
						m_saveState = Save::STATE_SHOW_ERROR_NOSPACE_START;
					}
					else
					{
						m_saveState = Save::STATE_SHOW_ERROR_START;
					}
				}
				else
				{
					m_saveState = Save::STATE_FINISH;
				}
			}
		}
		break;

	case Save::STATE_SHOW_CONFIRM_OVERWRITE_START:
		PRINT("STATE_SHOW_CONFIRM_OVERWRITE_START\n");

		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			ret = openDialogConfirm(SCE_SAVE_DATA_DIALOG_TYPE_SAVE,
									m_userId, NULL, &m_selectedDirName,
									SCE_SAVE_DATA_DIALOG_SYSMSG_TYPE_OVERWRITE,
									m_ioThreadedSlotParams.title,
									m_newIconBuf, m_newIconSize);
			if(ret < SCE_OK)
			{
				EPRINT("openDialogConfirm : 0x%x\n", ret);
				return ret;
			}
			m_saveState = Save::STATE_SHOW_CONFIRM_OVERWRITE;
		}
		break;

	case Save::STATE_SHOW_CONFIRM_OVERWRITE:
		//PRINT("STATE_SHOW_CONFIRM_OVERWRITE\n");
		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			SceSaveDataParam param;
			memset(&param, 0x00, sizeof(param));

			SceSaveDataDialogResult result;
			memset(&result, 0x00, sizeof(SceSaveDataDialogResult));
			result.param = &param;

			ret = sceSaveDataDialogGetResult(&result);
			if(ret < SCE_OK)
			{
				EPRINT("sceSaveDataDialogGetResult : 0x%x\n", ret);
				m_saveState = Save::STATE_FINISH;
			}
			else
			{
				if(result.result == SCE_OK)
				{
					if(result.buttonId == SCE_SAVE_DATA_DIALOG_BUTTON_ID_YES)
					{
						m_new = false;
						m_saveState = Save::STATE_SHOW_SAVE_START;
					}
					else
					{
						m_saveState = Save::STATE_CANCELED;
					}
				}
				else if(result.result == SCE_COMMON_DIALOG_RESULT_USER_CANCELED)
				{
					m_saveState = Save::STATE_CANCELED;
				}
				else
				{
					m_saveState = Save::STATE_SHOW_ERROR_START;
					m_errorCode = result.result;
				}
			}
		}
		break;

	case Save::STATE_SHOW_ERROR_START:
		PRINT("STATE_SHOW_ERROR_START\n");

		ret = openDialogError(SCE_SAVE_DATA_DIALOG_TYPE_SAVE,
							  m_userId, NULL, &m_selectedDirName, m_errorCode,
							  m_ioThreadedSlotParams.newTitle,
							  m_newIconBuf, m_newIconSize);
		if(ret < SCE_OK)
		{
			EPRINT("openDialogError : 0x%x\n", ret);
			return ret;
		}
		m_saveState = Save::STATE_SHOW_ERROR;
		break;

	case Save::STATE_SHOW_ERROR:
		//PRINT("STATE_SHOW_ERROR\n");
		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			SceSaveDataDialogResult result;
			memset(&result, 0x00, sizeof(SceSaveDataDialogResult));
			ret = sceSaveDataDialogGetResult(&result);
			m_saveState = Save::STATE_FINISH;

			// display

//			setDispValue(menu, "Result", result.result);
//			setDispEnum(menu, "ButtonId", static_cast<int32_t>(result.buttonId));
		}
		break;

	case Save::STATE_SHOW_ERROR_NOSPACE_START:
		PRINT("STATE_SHOW_ERROR_SYSTEM_MSG_START\n");

		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			ret = openDialogSystemMessage(SCE_SAVE_DATA_DIALOG_TYPE_SAVE,
										  m_userId, NULL, &m_selectedDirName,
										  SCE_SAVE_DATA_DIALOG_SYSMSG_TYPE_NOSPACE,
										  m_ioThreadedSlotParams.newTitle,
										  m_requiredBlocks,
										  m_newIconBuf, m_newIconSize);
			if(ret < SCE_OK)
			{
				EPRINT("openDialogError : 0x%x\n", ret);
				return ret;
			}
			m_saveState = Save::STATE_SHOW_ERROR;
			m_FailureCode = FAIL_NOSPACE;
		}
		break;

	case Save::STATE_SHOW_ERROR_NOSPACE:
		//PRINT("STATE_SHOW_ERROR_NOSPACE\n");
		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			SceSaveDataDialogResult result;
			memset(&result, 0x00, sizeof(SceSaveDataDialogResult));
			ret = sceSaveDataDialogGetResult(&result);
			m_saveState = Save::STATE_FINISH;

			// display

//			setDispValue(menu, "Result", result.result);
//			setDispEnum(menu, "ButtonId", static_cast<int32_t>(result.buttonId));
		}
		break;

    case Save::STATE_CANCELED:
	case Save::STATE_FINISH:
	default:
		PRINT("state : %d\n", m_saveState);
		m_isFinished = true;
		break;
	}

	return SCE_OK;
}

//-----------------------------------------------------------------------------
// JOB : prepare
//-----------------------------------------------------------------------------
int32_t SavedGame::jobPrepare()
{
	int32_t ret = SCE_OK;

	ret = jobSearch();
	if(ret < SCE_OK)
	{
		EPRINT("jobSearch : 0x%x\n", ret);
		return ret;
	}

	delete [] m_newIconBuf;
	m_newIconBuf = NULL;
	m_newIconSize = 0;

	ret = save_data::util::loadFile(m_ioThreadedSlotParams.iconPath, &m_newIconBuf, &m_newIconSize);
	if(ret < SCE_OK)
	{
		EPRINT("util::loadFile : 0x%x\n", ret);
		return ret;
	}

	return SCE_OK;
}


void SavedGame::jobPrepareEnd(const int32_t errorCode)
{
	m_errorCode = errorCode;
}


//-----------------------------------------------------------------------------
// JOB : save
//-----------------------------------------------------------------------------
int32_t SavedGame::jobSave()
{
	int32_t ret = SCE_OK;
	bool dialogEnabled = true;
	// save

	if(m_new == true)
	{
		ret = save_data::util::create(m_userId, &m_ioThreadedSlotParams.titleId, &m_selectedDirName, 
			m_ioThreadedSlotParams.fileName, m_IOThread->GetBufferSize(), m_IOThread->GetBuffer(),
			&m_requiredBlocks,
				m_ioThreadedSlotParams.title,
				m_ioThreadedSlotParams.subTitle,
				m_ioThreadedSlotParams.detail,
				m_ioThreadedSlotParams.iconPath,
				dialogEnabled
			);
	}
	else
	{
		ret = save_data::util::writeWithParams(m_userId, &m_ioThreadedSlotParams.titleId, &m_selectedDirName, 
			m_ioThreadedSlotParams.fileName, m_IOThread->GetBufferSize(), m_IOThread->GetBuffer(), 
			&m_requiredBlocks,
			m_ioThreadedSlotParams.title,
			m_ioThreadedSlotParams.subTitle,
			m_ioThreadedSlotParams.detail,
			m_ioThreadedSlotParams.iconPath,
			dialogEnabled
			);
	}

	if(ret < SCE_OK)
	{
		EPRINT("0x%x\n", ret);
		return ret;
	}

	return SCE_OK;
}


void SavedGame::jobSaveEnd(const int32_t errorCode)
{
	m_errorCode = errorCode;
}


//-----------------------------------------------------------------------------
// JOB I/F : prepare
//-----------------------------------------------------------------------------
int32_t SavedGame::iStartPrepare(void *userData)
{
	SavedGame *save = static_cast<SavedGame *>(userData);

	return save->jobPrepare();
}

void SavedGame::iEndPrepare(const int32_t errorCode, void *userData)
{
	SavedGame *save = static_cast<SavedGame *>(userData);

	save->jobPrepareEnd(errorCode);
}


//-----------------------------------------------------------------------------
// JOB I/F : save
//-----------------------------------------------------------------------------
int32_t SavedGame::iStartSave(void *userData)
{
	SavedGame *save = static_cast<SavedGame *>(userData);

	return save->jobSave();
}

void SavedGame::iEndSave(const int32_t errorCode, void *userData)
{
	SavedGame *save = static_cast<SavedGame *>(userData);

	save->jobSaveEnd(errorCode);
}
}	// namespace save_data {
