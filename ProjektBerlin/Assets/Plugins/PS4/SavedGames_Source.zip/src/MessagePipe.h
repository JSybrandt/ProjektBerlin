#ifndef _MESSAGEPIPE_H
#define _MESSAGEPIPE_H

namespace UnitySavedGames
{
	namespace Messages
	{
		enum MessageType
		{
			kSavedGame_NotSet,
			kSavedGame_Log,
			kSavedGame_LogWarning,
			kSavedGame_LogError,				

			kSavedGame_GameSaved,			// Game saving has completed.
			kSavedGame_GameLoaded,			// Game loading has completed.
			kSavedGame_GameDeleted,			// A saved game has been deleted.
			kSavedGame_Canceled,			// Saving/loading was canceled.

			kSavedGame_SaveNoSpace,			// Saving failed because there was not enough space.
			kSavedGame_SaveNotMounted,		// Saving failed because there was save device mounted (missing memory card).
			kSavedGame_SaveGenericError,	// Saving failed due to some error.
			kSavedGame_LoadCorrupted,		// Load failed because the slot was corrupted.
			kSavedGame_LoadNoData,			// Load failed because there was nothing to load.
		};

		struct PluginMessage
		{
			PluginMessage()
			{
				type = kSavedGame_NotSet;
				dataSize = 0;
				data = NULL;
			}
			~PluginMessage()
			{
				if(dataSize > 0)
				{
					free(data);
				}
			}

			void SetData(void* src, int size)
			{
				dataSize = size;
				data = (char*)malloc(dataSize);
				memcpy(data, src, dataSize);
			}

			template<typename T> void SetData(const T& val)
			{
				Assert(sizeof(val) == sizeof(void*));
				dataSize = 0;
				memcpy(&data, &val, sizeof(void*));
			}

			void SetDataFromString(char* src)
			{
				int len = strlen(src);
				dataSize = len + 1;
				data = malloc(dataSize);
				memcpy(data, src, dataSize);
			}

			// Message type.
			int type;

			// Message data.
			// NOTE, if dataSize != 0 then the data was allocated, if dataSize == 0 then the data void* is actually some 4byte blittable value, i.e, an int.
			int dataSize;
			void* data;
		};

		void Log(const char* format, ...);
		void LogWarning(const char* format, ...);
		void LogError(const char* format, ...);
		void AddMessage(MessageType msgType);
		void AddMessage(PluginMessage* msg);
		bool HasMessage();
		bool GetFirstMessage(PluginMessage* msg);
		bool RemoveFirstMessage();
	}
}

PRX_EXPORT bool PrxSavedGamesHasMessage();
PRX_EXPORT bool PrxSavedGamesGetFirstMessage(UnitySavedGames::Messages::PluginMessage* result);
PRX_EXPORT bool PrxSavedGamesRemoveFirstMessage();

#endif // _MESSAGEPIPE_H
