﻿/* SCE CONFIDENTIAL
 * PlayStation(R)4 Programmer Tool Runtime Library Release 01.600.051
 * Copyright (C) 2013 Sony Computer Entertainment Inc.
 * All Rights Reserved.
 */
#include <stdio.h>
#include <string.h>
#include <_fs.h>
#include <sceerror.h>
#include <save_data.h>
#include "config.h"
#include "util_dialog.h"


namespace save_data {
namespace util_dialog {

int32_t openDialogList(const SceSaveDataDialogType type,
					   const SceUserServiceUserId userId,
					   const SceSaveDataTitleId *titleId,
					   const SceSaveDataDirName *dirNames,
					   const uint32_t hitNum,
					   const char *newItemTitle,
					   void *newIconBuf/*=NULL*/, const size_t newIconSize/*=NULL*/)
{
	int32_t ret = SCE_OK;

	SceSaveDataDialogParam param;
	sceSaveDataDialogParamInitialize(&param);
	param.mode = SCE_SAVE_DATA_DIALOG_MODE_LIST;
	param.dispType = type;

	SceSaveDataDialogAnimationParam animParam;
	memset(&animParam, 0x00, sizeof(animParam));
	animParam.userOK = SCE_SAVE_DATA_DIALOG_ANIMATION_OFF;
	animParam.userCancel = SCE_SAVE_DATA_DIALOG_ANIMATION_ON;
	param.animParam = &animParam;

	bool showNewItem = false;
	SceSaveDataDialogNewItem newItem;
	memset(&newItem, 0x00, sizeof(newItem));

	// Don't allow more than the maximum save count
	// Why one less - well leave space for the autosave.
	// The Autosave doesn't do a jobsearch so it doesn't know how many saves are available. Therefore
	// it is easier to just leave an extra space for the autosave. 
	if(newIconBuf && hitNum <= SAVE_DATA_COUNT-1)
	{
		newItem.title = newItemTitle;
		newItem.iconBuf = static_cast<void *>(newIconBuf);
		newItem.iconSize = newIconSize;
		showNewItem = true;
	}

	SceSaveDataDialogItems items;
	memset(&items, 0x00, sizeof(items));
	items.userId = userId;
	items.titleId = titleId;
	items.dirName = dirNames;
	items.dirNameNum = hitNum;
	items.newItem = showNewItem ? &newItem : NULL;
	items.focusPos = SCE_SAVE_DATA_DIALOG_FOCUS_POS_DATAOLDEST;
	items.itemStyle = SCE_SAVE_DATA_DIALOG_ITEM_STYLE_TITLE_DATESIZE_SUBTITLE;

	param.items = &items;

	ret = sceSaveDataDialogOpen(&param);
	if(ret < SCE_OK)
	{
		EPRINT("sceSaveDataDialogOpen : 0x%x\n", ret);
		return ret;
	}

	return SCE_OK;
}


int32_t openDialogConfirm(const SceSaveDataDialogType type,
						  SceUserServiceUserId userId,
						  SceSaveDataTitleId *titleId,
						  SceSaveDataDirName *dirName,
						  const SceSaveDataDialogSystemMessageType systemMessageType,
						  const char *newItemTitle,
						  void *newIconBuf/*=NULL*/, const size_t newIconSize/*=NULL*/)
{
	int32_t ret = SCE_OK;

	SceSaveDataDialogParam param;
	sceSaveDataDialogParamInitialize(&param);
	param.mode = SCE_SAVE_DATA_DIALOG_MODE_SYSTEM_MSG;
	param.dispType = type;

	SceSaveDataDialogAnimationParam animParam;
	memset(&animParam, 0x00, sizeof(animParam));
	animParam.userOK = SCE_SAVE_DATA_DIALOG_ANIMATION_OFF;
	animParam.userCancel = SCE_SAVE_DATA_DIALOG_ANIMATION_ON;
	param.animParam = &animParam;

	bool showNewItem = false;
	SceSaveDataDialogNewItem newItem;
	memset(&newItem, 0x00, sizeof(newItem));
	if(newIconBuf)
	{
		newItem.title = newItemTitle;
		newItem.iconBuf = static_cast<void *>(newIconBuf);
		newItem.iconSize = newIconSize;
		showNewItem = true;
	}

	SceSaveDataDialogItems items;
	memset(&items, 0x00, sizeof(items));
	items.userId = userId;
	items.titleId = titleId;
	items.dirName = dirName;
	items.dirNameNum = (dirName == NULL) ? 0 : 1;
	items.newItem = showNewItem ? &newItem : NULL;

	SceSaveDataDialogSystemMessageParam sysm;
	memset(&sysm, 0x00, sizeof(sysm));
	sysm.sysMsgType = systemMessageType;

	param.items = &items;
	param.sysMsgParam = &sysm;

	ret = sceSaveDataDialogOpen(&param);
	if(ret < SCE_OK)
	{
		EPRINT("sceSaveDataDialogOpen : 0x%x\n", ret);
		return ret;
	}

	return SCE_OK;
}


int32_t openDialogOperating(const SceSaveDataDialogType type,
							SceUserServiceUserId userId,
							SceSaveDataTitleId *titleId,
							SceSaveDataDirName *dirName,
							const char *newItemTitle,
							void *newIconBuf/*=NULL*/, const size_t newIconSize/*=NULL*/)
{
	int32_t ret = SCE_OK;

	SceSaveDataDialogParam param;
	sceSaveDataDialogParamInitialize(&param);
	param.mode = SCE_SAVE_DATA_DIALOG_MODE_PROGRESS_BAR;
	param.dispType = type;

	bool showNewItem = false;
	SceSaveDataDialogNewItem newItem;
	memset(&newItem, 0x00, sizeof(newItem));
	if(newIconBuf)
	{
		newItem.title = newItemTitle;
		newItem.iconBuf = static_cast<void *>(newIconBuf);
		newItem.iconSize = newIconSize;
		showNewItem = true;
	}

	SceSaveDataDialogItems items;
	memset(&items, 0x00, sizeof(items));
	items.userId = userId;
	items.titleId = titleId;
	items.dirName = dirName;
	items.dirNameNum = (dirName == NULL) ? 0 : 1;
	items.newItem = showNewItem ? &newItem : NULL;

	SceSaveDataDialogProgressBarParam bparam;
	memset(&bparam, 0x00, sizeof(bparam));
	bparam.barType = SCE_SAVE_DATA_DIALOG_PROGRESSBAR_TYPE_PERCENTAGE;
	bparam.sysMsgType = SCE_SAVE_DATA_DIALOG_PRGRESS_SYSMSG_TYPE_PROGRESS;
	bparam.msg = NULL;			// NULL == system message

	param.items = &items;
	param.progBarParam = &bparam;

	ret = sceSaveDataDialogOpen(&param);
	if(ret < SCE_OK)
	{
		EPRINT("sceSaveDataDialogOpen : 0x%x\n", ret);
		return ret;
	}

	return SCE_OK;
}


int32_t openDialogError(const SceSaveDataDialogType type,
						SceUserServiceUserId userId,
						SceSaveDataTitleId *titleId,
						SceSaveDataDirName *dirName,
						int32_t errorCode,
						const char *newItemTitle,
						void *newIconBuf/*=NULL*/, const size_t newIconSize/*=0*/)
{
	int32_t ret = SCE_OK;

	SceSaveDataDialogParam param;
	sceSaveDataDialogParamInitialize(&param);
	param.mode = SCE_SAVE_DATA_DIALOG_MODE_ERROR_CODE;
	param.dispType = type;

	SceSaveDataDialogAnimationParam animParam;
	memset(&animParam, 0x00, sizeof(animParam));
	animParam.userOK = SCE_SAVE_DATA_DIALOG_ANIMATION_ON;
	animParam.userCancel = SCE_SAVE_DATA_DIALOG_ANIMATION_ON;
	param.animParam = &animParam;

	bool showNewItem = false;
	SceSaveDataDialogNewItem newItem;
	memset(&newItem, 0x00, sizeof(newItem));
	if(newIconBuf)
	{
		newItem.title = newItemTitle;
		newItem.iconBuf = static_cast<void *>(newIconBuf);
		newItem.iconSize = newIconSize;
		showNewItem = true;
	}

	SceSaveDataDialogItems items;
	memset(&items, 0x00, sizeof(items));
	items.userId = userId;
	items.titleId = titleId;
	items.dirName = dirName;
	items.dirNameNum = 1;
	items.newItem = showNewItem ? &newItem : NULL;

	SceSaveDataDialogErrorCodeParam eparam;
	memset(&eparam, 0x00, sizeof(eparam));
	eparam.errorCode = errorCode;

	param.items = &items;
	param.errorCodeParam = &eparam;
	ret = sceSaveDataDialogOpen(&param);
	if(ret < SCE_OK)
	{
		EPRINT("sceSaveDataDialogOpen : 0x%x\n", ret);
		return ret;
	}

	return SCE_OK;
}


int32_t openDialogSystemMessage(const SceSaveDataDialogType type,
								SceUserServiceUserId userId,
								SceSaveDataTitleId *titleId,
								SceSaveDataDirName *dirName,
								SceSaveDataDialogSystemMessageType msgType,
								const char *newItemTitle,
								uint64_t value/*=0*/,
								void *newIconBuf/*=NULL*/, const size_t newIconSize/*=0*/)
{
	int32_t ret = SCE_OK;

	SceSaveDataDialogParam param;
	sceSaveDataDialogParamInitialize(&param);
	param.mode = SCE_SAVE_DATA_DIALOG_MODE_SYSTEM_MSG;
	param.dispType = type;

	SceSaveDataDialogAnimationParam animParam;
	memset(&animParam, 0x00, sizeof(animParam));
	animParam.userOK = SCE_SAVE_DATA_DIALOG_ANIMATION_ON;
	animParam.userCancel = SCE_SAVE_DATA_DIALOG_ANIMATION_ON;
	param.animParam = &animParam;

	bool showNewItem = false;
	SceSaveDataDialogNewItem newItem;
	memset(&newItem, 0x00, sizeof(newItem));
	if(newIconBuf)
	{
		newItem.title = newItemTitle;
		newItem.iconBuf = static_cast<void *>(newIconBuf);
		newItem.iconSize = newIconSize;
		showNewItem = true;
	}

	SceSaveDataDialogItems items;
	memset(&items, 0x00, sizeof(items));
	items.userId = userId;
	items.titleId = titleId;
	items.dirName = dirName;
	if(dirName)
	{
		items.dirNameNum = dirName->data[0] == '\0' ? 0 : 1;
	}
	items.newItem = showNewItem ? &newItem : NULL;

	SceSaveDataDialogSystemMessageParam sysMessageParam;
	memset(&sysMessageParam, 0x00, sizeof(sysMessageParam));
	sysMessageParam.sysMsgType = msgType;
	sysMessageParam.value = value;

	param.items = &items;
	param.sysMsgParam = &sysMessageParam;
	ret = sceSaveDataDialogOpen(&param);
	if(ret < SCE_OK)
	{
		EPRINT("sceSaveDataDialogOpen : 0x%x\n", ret);
		return ret;
	}

	return SCE_OK;
}
}	// namespace util_dialog {
}	// namespace save_data {
