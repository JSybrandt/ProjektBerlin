#ifndef _SAVEDGAME_H
#define _SAVEDGAME_H

#include "prx.h"
#include "SimpleLock.h"
#include "IOThread.h"
#include "MessagePipe.h"

#define	SAVEDATA_FIXED_TARGET_SLOT	0		// Always use slot 0 for single fixed slot saving/loading.

namespace UnitySavedGames
{
	struct SavedGameSlotParams
	{
		SceUserServiceUserId  userId;
		uint32_t reserved;		// padding
		const char * titleId;		// SceSaveDataTitleId
		const char * dirName;	// directory name
		const char * fileName;		// file name

		// used when creating the save game
		const char * newTitle;
		const char * title;
		const char * subTitle;
		const char * detail;
		const char * iconPath;
		size_t sizeKiB;
	};

	struct SaveGameSlotDetails
	{
		size_t m_size;

		const char *title;
		const char * subTitle;
		const char * detail;
		uint32_t userParam;
		time_t mtime;
		uint64_t rtcTicktime;	// value stored as SceRtcTick

		void *m_DataIconData;
		size_t m_DataIconDataSize;
	};

	// save data dialog mode
	enum DialogMode
	{
		SAVEDATA_DIALOG_MODE_NONE,
		SAVEDATA_DIALOG_MODE_SAVE,
		SAVEDATA_DIALOG_MODE_LOAD,
		SAVEDATA_DIALOG_MODE_AUTOSAVE,
		SAVEDATA_DIALOG_MODE_AUTOLOAD
	};

	// save data dialog state
	enum DialogState
	{
		SAVEDATA_DIALOG_STEP_NONE,
		SAVEDATA_DIALOG_STEP_FIXED,
		SAVEDATA_DIALOG_STEP_CONFIRM,
		SAVEDATA_DIALOG_STEP_CONFIRM_CANCEL,
		SAVEDATA_DIALOG_STEP_AUTO,
		SAVEDATA_DIALOG_STEP_AUTOSAVING,
		SAVEDATA_DIALOG_STEP_AUTOLOAD_FAILED,
		SAVEDATA_DIALOG_STEP_SAVING,
		SAVEDATA_DIALOG_STEP_ALERT,
		SAVEDATA_DIALOG_STEP_FINISH,
		SAVEDATA_DIALOG_STEP_END,
		SAVEDATA_DIALOG_STEP_END_CANCELED
	};

	namespace Delete
	{
		typedef enum
		{
			STATE_UNKNOWN = 0,
			STATE_JOB_SEARCH_START,
			STATE_JOB_SEARCH,
			STATE_SHOW_LIST_START,
			STATE_SHOW_LIST,
			STATE_SHOW_CONFIRM_DELETE_START,
			STATE_SHOW_CONFIRM_DELETE,
			STATE_SHOW_DELETE_START,
			STATE_SHOW_DELETE,
			STATE_SHOW_ERROR_START,
			STATE_SHOW_ERROR,
			STATE_SHOW_NODATA_START,
			STATE_SHOW_NODATA,
			STATE_FINISH,
			STATE_CANCELED,
			STATE_MAX
		} State;
	}

	namespace Save
	{
		typedef enum
		{
			STATE_UNKNOWN = 0,
			STATE_JOB_PREPARE_START,
			STATE_JOB_PREPARE,
			STATE_SHOW_LIST_START,
			STATE_SHOW_LIST,
			STATE_SHOW_SAVE_START,
			STATE_SHOW_SAVE,
			STATE_SHOW_CONFIRM_OVERWRITE_START,
			STATE_SHOW_CONFIRM_OVERWRITE,
			STATE_SHOW_ERROR_START,
			STATE_SHOW_ERROR,
			STATE_SHOW_ERROR_NOSPACE_START,
			STATE_SHOW_ERROR_NOSPACE,
			STATE_FINISH,
			STATE_CANCELED,
			STATE_MAX
		} State;
	}

	namespace Load
	{
		typedef enum
		{
			STATE_UNKNOWN = 0,
			STATE_JOB_SEARCH_START,
			STATE_JOB_SEARCH,
			STATE_SHOW_LIST_START,
			STATE_SHOW_LIST,
			STATE_SHOW_LOAD_START,
			STATE_SHOW_LOAD,
			STATE_SHOW_ERROR_START,
			STATE_SHOW_ERROR,
			STATE_SHOW_NODATA_START,
			STATE_SHOW_NODATA,
			STATE_FINISH,
			STATE_CANCELED,
			STATE_MAX
		} State;
	}

	typedef enum
	{
		FAIL_NONE,
		FAIL_NOSPACE,
		FAIL_NOTMOUNTED,
		FAIL_GENERIC,
		FAIL_CORRUPTED,
		FAIL_NODATA
	} FAILCODE;

	class SavedGame
	{
		SimpleLock m_Lock;
		bool m_DialogOpen;
		bool m_Busy;
		bool m_Initialised;		// when false we are in the non-initialised state, no work can be performed
		DialogState m_SavedDataDialogState;
		FAILCODE m_FailureCode;		// when >0 it indicates failure code
		IOThreadMode m_IOThreadMode;
		IOThread* m_IOThread;
		bool m_useDialogs;
		static void *SaveDataDetailsIconBuf;

		bool m_DialogModuleLoaded;		// when true this plugin has loaded the dialog module
		bool m_DialogModuleInitialised; // when true we have initialized the dialog module
	public:
		SavedGame();
		~SavedGame();


		bool IsBusy() { return m_Busy; }
		bool IsDialogOpen();
		bool Save(void* data, int dataSize, SavedGameSlotParams* slotParams, bool useDialogs);
		bool Load(SavedGameSlotParams* slotParams, bool useDialogs);
		int32_t Exists(SavedGameSlotParams* slotParams);
		int32_t GetDetails(SavedGameSlotParams* slotParams, SaveGameSlotDetails *slotDetails);
		bool Delete(SavedGameSlotParams* slotParams, bool useDialogs);


		void SetIOThread(IOThread* thread) { m_IOThread = thread; }
		int Update(void);
		void InitSlotParams( const SavedGameSlotParams*src);

		// new variables for ps4 dialog state system
		int updateDelete(void);
		int32_t jobDelete();
		void jobDeleteEnd(const int32_t errorCode);
		static int32_t iStartDelete(void *userData);
		static void iEndDelete(const int32_t errorCode, void *userData);
		Delete::State m_deleteState;

		int updateLoad(void);
		int updateSave(void);
		Load::State m_loadState;
		Save::State m_saveState;
		SceUserServiceUserId	m_userId;
		SceSaveDataDirName		*m_searchedDirNames;
		uint32_t				m_searchedDirNum;
		SceSaveDataDirName		m_selectedDirName;
		int32_t					m_errorCode;
		bool					m_isFinished;	// set to true when the process has completed
		bool					m_callClose;	// set to true when the close dialog has been called
		bool					m_new;			// set to true when we are creating a new save game
		SceSaveDataBlocks		m_requiredBlocks; // number of block required by save game (to be clarified)
		uint8_t *				m_newIconBuf;	// icon used for created save game
		size_t					m_newIconSize;	// size of newIconBuf
		int32_t					m_Result;		// the result from the dialog
		int32_t					m_DialogResult;	// the result of
		Messages::MessageType	m_PendingError;	// error from autosave/load ... stored till after we've displayed the dialog

		int32_t jobSearch();
		void jobSearchEnd(const int32_t errorCode);
		static int32_t iStartSearch(void *userData);
		static void iEndSearch(const int32_t errorCode, void *userData);

		int32_t jobLoad();
		void jobLoadEnd(const int32_t errorCode);
		static int32_t iStartLoad(void *userData);
		static void iEndLoad(const int32_t errorCode, void *userData);

		int32_t jobPrepare();
		void jobPrepareEnd(const int32_t errorCode);
		static int32_t iStartPrepare(void *userData);
		static void iEndPrepare(const int32_t errorCode, void *userData);

		int32_t jobSave();
		void jobSaveEnd(const int32_t errorCode);
		static int32_t iStartSave(void *userData);
		static void iEndSave(const int32_t errorCode, void *userData);

		IOThreadSlotParams m_ioThreadedSlotParams;

		void updateErrorDialog();
		// end of new system




		int32_t Initialise(void);
		int32_t Terminate(void);

	private:
		int32_t StartSaveLoad(IOThreadMode mode, SavedGameSlotParams* slotParams, int size, void *buffer);
		int32_t InitDialog();

		int32_t ShutdownIOThread(void);
		int32_t ShutdownDialog(void);
	};

	extern SavedGame gSavedGame;
}

#endif // _SAVEDGAME_H
