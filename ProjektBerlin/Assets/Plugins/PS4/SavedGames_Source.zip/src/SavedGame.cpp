#include "SavedGame.h"
#include "ErrorCodes.h"
#include "util_dialog.h"
#include "MessagePipe.h"

#include <save_data_dialog.h>
#include <libsysmodule.h>

extern int pluginstate;		// pluginstate >=0 is good

using namespace UnitySavedGames::Messages;

namespace UnitySavedGames
{
	#pragma region External Methods

	PRX_EXPORT bool PrxSavedGameSave(void* data, int dataSize, SavedGameSlotParams* slotParams, bool useDialogs)
	{
		if (pluginstate<0) return false;
		return gSavedGame.Save(data, dataSize, slotParams, useDialogs);
	}

	PRX_EXPORT bool PrxSavedGameLoad(SavedGameSlotParams* slotParams, bool useDialogs)
	{
		if (pluginstate<0) return false;
		return gSavedGame.Load(slotParams, useDialogs);
	}

	PRX_EXPORT uint32_t PrxSavedGameExists(SavedGameSlotParams* slotParams)
	{
		if (pluginstate<0) return -1;
		return gSavedGame.Exists(slotParams);
	}

	PRX_EXPORT uint32_t PrxSavedGameGetDetails(SavedGameSlotParams* slotParams, SaveGameSlotDetails *slotDetailsResults)
	{
		if (pluginstate<0) return -1;
		return gSavedGame.GetDetails(slotParams,slotDetailsResults);
	}

	PRX_EXPORT bool PrxSavedGameDelete(SavedGameSlotParams* slotParams, bool useDialogs)
	{
		if (pluginstate<0) return false;
		return gSavedGame.Delete(slotParams, useDialogs);
	}

	#pragma endregion

	SavedGame gSavedGame;

	void *SavedGame::SaveDataDetailsIconBuf = NULL;

	SavedGame::SavedGame()
		: m_DialogOpen(false)
		, m_Busy(false)
		, m_IOThread(NULL)
		, m_useDialogs(false)
	{
		m_DialogModuleLoaded = false;
		m_DialogModuleInitialised = false;
		m_Initialised = false;
		m_FailureCode = FAIL_NONE;
	}

	void SavedGame::InitSlotParams(const SavedGameSlotParams*src)
	{
		IOThreadSlotParams *dest = &m_ioThreadedSlotParams;
		memset(dest,0,sizeof(IOThreadSlotParams));
		dest->userId = src->userId;

		if (dest->userId == 0)
		{
			sceUserServiceGetInitialUser(&dest->userId);
		}

		if (src->titleId!=NULL)		// if we don't supply a titleid then use the supplied one
		{
			strncpy(dest->titleId.data, src->titleId,SCE_SAVE_DATA_TITLE_ID_DATA_SIZE);
		}
		strncpy(dest->dirName.data, src->dirName,SCE_SAVE_DATA_DIRNAME_DATA_MAXSIZE);
		strncpy(dest->fileName, src->fileName,MAX_FILENAMESIZE);
		if (src->title)    strncpy(dest->title, src->title,SCE_SAVE_DATA_TITLE_MAXSIZE);
		if (src->newTitle) strncpy(dest->newTitle, src->newTitle,SCE_SAVE_DATA_TITLE_MAXSIZE);
		if (src->subTitle) strncpy(dest->subTitle, src->subTitle,SCE_SAVE_DATA_SUBTITLE_MAXSIZE);
		if (src->detail)   strncpy(dest->detail, src->detail,SCE_SAVE_DATA_DETAIL_MAXSIZE);
		if (src->iconPath) strncpy(dest->iconPath, src->iconPath,MAX_ICONPATHSIZE);

		dest->sizeKiB = src->sizeKiB;
	}

	SavedGame::~SavedGame()
	{
	}
	
	// this have to be isolated from the constructors so we can call it at different times (constructors are called at prx load time)
	int32_t SavedGame::Initialise()
	{
		int32_t result = sceSaveDataInitialize(NULL);
		if (result != SCE_OK)
		{
			Messages::LogError("SavedGame::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(result));
		}
		else
		{
			m_Initialised = true;
			m_FailureCode = FAIL_NONE;
		}
		return result;
	}

	int32_t SavedGame::Terminate()
	{
		if (m_IOThread) m_IOThread->SetBuffer(0,NULL);		// important to free up the save game buffer

		int32_t result = sceSaveDataTerminate();
		if (result != SCE_OK)
		{
			Messages::LogError("SavedGame::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(result));
		}

		if (m_DialogModuleInitialised == true)
		{
			result = sceSaveDataDialogTerminate();
			if (result != SCE_OK)
			{
				Messages::LogError("SavedGame::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(result));
			}
			m_DialogModuleInitialised = false;
			if (m_DialogModuleLoaded == true)
			{
				result = sceSysmoduleUnloadModule(SCE_SYSMODULE_SAVE_DATA_DIALOG);
				m_DialogModuleLoaded = false;
			}
		}


		if (SaveDataDetailsIconBuf)
		{
			free(SaveDataDetailsIconBuf);
			SaveDataDetailsIconBuf = NULL;
		}

		m_Initialised = false;

		return result;
	}

	bool SavedGame::Save(void* data, int dataSize, SavedGameSlotParams* slotParams, bool useDialogs)
	{
		if (!m_Initialised) { return false; }
		InitSlotParams(slotParams);
		m_IOThread->SetSlotParams(m_ioThreadedSlotParams);
		m_useDialogs = useDialogs;
		m_saveState = Save::STATE_UNKNOWN;
		m_FailureCode = FAIL_NONE;
		m_PendingError = kSavedGame_NotSet;
		StartSaveLoad(IOMODE_SAVE, slotParams, dataSize, data);
		return true;
	}

	bool SavedGame::Load(SavedGameSlotParams* slotParams, bool useDialogs)
	{
		if (!m_Initialised) { return false; }
		InitSlotParams(slotParams);
		m_IOThread->SetSlotParams(m_ioThreadedSlotParams);
		m_useDialogs = useDialogs;
		m_loadState = Load::STATE_UNKNOWN;
		m_FailureCode = FAIL_NONE;
		m_PendingError = kSavedGame_NotSet;
		StartSaveLoad(IOMODE_LOAD, slotParams, 0, NULL);
		return true;
	}

	int32_t SavedGame::Exists(SavedGameSlotParams* slotParams)
	{
		SceSaveDataMount mount;
		SceSaveDataDirName dirName;

		memset(&mount, 0x00, sizeof(SceSaveDataMount));
		mount.userId = slotParams->userId;
		if (mount.userId == 0)
		{
			sceUserServiceGetInitialUser(&mount.userId);
		}
		mount.dirName = &dirName;
		strncpy(dirName.data, slotParams->dirName, SCE_SAVE_DATA_DIRNAME_DATA_MAXSIZE);

		mount.mountMode = SCE_SAVE_DATA_MOUNT_MODE_RDONLY;

		SceSaveDataMountResult mountResult;
		memset(&mountResult, 0x00, sizeof(mountResult));
		int32_t mountresult = sceSaveDataMount(&mount, &mountResult);

		if (mountresult == SCE_OK)
		{
			int32_t umountresult = sceSaveDataUmount(&mountResult.mountPoint);
			if (umountresult != SCE_OK)
			{
				printf("umount failed during SavedGame::Exists() 0x%x\n",umountresult);
			}

		}
		return mountresult;
	}

	int32_t SavedGame::GetDetails(SavedGameSlotParams* slotParams, SaveGameSlotDetails *slotDetails)
	{
		SceSaveDataMount mount;
		SceSaveDataDirName dirName;

		static SceSaveDataParam saveDataDetails;		// static so that we can maintain the values outside of this function and return pointers to some of the data in slotDetails
		SceSaveDataIcon icon;
		
		uint32_t iconBufSize = 128 * 1024;
		

		if (SaveDataDetailsIconBuf == NULL)
		{
			SaveDataDetailsIconBuf = malloc(iconBufSize);
		}


		memset(&mount, 0x00, sizeof(SceSaveDataMount));
		mount.userId = slotParams->userId;
		if (mount.userId == 0)
		{
			sceUserServiceGetInitialUser(&mount.userId);
		}
		mount.dirName = &dirName;
		strncpy(dirName.data, slotParams->dirName,SCE_SAVE_DATA_DIRNAME_DATA_MAXSIZE);

		mount.mountMode = SCE_SAVE_DATA_MOUNT_MODE_RDONLY;

		SceSaveDataMountResult mountResult;
		memset(&mountResult, 0x00, sizeof(mountResult));
		int32_t mountresult = sceSaveDataMount(&mount, &mountResult);

		if (mountresult == SCE_OK)
		{
			if ((slotDetails == NULL) || (slotDetails->m_size != sizeof(SaveGameSlotDetails)) )
			{
				sceSaveDataUmount(&mountResult.mountPoint);
				printf("sceSaveDataGetParam failed, bad parameter in result data\n");
				return -1;
			}

			memset(&saveDataDetails, 0, sizeof(saveDataDetails));
			size_t gotSize = 0;

			int32_t ret = sceSaveDataGetParam(&mountResult.mountPoint, SCE_SAVE_DATA_PARAM_TYPE_ALL, &saveDataDetails, sizeof(saveDataDetails), &gotSize);
			if (ret != SCE_OK)
			{
				printf("sceSaveDataGetParam failed during SavedGame::GetDetails() 0x%x\n",ret);
				sceSaveDataUmount(&mountResult.mountPoint);
				return ret;
			}
			slotDetails->title = saveDataDetails.title;
			slotDetails->subTitle = saveDataDetails.subTitle;
			slotDetails->detail = saveDataDetails.detail;
			slotDetails->userParam = saveDataDetails.userParam;

			SceRtcDateTime RTCtime;
			SceRtcTick RTCtick;

			sceRtcSetTime_t(&RTCtime,saveDataDetails.mtime);	// convert posix mtime to SceRtcDateTime
			sceRtcGetTick(&RTCtime, &RTCtick);					// convert to SceRtcTicks
			sceRtcConvertUtcToLocalTime(&RTCtick, &RTCtick);	// convert to local time based on current system settings

			slotDetails->rtcTicktime = RTCtick.tick;
			slotDetails->mtime = saveDataDetails.mtime;

			memset(&icon, 0x00, sizeof(icon));
			icon.buf = SaveDataDetailsIconBuf;
			icon.bufSize = iconBufSize;

			ret = sceSaveDataLoadIcon(&mountResult.mountPoint, &icon);
			if (ret != SCE_OK)
			{
				printf("sceSaveDataLoadIcon failed during SavedGame::GetDetails() 0x%x\n",ret);
				sceSaveDataUmount(&mountResult.mountPoint);
				return ret;
			}

			slotDetails->m_DataIconData= SaveDataDetailsIconBuf;
			slotDetails->m_DataIconDataSize = icon.dataSize;

			uint32_t  umountresult = sceSaveDataUmount(&mountResult.mountPoint);
			if (umountresult != SCE_OK)
			{
				printf("umount failed during SavedGame::Exists() 0x%x\n",umountresult);
			}

		}
		return mountresult;
	}

	bool SavedGame::IsDialogOpen()
	{
		if (m_DialogModuleLoaded && m_DialogModuleInitialised)
		{
			SceCommonDialogStatus status = sceSaveDataDialogGetStatus();
			if (status == SCE_COMMON_DIALOG_STATUS_RUNNING)
			{
				return true;
			}
		}
		return false;
	}

	bool SavedGame::Delete(SavedGameSlotParams* slotParams, bool useDialogs)
	{
		if (!m_Initialised) { return false; }
		InitSlotParams(slotParams);
		m_IOThread->SetSlotParams(m_ioThreadedSlotParams);
		m_useDialogs = useDialogs;
		m_deleteState = Delete::STATE_UNKNOWN;
		m_FailureCode = FAIL_NONE;
		StartSaveLoad(IOMODE_DELETE, slotParams, 0, NULL);
		return true;
	}

	int32_t SavedGame::InitDialog()
	{
		int		res = SCE_OK;
		if (m_useDialogs)	// if we are autoload/save we don't want to startup the dialog until required
		{
			if (m_DialogModuleInitialised == false)
			{
				if (sceSysmoduleIsLoaded(SCE_SYSMODULE_SAVE_DATA_DIALOG)==SCE_SYSMODULE_ERROR_UNLOADED)	// something else might have loaded the module
				{
					res = sceSysmoduleLoadModule(SCE_SYSMODULE_SAVE_DATA_DIALOG);
					if (res != SCE_OK)
					{
						Messages::LogError("SavedGame::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(res));
						return res;
					}
					m_DialogModuleLoaded = true;
				}

				res = sceSaveDataDialogInitialize();
				if (res!=SCE_OK)
				{
					Messages::LogError("SavedGame::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(res));
					return res;
				}
				m_DialogModuleInitialised = true;
				m_DialogOpen = true;		// is this the correct place, or is it too early?
			}

			
			m_isFinished = false;		// we are starting a new dialog task, this is used to detect when it's finished
			m_FailureCode = FAIL_NONE;

		}

		m_SavedDataDialogState = !m_useDialogs ? SAVEDATA_DIALOG_STEP_AUTO : SAVEDATA_DIALOG_STEP_FIXED;
		m_Busy = true;
		return res;
	}

	int32_t SavedGame::StartSaveLoad(IOThreadMode mode, SavedGameSlotParams* slotParams, int size, void *buffer)
	{
		DialogMode dialogMode;
		int32_t res;

		if ((m_IOThread->GetStatus() != THREAD_STOPPED)&&(m_IOThread->GetStatus() != THREAD_END))
		{
			Messages::LogError("SavedGame::%s@L%d - thread already running.", __FUNCTION__, __LINE__);
			Messages::AddMessage(Messages::kSavedGame_SaveGenericError);
			return -1;
		}

		// Set IO thread parameters
		m_IOThread->SetBuffer(size, buffer);
		m_IOThread->SetResult(0);
		m_IOThreadMode = mode;

		m_userId = slotParams->userId;
		if (m_userId == 0)
		{
			sceUserServiceGetInitialUser(&m_userId);
		}

		if (mode == IOMODE_SAVE)
		{
			dialogMode = SAVEDATA_DIALOG_MODE_SAVE;
		}
		else/* if (mode == IOMODE_LOAD)*/
		{
			dialogMode = SAVEDATA_DIALOG_MODE_LOAD;
		}

		// Open dialog
		res = InitDialog();
		if (res != SCE_OK)
		{
			Messages::LogError("SavedGame::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(res));
			m_IOThread->SetStatus(THREAD_END);
			Messages::AddMessage(Messages::kSavedGame_SaveGenericError);
			return -1;
		}

		return SCE_OK;
	}

	int32_t SavedGame::ShutdownIOThread(void)
	{
		m_IOThread->Stop();

		return SCE_OK;
	}

	int32_t SavedGame::ShutdownDialog(void)
	{
		int32_t res;

		if (m_DialogOpen)
		{
			SceSaveDataDialogCloseParam closeParam;
			memset(&closeParam, 0x00, sizeof(closeParam));
			closeParam.anim = SCE_SAVE_DATA_DIALOG_ANIMATION_ON;

			res = sceSaveDataDialogClose(&closeParam);

			if (m_DialogModuleInitialised)
			{
				res = sceSaveDataDialogTerminate();
				m_DialogModuleInitialised = false;
			}

			m_DialogOpen = false;
		}

		// Shutdown IO thread
		ShutdownIOThread();

		m_Busy = false;

		return SCE_OK;
	}

	void SavedGame::updateErrorDialog()
	{
		SceCommonDialogStatus status = sceSaveDataDialogUpdateStatus();
		if (status == SCE_COMMON_DIALOG_STATUS_FINISHED)
		{
			m_isFinished = true;

			SceSaveDataDialogResult result;
			memset(&result, 0x00, sizeof(SceSaveDataDialogResult));
			sceSaveDataDialogGetResult(&result);

			m_Result = result.result;
		}
	//	printf("update status : 0x%x\n",status);
	}

	/*
		Main save data update loop ... called from PrxSavedGamesUpdate() 
	*/
	int32_t SavedGame::Update(void)
	{
		if(!m_Busy)
		{
			return 0;
		}

		if (m_useDialogs)
		{
			// call the update function for managing the state machine for each mode
			switch (m_IOThreadMode)
			{
				case IOMODE_SAVE:
					updateSave();
					break;
				case IOMODE_LOAD:
					updateLoad();
					break;
				case IOMODE_DELETE: 
					updateDelete();
					break;
				case IOMODE_ERRORDIALOG:
					updateErrorDialog();
					break;
				default:
					printf("unexpected m_IOThreadMode\n");
					break;
			}
			if (m_isFinished) 
			{ 
				const Messages::MessageType kSuccessMessages[]=
				{
					Messages::kSavedGame_GameSaved,
					Messages::kSavedGame_GameLoaded,
					Messages::kSavedGame_GameDeleted
				};
				const Messages::MessageType kErrorMessages[]=
				{
					Messages::kSavedGame_SaveGenericError,
					Messages::kSavedGame_SaveNoSpace,
					Messages::kSavedGame_SaveNotMounted,
					Messages::kSavedGame_SaveGenericError,
					Messages::kSavedGame_LoadCorrupted,
					Messages::kSavedGame_LoadNoData
				};
				//				printf("dialog result:%d\n", m_Result);
				if (m_Result == SCE_COMMON_DIALOG_RESULT_USER_CANCELED)	
				{
					Messages::AddMessage(Messages::kSavedGame_Canceled);
				}
				else
				{
					if (m_PendingError!= kSavedGame_NotSet)
					{
						Messages::AddMessage(m_PendingError);
						m_PendingError = kSavedGame_NotSet;
					}
					else
					{
						if (m_FailureCode > 0)
						{
							Messages::AddMessage(kErrorMessages[m_FailureCode]);
						}
						else if((IOMODE_LOAD   == m_IOThreadMode && m_loadState   == Load::STATE_CANCELED)   ||
								(IOMODE_DELETE == m_IOThreadMode && m_deleteState == Delete::STATE_CANCELED) ||
								(IOMODE_SAVE   == m_IOThreadMode && m_saveState   == Save::STATE_CANCELED) )
						{
							Messages::AddMessage(Messages::kSavedGame_Canceled);
						}
						else
						{
							Messages::AddMessage(kSuccessMessages[m_IOThreadMode]);
						}
					}
				}
				m_Busy = false; 
				ShutdownDialog();
			}
		}
		else
		{
			// old vita based save system used for autosave/load

			// if the io thread is running something, always continue with it untill it's finished
			if	((m_IOThread->GetStatus() == THREAD_INIT)||(m_IOThread->GetStatus() == THREAD_RUNNING) )
			{
//				printf("io thread is running ... waiting for the result\n");
				return SCE_COMMON_DIALOG_STATUS_RUNNING;
			}


			switch (m_SavedDataDialogState)
			{
			case SAVEDATA_DIALOG_STEP_FIXED:
			case SAVEDATA_DIALOG_STEP_AUTO:
				{
					m_IOThread->Start(m_IOThreadMode);
					m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_SAVING;
				}
				break;
			case SAVEDATA_DIALOG_STEP_SAVING:		// saving is incorrect term here ... it means processing (save/load/delete etc)
				{
					IOThreadStatus status = m_IOThread->GetStatus();
					if ((status != THREAD_RUNNING) && (status != THREAD_INIT))
					{
						bool StartAutoSaveError = false;
						int res = m_IOThread->GetResult();
//						printf("thread is no longer running, status:%d result:0x%x\n",status, res);
						Messages::MessageType message = Messages::kSavedGame_SaveGenericError;
						if (m_IOThreadMode == IOMODE_LOAD) { message = Messages::kSavedGame_LoadCorrupted; }
						switch (res)
						{
						
							// generic errors
						case SCE_SAVE_DATA_ERROR_BROKEN:		
							StartAutoSaveError = true;
							break;
						case SCE_SAVE_DATA_ERROR_NOT_FOUND:
							message = Messages::kSavedGame_LoadNoData;
							StartAutoSaveError = false; // do not start the dialog for save data not found
							break;
						case SCE_SAVE_DATA_ERROR_NO_SPACE:
							message = Messages::kSavedGame_SaveNoSpace;
							StartAutoSaveError = true;
							break;
						case SCE_SAVE_DATA_ERROR_NOT_MOUNTED:
							message = Messages::kSavedGame_SaveNotMounted;
							StartAutoSaveError = true;
							break;
						case SCE_SAVE_DATA_ERROR_BAD_MOUNTED:
							message = Messages::kSavedGame_SaveGenericError;
							StartAutoSaveError = true;
							break;
						case SCE_SAVE_DATA_ERROR_NO_SPACE_FS:
							message = Messages::kSavedGame_SaveNoSpace;
							StartAutoSaveError = true;
							break;


						case SCE_OK:
							switch(m_IOThreadMode)
							{
							case IOMODE_SAVE:
								message = Messages::kSavedGame_GameSaved;
								break;
							case IOMODE_LOAD:
								message = Messages::kSavedGame_GameLoaded;
								break;
							case IOMODE_DELETE:
								message = Messages::kSavedGame_GameDeleted;
								break;
							case IOMODE_ERRORDIALOG:
								printf("TODO: handle update complete\n");
								break;
							}
							break;

						default:
							printf("unsupported error code:%x\n",res);
						}

						if (StartAutoSaveError)		// do we need to start dialogs system for error
						{
							int32_t ret;
							m_IOThread->SetResult(res);		// so that the dialog can return the correct error

							m_useDialogs = true;
							InitDialog();

							if (res == SCE_SAVE_DATA_ERROR_NO_SPACE_FS)
							{
								// space case dialog reporting the amount of size required
								ret = save_data::util_dialog::openDialogSystemMessage(SCE_SAVE_DATA_DIALOG_TYPE_SAVE,
															m_userId, NULL, &m_selectedDirName,
															SCE_SAVE_DATA_DIALOG_SYSMSG_TYPE_NOSPACE,
															m_ioThreadedSlotParams.newTitle,
															m_IOThread->GetRequiredBlocks(),
															m_newIconBuf, m_newIconSize);
							}
							else
							{
								ret = save_data::util_dialog::openDialogError(m_IOThreadMode == IOMODE_LOAD ? SCE_SAVE_DATA_DIALOG_TYPE_LOAD : SCE_SAVE_DATA_DIALOG_TYPE_SAVE,
													m_userId, NULL, &m_selectedDirName, res, m_ioThreadedSlotParams.newTitle);
							}
							if(ret < SCE_OK)
							{
								printf("openDialogError : 0x%x\n", ret);
								return ret;
							}

							m_IOThreadMode = IOMODE_ERRORDIALOG;
							m_PendingError = message;
						}
						else		// no dialogs, then inform the scripts that we have completed
						{
							Messages::AddMessage(message);
							ShutdownDialog();
							m_SavedDataDialogState = SAVEDATA_DIALOG_STEP_NONE;
						}
					}
				}
				break;
			default:
				break;
			}

		}
		return SCE_OK;
	}
}
