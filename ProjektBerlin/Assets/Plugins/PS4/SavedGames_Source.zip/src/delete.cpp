﻿/* SCE CONFIDENTIAL
 * PlayStation(R)4 Programmer Tool Runtime Library Release 01.600.051
 * Copyright (C) 2013 Sony Computer Entertainment Inc.
 * All Rights Reserved.
 */

#include <kernel.h>
#include <sceerror.h>
#include <save_data.h>
#include <save_data_dialog.h>
#include "config.h"
#include "util.h"
#include "util_dialog.h"

#include "SavedGame.h"


namespace UnitySavedGames {


//-----------------------------------------------------------------------------
// Update
//-----------------------------------------------------------------------------
int32_t SavedGame::updateDelete(void)
{
	int32_t ret = SCE_OK;

	SceCommonDialogStatus status = sceSaveDataDialogUpdateStatus();

	// display

	// flow

	switch(m_deleteState)
	{
	case Delete::STATE_UNKNOWN:
		PRINT("STATE_UNKNOWN\n");
		if(m_IOThread->isReady())
		{
			m_deleteState = Delete::STATE_JOB_SEARCH_START;
		}
		break;

	case Delete::STATE_JOB_SEARCH_START:
		PRINT("STATE_JOB_SEARCH_START\n");
		m_IOThread->startJob(iStartSearch, iEndSearch, this);
		m_deleteState = Delete::STATE_JOB_SEARCH;
		break;

	case Delete::STATE_JOB_SEARCH:
		PRINT("STATE_JOB_SEARCH\n");
		if(m_IOThread->isJobRunning() == false)
		{
			if(m_errorCode < SCE_OK)
			{
				m_deleteState = Delete::STATE_SHOW_ERROR_START;
			}
			else
			{
				if(m_searchedDirNum == 0)
				{
					m_deleteState = Delete::STATE_SHOW_NODATA_START;
				}
				else
				{
					m_deleteState = Delete::STATE_SHOW_LIST_START;
				}
			}
		}
		break;

	case Delete::STATE_SHOW_LIST_START:
		PRINT("STATE_SHOW_LIST_START\n");
		ret = save_data::util_dialog::openDialogList(SCE_SAVE_DATA_DIALOG_TYPE_DELETE,
			m_userId, NULL, m_searchedDirNames, m_searchedDirNum, m_ioThreadedSlotParams.newTitle );
		if(ret < SCE_OK)
		{
			EPRINT("openDialogList : 0x%x\n", ret);
			return ret;
		}
		m_deleteState = Delete::STATE_SHOW_LIST;
		break;

	case Delete::STATE_SHOW_LIST:
		//PRINT("STATE_SHOW_LIST\n");
		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			memset(&m_selectedDirName, 0x00, sizeof(m_selectedDirName));
			SceSaveDataParam param;
			memset(&param, 0x00, sizeof(param));

			SceSaveDataDialogResult result;
			memset(&result, 0x00, sizeof(SceSaveDataDialogResult));
			result.dirName = &m_selectedDirName;
			result.param = &param;

			ret = sceSaveDataDialogGetResult(&result);
			if(result.result == SCE_COMMON_DIALOG_RESULT_OK)
			{
				m_deleteState = Delete::STATE_SHOW_CONFIRM_DELETE_START;
			}
			else if(result.result == SCE_COMMON_DIALOG_RESULT_USER_CANCELED)
			{
				m_deleteState = Delete::STATE_CANCELED;
			}
			else
			{
				m_saveState = Save::STATE_SHOW_ERROR_START;
				m_errorCode = result.result;
			}

			// display
		}
		break;

	case Delete::STATE_SHOW_DELETE_START:
		//PRINT("STATE_SHOW_DELETE_START\n");
		// start thread
		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			m_callClose = false;
			ret = save_data::util_dialog::openDialogOperating(SCE_SAVE_DATA_DIALOG_TYPE_DELETE,
									  m_userId, NULL, &m_selectedDirName, m_ioThreadedSlotParams.newTitle);
			if(ret < SCE_OK)
			{
				EPRINT("openDialogOperating : 0x%x\n", ret);
				return ret;
			}
		}
		else if(SCE_COMMON_DIALOG_STATUS_RUNNING == status)
		{
			ret = sceSaveDataDialogIsReadyToDisplay();
			if(ret <= 0)
			{
				// not ready
				PRINT("sceSaveDataDialogIsReadyToDisplay : 0x%x\n", ret);
				break;
			}

			m_IOThread->startJob(iStartDelete, iEndDelete, this);
			m_deleteState = Delete::STATE_SHOW_DELETE;
		}
		break;

	case Delete::STATE_SHOW_DELETE:
		//PRINT("STATE_SHOW_DELETE\n");
		if(m_IOThread->isJobRunning() == false)
		{
			if(SCE_COMMON_DIALOG_STATUS_RUNNING == status && m_callClose == false)
			{
				SceSaveDataDialogCloseParam closeParam;
				memset(&closeParam, 0x00, sizeof(closeParam));
				closeParam.anim = (m_errorCode < SCE_OK) ? SCE_SAVE_DATA_DIALOG_ANIMATION_OFF : SCE_SAVE_DATA_DIALOG_ANIMATION_ON;
				ret = sceSaveDataDialogClose(&closeParam);
				if(ret == SCE_OK)
				{
					m_callClose = true;
				}
			}
			else if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
			{
				PRINT("delete job result : 0x%x\n", ret);
				if(m_errorCode < SCE_OK)		// check job result
				{
					m_deleteState = Delete::STATE_SHOW_ERROR_START;
				}
				else
				{
					m_deleteState = Delete::STATE_FINISH;
				}
			}
		}
		break;

	case Delete::STATE_SHOW_CONFIRM_DELETE_START:
		PRINT("STATE_SHOW_CONFIRM_DELETE_START\n");
		ret = save_data::util_dialog::openDialogConfirm(SCE_SAVE_DATA_DIALOG_TYPE_DELETE,
								m_userId, NULL, &m_selectedDirName,
								SCE_SAVE_DATA_DIALOG_SYSMSG_TYPE_CONFIRM,
								m_ioThreadedSlotParams.title,
								m_newIconBuf, m_newIconSize);
		if(ret < SCE_OK)
		{
			EPRINT("openDialogConfirm : 0x%x\n", ret);
			return ret;
		}
		m_deleteState = Delete::STATE_SHOW_CONFIRM_DELETE;
		break;

	case Delete::STATE_SHOW_CONFIRM_DELETE:
		//PRINT("STATE_SHOW_CONFIRM_DELETE\n");
		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			memset(&m_selectedDirName, 0x00, sizeof(m_selectedDirName));
			SceSaveDataParam param;
			memset(&param, 0x00, sizeof(param));

			SceSaveDataDialogResult result;
			memset(&result, 0x00, sizeof(SceSaveDataDialogResult));
			result.dirName = &m_selectedDirName;
			result.param = &param;

			ret = sceSaveDataDialogGetResult(&result);
			if(ret < SCE_OK)
			{
				EPRINT("sceSaveDataDialogGetResult : 0x%x\n", ret);
				m_deleteState = Delete::STATE_FINISH;
			}
			else
			{
				if(result.result == SCE_OK)
				{
					if(result.buttonId == SCE_SAVE_DATA_DIALOG_BUTTON_ID_YES)
					{
						m_deleteState = Delete::STATE_SHOW_DELETE_START;
					}
					else
					{
						m_deleteState = Delete::STATE_CANCELED;
					}
				}
				else if(result.result == SCE_COMMON_DIALOG_RESULT_USER_CANCELED)
				{
					m_deleteState = Delete::STATE_CANCELED;
				}
				else
				{
					m_deleteState = Delete::STATE_SHOW_ERROR_START;
					m_errorCode = result.result;
				}

				// display
			}
		}
		break;

	case Delete::STATE_SHOW_ERROR_START:
		PRINT("STATE_SHOW_ERROR_START\n");
		ret = save_data::util_dialog::openDialogError(SCE_SAVE_DATA_DIALOG_TYPE_DELETE,
							  m_userId, NULL, &m_selectedDirName, m_errorCode, m_ioThreadedSlotParams.newTitle);
		if(ret < SCE_OK)
		{
			EPRINT("openDialogError : 0x%x\n", ret);
			return ret;
		}
		m_deleteState = Delete::STATE_SHOW_ERROR;
		break;

	case Delete::STATE_SHOW_ERROR:
		//PRINT("STATE_SHOW_ERROR\n");
		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			SceSaveDataDialogResult result;
			memset(&result, 0x00, sizeof(SceSaveDataDialogResult));
			ret = sceSaveDataDialogGetResult(&result);
			m_deleteState = Delete::STATE_FINISH;

			// display
		}
		break;

	case Delete::STATE_SHOW_NODATA_START:
		PRINT("STATE_SHOW_NODATA_START\n");
		ret = save_data::util_dialog::openDialogSystemMessage(SCE_SAVE_DATA_DIALOG_TYPE_DELETE,
									  m_userId, NULL, NULL,
									  SCE_SAVE_DATA_DIALOG_SYSMSG_TYPE_NODATA, m_ioThreadedSlotParams.newTitle);
		if(ret < SCE_OK)
		{
			EPRINT("openDialogSystemMessage : 0x%x\n", ret);
			return ret;
		}
		m_deleteState = Delete::STATE_SHOW_NODATA;
		break;

	case Delete::STATE_SHOW_NODATA:
		//PRINT("STATE_SHOW_NODATA\n");
		if(SCE_COMMON_DIALOG_STATUS_FINISHED == status)
		{
			SceSaveDataDialogResult result;
			memset(&result, 0x00, sizeof(SceSaveDataDialogResult));
			ret = sceSaveDataDialogGetResult(&result);
			m_deleteState = Delete::STATE_CANCELED;

			// display
		}
		break;

	case Delete::STATE_CANCELED:
	case Delete::STATE_FINISH:
	default:
		PRINT("state : %d\n", m_deleteState);
		m_isFinished = true;
		break;
	}

	return SCE_OK;
}


//-----------------------------------------------------------------------------
// JOB
//-----------------------------------------------------------------------------
int32_t SavedGame::jobDelete()
{
	int32_t ret = SCE_OK;

	// delete
	ret = save_data::util::del(m_userId, NULL, &m_selectedDirName, true);
	if(ret < SCE_OK)
	{
		EPRINT("util::del : 0x%x\n", ret);
		return ret;
	}

	return SCE_OK;
}


void SavedGame::jobDeleteEnd(const int32_t errorCode)
{
	m_errorCode = errorCode;
}


//-----------------------------------------------------------------------------
// JOB I/F
//-----------------------------------------------------------------------------
int32_t SavedGame::iStartDelete(void *userData)
{
	SavedGame *del = static_cast<SavedGame *>(userData);

	return del->jobDelete();
}

void SavedGame::iEndDelete(const int32_t errorCode, void *userData)
{
	SavedGame *del = static_cast<SavedGame *>(userData);

	del->jobDeleteEnd(errorCode);
}

int32_t SavedGame::jobSearch()
{
	int32_t ret = SCE_OK;

	// Note there will only be space for one less save game as one space is reserved for an AutoSave.
	m_searchedDirNames = new SceSaveDataDirName[SAVE_DATA_COUNT];
	if(!m_searchedDirNames)
	{
		EPRINT("m_searchedDirNames == NULL\n");
		return -1;
	}

	ret = save_data::util::search(m_userId, NULL, m_searchedDirNames, SAVE_DATA_COUNT, &m_searchedDirNum);
	if(ret < SCE_OK)
	{
		EPRINT("util::Search : 0x%x\n", ret);
		return ret;
	}

	return SCE_OK;
}


void SavedGame::jobSearchEnd(const int32_t errorCode)
{
	m_errorCode = errorCode;
}


//-----------------------------------------------------------------------------
// JOB I/F
//-----------------------------------------------------------------------------
int32_t SavedGame::iStartSearch(void *userData)
{
	SavedGame *base = static_cast<SavedGame *>(userData);

	return base->jobSearch();
}


void SavedGame::iEndSearch(const int32_t errorCode, void *userData)
{
	SavedGame *base = static_cast<SavedGame *>(userData);

	base->jobSearchEnd(errorCode);
}


}	// namespace save_data {
