#ifndef _IOTHREAD_H
#define _IOTHREAD_H

#include "prx.h"
#include "SimpleLock.h"
#include <save_data_dialog.h>

#include <string>

#define MAX_FILENAMESIZE (64)	// not sure what this should be
#define MAX_ICONPATHSIZE (256)

namespace UnitySavedGames
{
	struct IOThreadSlotParams
	{
		SceUserServiceUserId  userId;
		SceSaveDataTitleId  titleId;		// SceSaveDataTitleId
		SceSaveDataDirName dirName;	// directory name
		char fileName[MAX_FILENAMESIZE];		// file name

		// used when creating the save game
		char title[SCE_SAVE_DATA_TITLE_MAXSIZE];
		char newTitle[SCE_SAVE_DATA_TITLE_MAXSIZE];
		char subTitle[SCE_SAVE_DATA_SUBTITLE_MAXSIZE];
		char detail[SCE_SAVE_DATA_DETAIL_MAXSIZE];
		char iconPath[MAX_ICONPATHSIZE];
		size_t sizeKiB;

	};

	enum IOThreadStatus
	{
		THREAD_STOPPED,
		THREAD_INIT,
		THREAD_RUNNING,
		THREAD_LOADED,
		THREAD_END
	};

	enum IOThreadMode
	{
		IOMODE_SAVE,
		IOMODE_LOAD,
		IOMODE_DELETE,
		IOMODE_ERRORDIALOG
	};

	class IOThread
	{
		SimpleLock m_Lock;

		bool m_ThreadCreated;
		ScePthread m_ThreadID;

		IOThreadSlotParams m_SlotParams;
		IOThreadStatus m_Status;
		int	m_BufferSize;
		void* m_Buffer;
		int m_Result;
		SceSaveDataBlocks m_requiredBlocks; // number of block required by save game

	public:
		IOThread();
		~IOThread();

		int Start(IOThreadMode mode/*, int slotID*/);
		int Stop(void);


		void SetSlotParams(const IOThreadSlotParams& slotParams)
		{
			m_SlotParams = slotParams;
		}

		IOThreadStatus GetStatus() const { return m_Status; }
		void SetStatus(IOThreadStatus status) { m_Status = status; }

		void SetBuffer(int bufferSize, void* buffer);
		void* GetBuffer() const
		{
			if(m_Buffer && m_BufferSize > 0)
			{
				return m_Buffer;
			}
			return NULL;
		}
		int GetBufferSize() const
		{
			if(m_Buffer && m_BufferSize > 0)
			{
				return m_BufferSize; // - sizeof(Header);
			}
			return 0;
		}

		int GetResult() const { return m_Result; }
		void SetResult(int result) { m_Result = result; }
		SceSaveDataBlocks GetRequiredBlocks() const { return m_requiredBlocks; }

		// new job system 
		bool isReady();
		bool isJobRunning();
		bool m_isJobRunning;
		typedef  int32_t (*startjobfunc)(void *);
		typedef  void (*endjobfunc)(const int32_t errorCode, void *);
		void startJob(startjobfunc start, endjobfunc end, void *userData);
		static void *jobWrapper(void *input);
		class JobInput
		{
		public:
			startjobfunc startfunc;
			endjobfunc endfunc;
			void *userData;
			IOThread *ioThread;
		};

	private:
		static void * ThreadFuncSave(void *argc);
		static void * ThreadFuncLoad(void *argc);
		static void * ThreadFuncDelete(void *argc);
	};
}

#endif // _IOTHREAD_H
