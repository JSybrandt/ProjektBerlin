﻿/* SCE CONFIDENTIAL
 * PlayStation(R)4 Programmer Tool Runtime Library Release 01.600.051
 * Copyright (C) 2013 Sony Computer Entertainment Inc.
 * All Rights Reserved.
 */

#ifndef	_SCE_SAMPLE_COMMONDIALOG_SAVE_DATA_DIALOG_UTIL_H
#define	_SCE_SAMPLE_COMMONDIALOG_SAVE_DATA_DIALOG_UTIL_H

#include <user_service.h>
#include <save_data.h>

namespace save_data {
	

	namespace util {
		int32_t create(const SceUserServiceUserId userId,
					   const SceSaveDataTitleId *titleId,
					   const SceSaveDataDirName *dirName,
						const char *fileName, const size_t fileSize,const void *fileData,
					   SceSaveDataBlocks *requiredBlocks,
					   const char *title,
					   const char *subTitle,
					   const char *detail,
					   const char *iconPath,
					   bool dialogEnabled
					   );
		int32_t read(const SceUserServiceUserId userId,
					 const SceSaveDataTitleId *titleId,
					 const SceSaveDataDirName *dirName,
					 const char *fileName, uint8_t **buffer, int64_t *filesize,
					 SceSaveDataParam *param,
					 bool dialogEnabled);
		int32_t write(const SceUserServiceUserId userId,
					  const SceSaveDataTitleId *titleId,
					  const SceSaveDataDirName *dirName,
					  const char *fileName, const size_t fileSize,const void *fileData,
					  SceSaveDataBlocks *requiredBlocks,
					  bool dialogEnabled
					  );
		int32_t writeWithParams(const SceUserServiceUserId userId,
						const SceSaveDataTitleId *titleId,
						const SceSaveDataDirName *dirName,
						const char *fileName, const size_t fileSize,const void *fileData,
						SceSaveDataBlocks *requiredBlocks,
						const char *title,
						const char *subTitle,
						const char *detail,
						const char *iconPath,
						bool dialogEnabled
						);


		int32_t search(const SceUserServiceUserId userId,
					   const SceSaveDataTitleId *titleId,
					   SceSaveDataDirName *dirNames, const uint32_t dirNameNum, uint32_t *hitNum);
		int32_t del(const SceUserServiceUserId userId,
					   const SceSaveDataTitleId *titleId,
					   const SceSaveDataDirName *dirName,
					    bool dialogEnabled
					   );

		int32_t loadFile(const char *path, uint8_t **data, size_t *data_size);
		
	}	// namespace util
}	// namespace save_data {
#endif	//_SCE_SAMPLE_COMMONDIALOG_SAVE_DATA_DIALOG_UTIL_H
