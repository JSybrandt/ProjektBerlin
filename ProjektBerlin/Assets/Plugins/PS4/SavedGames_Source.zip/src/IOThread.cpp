#include "IOThread.h"
#include "MessagePipe.h"
#include "ErrorCodes.h"


#include "util.h"


#define	SAVEDATA_MOUNTPOINT_DATA		"savedata0"
#define	SAVEDATA_SUBTHREAD_NAME			"savedata_sub_thr"
#define	SAVEDATA_SAVE_FILENAME_BASE		"data"
#define	SAVEDATA_SAVE_FILENAME_EXT		".bin"
#define SAVEDATA_HEADER_IDENT			"SVGM"

namespace UnitySavedGames
{
	IOThread::IOThread()
		: m_ThreadCreated(false)
		, m_Status(THREAD_STOPPED)
		, m_BufferSize(0)
		, m_Buffer(NULL)
		, m_Result(0)
	{
	}

	IOThread::~IOThread()
	{
		Stop();
		free(m_Buffer);
	}
	


	void IOThread::SetBuffer(int bufferSize, void* buffer)
	{
		free(m_Buffer);
		if(buffer)
		{
			m_BufferSize = bufferSize;
			m_Buffer = malloc(m_BufferSize);
			if (m_Buffer == NULL)
			{
				Messages::LogError("IOThread::%s@L%d - unable to allocate save buffer", __FUNCTION__, __LINE__);
				return;
			}
			void* data = (m_Buffer);
			memcpy(data, buffer, bufferSize);
		}
		else
		{
			m_BufferSize = 0;
			m_Buffer = NULL;
		}
	}

	int IOThread::Start(IOThreadMode mode/*, int slotID*/)
	{
		void *(*entry)(void *) = NULL;
		int		res;

		switch(mode)
		{
			case IOMODE_LOAD:
				entry = ThreadFuncLoad;
				break;

			case IOMODE_SAVE:
				entry = ThreadFuncSave;
				break;

			case IOMODE_DELETE:
				entry = ThreadFuncDelete;
				break;
			case IOMODE_ERRORDIALOG:
				{
					res = -1;
					Messages::LogError("IOThread::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(res));
					return res;
				}
				break;
		}
		ScePthreadAttr *attr = NULL;
		m_Status = THREAD_INIT;
		res = scePthreadCreate(&m_ThreadID,attr,entry,this,SAVEDATA_SUBTHREAD_NAME);
		if (res < SCE_OK)
		{
			Messages::LogError("IOThread::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(res));
			return res;
		}

		SceKernelCpumask  mask;
		mask = 0x3c; // all cores except 0 (main thread) and 1 (gfx thread)
		res = scePthreadSetaffinity(m_ThreadID, mask);
		if (res < SCE_OK)
		{
			Messages::LogError("IOThread::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(res));
			return res;
		}

		m_ThreadCreated = true;

		return res;
	}

	int IOThread::Stop(void)
	{
		int		res;

		m_Status = THREAD_STOPPED;

		if (m_ThreadCreated != true)
		{
			return -1;
		}

		res = scePthreadJoin(m_ThreadID, NULL);
		if (res < SCE_OK)
		{
			Messages::LogError("IOThread::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(res));
			return res;
		}

		m_ThreadCreated = false;
		//	no pthread delete
		
		return res;
	}

	void * IOThread::ThreadFuncSave(void *argc)
	{
		IOThread* thread = (IOThread*)argc;
	
		thread->m_Status = THREAD_RUNNING;

		int32_t result = SCE_OK;
		bool dialogEnabled = false;


		result = save_data::util::writeWithParams(thread->m_SlotParams.userId,
				&thread->m_SlotParams.titleId,
				&thread->m_SlotParams.dirName,
				thread->m_SlotParams.fileName,thread->m_BufferSize,thread->m_Buffer,
				&thread->m_requiredBlocks,
				thread->m_SlotParams.title,
				thread->m_SlotParams.subTitle,
				thread->m_SlotParams.detail,
				thread->m_SlotParams.iconPath,
			dialogEnabled
			);
		if (result == SCE_SAVE_DATA_ERROR_NOT_FOUND)
		{
			result = save_data::util::create(thread->m_SlotParams.userId,
				&thread->m_SlotParams.titleId,
				&thread->m_SlotParams.dirName,
				thread->m_SlotParams.fileName,thread->m_BufferSize,thread->m_Buffer,
				&thread->m_requiredBlocks,
				thread->m_SlotParams.title,
				thread->m_SlotParams.subTitle,
				thread->m_SlotParams.detail,
				thread->m_SlotParams.iconPath,
				dialogEnabled
				);
			if (result != SCE_OK) 
			{
				Messages::LogError("IOThread::%s@L%d - %s create", __FUNCTION__, __LINE__, LookupErrorCode(result));

			}
		}

		
		thread->m_Result = result;
		thread->m_Status = THREAD_END;

		if (result!= SCE_OK)
		{
			Messages::LogError("IOThread::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(result));
		}

		scePthreadExit((void *)(uint64_t)result);
		return (void*)(uint64_t)result;
	}


	void * IOThread::ThreadFuncLoad(void *argc)
	{
		IOThread* thread = (IOThread*)argc;
		
		thread->m_Status = THREAD_RUNNING;
		uint8_t *buffer  = NULL;
		int64_t filesize  = 0;

		free (thread->m_Buffer);
		thread->m_Buffer = NULL;

		bool dialogEnabled = false;

		SceSaveDataParam saveDataParam;
		int32_t result = save_data::util::read(thread->m_SlotParams.userId,
			&thread->m_SlotParams.titleId,
			&thread->m_SlotParams.dirName,
			thread->m_SlotParams.fileName,
			&buffer,
			&filesize,
			&saveDataParam,
			dialogEnabled
			);

		thread->m_Buffer = buffer;
		thread->m_BufferSize = filesize;

		thread->m_Result = result;

		if (result!= SCE_OK)
		{
			Messages::LogError("IOThread::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(result));
			thread->m_Status = THREAD_END;
		}
		else
		{
			thread->m_Status = THREAD_LOADED;
		}


		scePthreadExit((void *)(uint64_t)result);
		return (void*)(uint64_t)result;
	
	}

	void * IOThread::ThreadFuncDelete(void *argc)
	{
		IOThread* thread = (IOThread*)argc;
		
		thread->m_Status = THREAD_RUNNING;
		
		bool dialogEnabled = false;

		int32_t result = save_data::util::del(thread->m_SlotParams.userId,
			&thread->m_SlotParams.titleId,
			&thread->m_SlotParams.dirName,
			dialogEnabled
			);
		
		thread->m_Result = result;
		thread->m_Status = THREAD_END;

		if (result!= SCE_OK)
		{
			Messages::LogError("IOThread::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(result));
		}

		scePthreadExit((void *)(uint64_t)result);
		return (void*)(uint64_t)result;
	}


	bool IOThread::isReady()
	{
		//printf("IOThread::isReady called ... not yet implemented\n");
		return true;
	}
	bool IOThread::isJobRunning()
	{
		return m_isJobRunning;
	}



	void *IOThread::jobWrapper(void *input)
	{
		JobInput ji = *(JobInput *)(input);		// make a copy of the data because it'll go out of scope 
		IOThread *ioThread = ji.ioThread;

		ioThread->m_isJobRunning = true;
		int32_t errorCode = ji.startfunc(ji.userData);
		ji.endfunc(errorCode, ji.userData);
		ioThread->m_isJobRunning = false;
		scePthreadExit((void *)(uint64_t)errorCode);
		return (void*)(uint64_t)errorCode;

	}

	void IOThread::startJob(startjobfunc start, endjobfunc end, void *userData)
	{

		static JobInput ji;	// keep it static so it does't get wiped when losing scope (means we can only have 1 job)
		ji.startfunc = start;
		ji.endfunc = end;
		ji.userData = userData;
		ji.ioThread = this;

		ScePthreadAttr *attr = NULL;

		int res = scePthreadCreate(&m_ThreadID,attr,jobWrapper,&ji,SAVEDATA_SUBTHREAD_NAME);
		if (res < SCE_OK)
		{
			Messages::LogError("IOThread::%s@L%d - %s", __FUNCTION__, __LINE__, LookupErrorCode(res));
		}

	}

} // UnitySavedGames
