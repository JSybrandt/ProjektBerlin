
#define PRX_INTERFACE extern "C" __declspec (dllexport)

typedef unsigned short ushort;
typedef unsigned int uint;


