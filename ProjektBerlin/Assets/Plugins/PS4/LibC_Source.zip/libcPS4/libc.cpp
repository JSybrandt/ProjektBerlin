/*
	Trivial implementation of some missing libc functions for .net sockets functions
*/


#include <net.h>
#include <libnetctl.h>
#include <string.h>

#include "libc.h"


PRX_INTERFACE int uname(void *buffer)
{
	return -1;
}

// see NetworkInterface.cs 

struct ifaddrs
{
	struct ifaddrs *ifa_next;
	char *ifa_name;
	unsigned int ifa_flags;
	void *ifa_addr;
	SceNetSockaddr *ifa_netmask;
union {
		SceNetSockaddr *ifu_broadaddr;
		/* Broadcast address of interface */
		SceNetSockaddr *ifu_dstaddr;
		/* Point-to-point destination address */
} ifa_ifu;
           #define              ifa_broadaddr ifa_ifu.ifu_broadaddr
           #define              ifa_dstaddr   ifa_ifu.ifu_dstaddr
	void            *ifa_data;    /* Address-specific data */
};


typedef unsigned char byte;
struct sockaddr_ll
{
	ushort sll_family;
	ushort sll_protocol;
	int sll_ifindex;
	ushort sll_hatype;
	byte sll_pkttype;
	byte sll_halen;
	byte sll_addr[SCE_NET_ETHER_ADDR_LEN ];
};


// sockaddr as used by LinuxNetworkInterfaceMarshal.cs
struct sockaddr_in
{
	ushort sin_family;
	ushort sin_port;
	uint sin_addr;
};

static struct ifaddrs nic;


static struct ifaddrs nic_sll;
static struct sockaddr_ll sll;

static sockaddr_in ifa_addr;
static SceNetSockaddr ifa_netmask;




#define AF_PACKET (17)	// matches AF_PACKET in NetworkInterface.cs # 234
#define ETHER (1)		// matches LinuxArpHardware.ETHER in LinuxNetworkInterfaceMarshal.cs

PRX_INTERFACE int getifaddrs(struct ifaddrs **buffer)
{
#if   defined(SN_TARGET_ORBIS)
#define NetGetInfo sceNetCtlGetInfo
#endif

	nic.ifa_name = "eth0";
	nic.ifa_flags = 0;

	SceNetCtlInfo info;

	bool wireless = false;
	NetGetInfo(SCE_NET_CTL_INFO_DEVICE, &info);
	if (info.device == SCE_NET_CTL_DEVICE_WIRELESS) { wireless = true;}

	NetGetInfo(SCE_NET_CTL_INFO_IP_ADDRESS, &info);
	ifa_addr.sin_family = SCE_NET_AF_INET;
	ifa_addr.sin_port = 0;
	sceNetInetPton(SCE_NET_AF_INET, info.ip_address , &ifa_addr.sin_addr);
	nic.ifa_addr = &ifa_addr;

	NetGetInfo(SCE_NET_CTL_INFO_NETMASK, &info);
	ifa_netmask.sa_len = 0;	// size is critical as NetworkInterface.cs treats sin_family as 16bit
	ifa_netmask.sa_family = SCE_NET_AF_INET;
	sceNetInetPton(SCE_NET_AF_INET, info.ip_address , ifa_netmask.sa_data);
	nic.ifa_netmask = &ifa_netmask;
	nic.ifa_next = &nic_sll;

	memset(&sll, 0, sizeof(sll) );
	sll.sll_family = AF_PACKET;
	sll.sll_hatype = ETHER;
	sll.sll_halen= SCE_NET_ETHER_ADDR_LEN ;

	sceNetGetMacAddress((SceNetEtherAddr *)&sll.sll_addr[0], 0);


	nic_sll.ifa_name = "eth0";
	nic_sll.ifa_flags = 0;
	nic_sll.ifa_addr = &sll;
	nic_sll.ifa_next = NULL;


	*buffer = &nic;

	return 0;
}

PRX_INTERFACE void freeifaddrs(struct ifaddrs *buffer)
{
}

